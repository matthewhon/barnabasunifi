/**
 * firebase/visitorSync.ts
 * Syncs UniFi Access visitors into Firestore.
 *
 * Fetches all visitors from the local UniFi console and upserts them
 * into /organizations/{orgId}/visitors/{visitorId}.
 */

import { getDb } from '../firebase';
import { UnifiAccessClient, UnifiVisitor } from '../unifi/access';
import { logger } from '../logger';
import * as admin from 'firebase-admin';

/**
 * Fetch all visitors from UniFi Access and upsert into Firestore.
 */
export async function syncVisitors(
  orgId: string,
  unifiClient: UnifiAccessClient
): Promise<UnifiVisitor[]> {
  const db = getDb();
  let visitors: UnifiVisitor[] = [];

  try {
    visitors = await unifiClient.getVisitors();
  } catch (err) {
    logger.error(`[VisitorSync] Failed to fetch visitors from UniFi: ${String(err)}`);
    return [];
  }

  if (visitors.length === 0) {
    logger.info('[VisitorSync] No visitors returned from UniFi Access.');
    return [];
  }

  // Preload existing visitors for this org to merge with pending documents
  const existingSnap = await db.collection(`organizations/${orgId}/visitors`).get().catch(() => null);
  const existingDocs = existingSnap?.docs || [];

  const batch = db.batch();
  const now = admin.firestore.Timestamp.now();
  const matchedDocIds = new Set<string>();

  for (const visitor of visitors) {
    const unifiId = visitor.unifi_visitor_id || visitor.id;
    if (!unifiId && !visitor.first_name) continue;

    // Check if there is already a Firestore document with this unifi_visitor_id or matching record
    let targetDocId = unifiId;
    const existingMatch = existingDocs.find((d) => {
      const data = d.data();
      if (data.unifi_visitor_id === unifiId || d.id === unifiId) return true;
      if (
        data.first_name?.toLowerCase() === visitor.first_name?.toLowerCase() &&
        (data.last_name || '').toLowerCase() === (visitor.last_name || '').toLowerCase()
      ) {
        // If pending, it's definitely our optimistic document
        if (data.sync_status === 'pending') return true;
        // Or if both share the exact start_time
        if (data.start_time && visitor.start_time && data.start_time === visitor.start_time) return true;
      }
      return false;
    });

    if (existingMatch) {
      const existingData = existingMatch.data();
      // If this visitor was revoked, do NOT revive it to active!
      // Instead, ensure it is deleted from UniFi Access and keep it revoked.
      if (existingData.status === 'revoked') {
        unifiClient.deleteVisitor(unifiId, {
          first_name: visitor.first_name,
          last_name: visitor.last_name,
          email: visitor.email,
          mobile_phone: visitor.mobile_phone,
          pin_code: visitor.pin_code,
        }).catch((e) => logger.debug(`[VisitorSync] Auto-purge revoked visitor from UniFi: ${e}`));
        matchedDocIds.add(existingMatch.id);
        continue;
      }

      targetDocId = existingMatch.id;
      // If we matched an existing doc whose Firestore document ID differs from UniFi's raw ID,
      // make sure we don't also leave an orphaned document with the raw UniFi ID
      if (existingMatch.id !== unifiId) {
        const orphanRef = db.doc(`organizations/${orgId}/visitors/${unifiId}`);
        const orphanDoc = existingDocs.find((d) => d.id === unifiId);
        if (orphanDoc) {
          batch.delete(orphanRef);
        }
      }
    }

    if (!targetDocId) continue;
    const visitorRef = db.doc(`organizations/${orgId}/visitors/${targetDocId}`);

    // Create payload, omitting undefined/null pin_code to avoid clearing existing PIN stored in Firestore
    const record: Record<string, any> = {
      id: targetDocId,
      org_id: orgId,
      unifi_visitor_id: unifiId || targetDocId,
      first_name: visitor.first_name,
      last_name: visitor.last_name || '',
      full_name: visitor.full_name || `${visitor.first_name} ${visitor.last_name || ''}`.trim(),
      door_ids: visitor.door_ids || [],
      door_labels: visitor.door_labels || [],
      start_time: visitor.start_time,
      end_time: visitor.end_time,
      status: visitor.status || 'active',
      purpose: visitor.purpose || '',
      last_synced: now,
      sync_status: 'synced',
      sync_error: null,
      updated_at: now,
    };

    if (visitor.mobile_phone) record.mobile_phone = visitor.mobile_phone;
    if (visitor.email) record.email = visitor.email;
    if (visitor.pin_code) record.pin_code = visitor.pin_code;
    if (visitor.raw_data) {
      try {
        record.raw_data_json = JSON.stringify(visitor.raw_data);
      } catch {}
    }

    matchedDocIds.add(targetDocId);
    batch.set(visitorRef, record, { merge: true });
  }

  // Check for stale pending visitors (older than 2 minutes that were not found in UniFi)
  const twoMinutesAgoMs = Date.now() - 2 * 60 * 1000;
  for (const doc of existingDocs) {
    if (matchedDocIds.has(doc.id)) continue;
    const data = doc.data();
    if (data.sync_status === 'pending') {
      const updatedAtMs = data.updated_at ? new Date(data.updated_at).getTime() : 0;
      if (updatedAtMs < twoMinutesAgoMs) {
        batch.set(
          doc.ref,
          {
            sync_status: 'failed',
            sync_error: 'Visitor creation timed out or failed to sync with UniFi Access. Please edit and save to retry.',
          },
          { merge: true }
        );
      }
    }
  }

  try {
    await batch.commit();
    logger.info(`[VisitorSync] Synced ${visitors.length} visitor(s) for org: ${orgId}`);
  } catch (err) {
    logger.error(`[VisitorSync] Batch write failed: ${String(err)}`);
  }

  return visitors;
}

/**
 * Start a recurring visitor sync on a fixed interval.
 */
export function startVisitorSyncInterval(
  orgId: string,
  unifiClient: UnifiAccessClient,
  intervalMs: number
): () => void {
  logger.info(
    `[VisitorSync] Starting visitor sync interval — every ${intervalMs / 1000}s for org: ${orgId}`
  );

  const handle = setInterval(() => {
    syncVisitors(orgId, unifiClient).catch((err) => {
      logger.error(`[VisitorSync] Unhandled error in visitor sync interval: ${String(err)}`);
    });
  }, intervalMs);

  if (handle.unref) handle.unref();

  return () => {
    clearInterval(handle);
    logger.info('[VisitorSync] Visitor sync interval stopped.');
  };
}
