"use strict";
/**
 * firebase/updateChecker.ts
 * OTA (over-the-air) update checker for the local agent.
 *
 * On startup and on a configurable interval, checks Firestore for the latest
 * published agent release. If a newer version is available, downloads the
 * dist zip from the provided URL and stages it for application.
 *
 * The update is NOT auto-applied — the web UI surfaces it so the operator
 * can click "Apply Update", which calls applyPendingUpdate() and restarts.
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.getUpdateState = getUpdateState;
exports.checkForUpdate = checkForUpdate;
exports.applyPendingUpdate = applyPendingUpdate;
exports.startUpdateChecker = startUpdateChecker;
const fs = __importStar(require("fs"));
const path = __importStar(require("path"));
const https = __importStar(require("https"));
const http = __importStar(require("http"));
const child_process_1 = require("child_process");
const os = __importStar(require("os"));
const admin = __importStar(require("firebase-admin"));
const firebase_1 = require("../firebase");
const logger_1 = require("../logger");
// ---------------------------------------------------------------------------
// Module-level state (read by web server)
// ---------------------------------------------------------------------------
function readCurrentVersion() {
    if (process.env.AGENT_VERSION)
        return process.env.AGENT_VERSION;
    if (process.env.npm_package_version)
        return process.env.npm_package_version;
    try {
        const candidates = [
            path.resolve(__dirname, '../../package.json'),
            path.resolve(__dirname, '../package.json'),
            path.resolve(process.cwd(), 'package.json'),
        ];
        for (const p of candidates) {
            if (fs.existsSync(p)) {
                const pkg = JSON.parse(fs.readFileSync(p, 'utf-8'));
                if (pkg.version)
                    return pkg.version;
            }
        }
    }
    catch { }
    return '1.1.1';
}
let _state = {
    currentVersion: readCurrentVersion(),
    latestVersion: null,
    updateAvailable: false,
    changelog: '',
    downloadUrl: null,
    lastChecked: null,
    applying: false,
    error: null,
};
function getUpdateState() {
    return { ..._state };
}
// ---------------------------------------------------------------------------
// Semver comparison
// ---------------------------------------------------------------------------
function parseVersion(v) {
    const parts = String(v).replace(/^v/, '').split('.').map(Number);
    return [parts[0] || 0, parts[1] || 0, parts[2] || 0];
}
function isNewer(candidate, current) {
    const [cMaj, cMin, cPat] = parseVersion(candidate);
    const [eMaj, eMin, ePat] = parseVersion(current);
    if (cMaj !== eMaj)
        return cMaj > eMaj;
    if (cMin !== eMin)
        return cMin > eMin;
    return cPat > ePat;
}
// ---------------------------------------------------------------------------
// Check for update
// ---------------------------------------------------------------------------
async function checkForUpdate(agentId) {
    try {
        const db = (0, firebase_1.getDb)();
        const snap = await db.doc('agent_releases/latest').get();
        if (!snap.exists) {
            _state = { ..._state, latestVersion: null, updateAvailable: false, lastChecked: new Date(), error: null };
            if (agentId) {
                await db.doc(`agents/${agentId}`).set({
                    update_available: false,
                    latest_version: _state.currentVersion,
                    current_version: _state.currentVersion,
                    update_checked_at: admin.firestore.Timestamp.now(),
                }, { merge: true }).catch(() => { });
            }
            return getUpdateState();
        }
        const data = snap.data();
        const latestVersion = String(data.version || '');
        const downloadUrl = String(data.download_url || '');
        const changelog = String(data.changelog || '');
        const updateAvailable = isNewer(latestVersion, _state.currentVersion);
        _state = {
            ..._state,
            latestVersion,
            updateAvailable,
            changelog,
            downloadUrl: updateAvailable ? downloadUrl : null,
            lastChecked: new Date(),
            error: null,
        };
        if (agentId) {
            await db.doc(`agents/${agentId}`).set({
                update_available: updateAvailable,
                latest_version: latestVersion,
                current_version: _state.currentVersion,
                update_changelog: changelog,
                update_checked_at: admin.firestore.Timestamp.now(),
                update_status: updateAvailable ? (_state.applying ? 'applying' : 'idle') : 'idle',
            }, { merge: true }).catch(() => { });
        }
        if (updateAvailable) {
            logger_1.logger.info(`[UpdateChecker] Update available: ${_state.currentVersion} → ${latestVersion}`);
        }
        else {
            logger_1.logger.debug(`[UpdateChecker] Up to date (v${_state.currentVersion})`);
        }
    }
    catch (err) {
        const msg = String(err);
        logger_1.logger.warn(`[UpdateChecker] Check failed: ${msg}`);
        _state = { ..._state, lastChecked: new Date(), error: msg };
    }
    return getUpdateState();
}
// ---------------------------------------------------------------------------
// Download helper
// ---------------------------------------------------------------------------
function downloadFile(url, destPath) {
    return new Promise((resolve, reject) => {
        const file = fs.createWriteStream(destPath);
        const protocol = url.startsWith('https') ? https : http;
        const agent = new (require('https').Agent)({ rejectUnauthorized: false });
        protocol.get(url, { agent }, (res) => {
            if (res.statusCode !== 200) {
                file.close();
                fs.unlinkSync(destPath);
                return reject(new Error(`Download failed with HTTP ${res.statusCode}`));
            }
            res.pipe(file);
            file.on('finish', () => { file.close(); resolve(); });
        }).on('error', (err) => {
            file.close();
            try {
                fs.unlinkSync(destPath);
            }
            catch { }
            reject(err);
        });
    });
}
// ---------------------------------------------------------------------------
// Apply pending update
// ---------------------------------------------------------------------------
async function applyPendingUpdate(onRestart, agentId) {
    if (!_state.updateAvailable || !_state.downloadUrl) {
        throw new Error('No update available to apply.');
    }
    if (_state.applying) {
        throw new Error('Update is already being applied.');
    }
    _state = { ..._state, applying: true, error: null };
    const downloadUrl = _state.downloadUrl;
    const targetVersion = _state.latestVersion;
    logger_1.logger.info(`[UpdateChecker] Applying update v${targetVersion} from ${downloadUrl}…`);
    if (agentId) {
        const db = (0, firebase_1.getDb)();
        await db.doc(`agents/${agentId}`).set({
            update_status: 'downloading',
            update_error: null,
        }, { merge: true }).catch(() => { });
    }
    try {
        // 1. Create temp staging directory
        const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'agent-update-'));
        const zipPath = path.join(tmpDir, 'dist.zip');
        const extractDir = path.join(tmpDir, 'extracted');
        fs.mkdirSync(extractDir, { recursive: true });
        // 2. Download zip
        logger_1.logger.info(`[UpdateChecker] Downloading update zip…`);
        await downloadFile(downloadUrl, zipPath);
        logger_1.logger.info(`[UpdateChecker] Download complete (${Math.round(fs.statSync(zipPath).size / 1024)} KB)`);
        if (agentId) {
            const db = (0, firebase_1.getDb)();
            await db.doc(`agents/${agentId}`).set({
                update_status: 'applying',
            }, { merge: true }).catch(() => { });
        }
        // 3. Extract zip directly into dist directory
        const distDir = path.resolve(__dirname, '..');
        logger_1.logger.info(`[UpdateChecker] Installing update directly to ${distDir}…`);
        (0, child_process_1.execSync)(`unzip -o "${zipPath}" -d "${distDir}"`, { stdio: 'pipe' });
        // 4. Update package.json version if found
        try {
            const candidates = [
                path.resolve(distDir, '../package.json'),
                path.resolve(distDir, '../../package.json'),
                path.resolve(process.cwd(), 'package.json'),
            ];
            for (const p of candidates) {
                if (fs.existsSync(p)) {
                    const pkg = JSON.parse(fs.readFileSync(p, 'utf-8'));
                    pkg.version = targetVersion;
                    fs.writeFileSync(p, JSON.stringify(pkg, null, 2), 'utf-8');
                }
            }
        }
        catch { }
        // 5. Cleanup temp
        fs.rmSync(tmpDir, { recursive: true, force: true });
        logger_1.logger.info(`[UpdateChecker] Update v${targetVersion} installed successfully. Restarting…`);
        _state = { ..._state, applying: false, currentVersion: targetVersion, updateAvailable: false };
        if (agentId) {
            const db = (0, firebase_1.getDb)();
            await db.doc(`agents/${agentId}`).set({
                version: targetVersion,
                current_version: targetVersion,
                update_available: false,
                update_status: 'restarting',
                update_approved_version: null,
            }, { merge: true }).catch(() => { });
        }
        // 6. Restart
        if (onRestart) {
            await onRestart();
        }
        else {
            setTimeout(() => process.exit(0), 500);
        }
    }
    catch (err) {
        const msg = String(err);
        logger_1.logger.error(`[UpdateChecker] Update failed: ${msg}`);
        _state = { ..._state, applying: false, error: msg };
        if (agentId) {
            const db = (0, firebase_1.getDb)();
            await db.doc(`agents/${agentId}`).set({
                update_status: 'error',
                update_error: msg,
            }, { merge: true }).catch(() => { });
        }
        throw err;
    }
}
// ---------------------------------------------------------------------------
// Start periodic check interval & remote approval listener
// ---------------------------------------------------------------------------
function startUpdateChecker(agentId, orgId, intervalMs = 60 * 1000, onRestart) {
    // Set current version from package.json
    try {
        const pkgPath = path.resolve(__dirname, '../../package.json');
        if (fs.existsSync(pkgPath)) {
            const pkg = JSON.parse(fs.readFileSync(pkgPath, 'utf-8'));
            _state.currentVersion = pkg.version || _state.currentVersion;
        }
    }
    catch { }
    logger_1.logger.info(`[UpdateChecker] Starting — current version: v${_state.currentVersion}, poll interval: ${intervalMs / 1000}s`);
    // Check immediately on startup
    checkForUpdate(agentId).catch(() => { });
    // Periodic poll interval
    const handle = setInterval(() => {
        checkForUpdate(agentId).catch(() => { });
    }, intervalMs);
    let unsubSnapshot = null;
    // Real-time listener on agents/{agentId} for remote approval from app
    if (agentId) {
        try {
            const db = (0, firebase_1.getDb)();
            unsubSnapshot = db.doc(`agents/${agentId}`).onSnapshot(async (snap) => {
                if (!snap.exists)
                    return;
                const data = snap.data();
                const approvedVersion = data?.update_approved_version;
                const autoUpdate = Boolean(data?.auto_update);
                // Ensure we have current release data
                if (!_state.latestVersion) {
                    await checkForUpdate(agentId);
                }
                if (!_state.applying &&
                    _state.updateAvailable &&
                    _state.downloadUrl &&
                    _state.latestVersion &&
                    (approvedVersion === _state.latestVersion || autoUpdate) &&
                    isNewer(_state.latestVersion, _state.currentVersion)) {
                    logger_1.logger.info(`[UpdateChecker] 🚀 Auto-deploying approved update: v${_state.currentVersion} → v${_state.latestVersion}…`);
                    try {
                        await applyPendingUpdate(onRestart, agentId);
                    }
                    catch (err) {
                        logger_1.logger.error(`[UpdateChecker] Remote auto-deploy failed: ${err.message}`);
                    }
                }
            });
        }
        catch (err) {
            logger_1.logger.warn(`[UpdateChecker] Failed to attach agent document listener: ${err.message}`);
        }
    }
    if (handle.unref)
        handle.unref();
    return () => {
        clearInterval(handle);
        if (unsubSnapshot)
            unsubSnapshot();
        logger_1.logger.info('[UpdateChecker] Stopped.');
    };
}
