"use strict";
/**
 * firebase/visitorSync.ts
 * Syncs UniFi Access visitors into Firestore.
 *
 * Fetches all visitors from the local UniFi console and upserts them
 * into /organizations/{orgId}/visitors/{visitorId}.
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.syncVisitors = syncVisitors;
exports.startVisitorSyncInterval = startVisitorSyncInterval;
const firebase_1 = require("../firebase");
const logger_1 = require("../logger");
const admin = __importStar(require("firebase-admin"));
/**
 * Fetch all visitors from UniFi Access and upsert into Firestore.
 */
async function syncVisitors(orgId, unifiClient) {
    const db = (0, firebase_1.getDb)();
    let visitors = [];
    try {
        visitors = await unifiClient.getVisitors();
    }
    catch (err) {
        logger_1.logger.error(`[VisitorSync] Failed to fetch visitors from UniFi: ${String(err)}`);
        return [];
    }
    if (visitors.length === 0) {
        logger_1.logger.info('[VisitorSync] No visitors returned from UniFi Access.');
        return [];
    }
    const batch = db.batch();
    const now = admin.firestore.Timestamp.now();
    for (const visitor of visitors) {
        if (!visitor.id)
            continue;
        const visitorRef = db.doc(`organizations/${orgId}/visitors/${visitor.id}`);
        // Create payload, omitting undefined/null pin_code to avoid clearing existing PIN stored in Firestore
        const record = {
            id: visitor.id,
            org_id: orgId,
            unifi_visitor_id: visitor.unifi_visitor_id || visitor.id,
            first_name: visitor.first_name,
            last_name: visitor.last_name || '',
            full_name: visitor.full_name || `${visitor.first_name} ${visitor.last_name || ''}`.trim(),
            door_ids: visitor.door_ids || [],
            door_labels: visitor.door_labels || [],
            start_time: visitor.start_time,
            end_time: visitor.end_time,
            status: visitor.status || 'active',
            purpose: visitor.purpose || '',
            last_synced: now,
            sync_status: 'synced',
            sync_error: null,
            updated_at: now,
        };
        if (visitor.mobile_phone)
            record.mobile_phone = visitor.mobile_phone;
        if (visitor.email)
            record.email = visitor.email;
        if (visitor.pin_code)
            record.pin_code = visitor.pin_code;
        if (visitor.raw_data)
            record.raw_data = visitor.raw_data;
        batch.set(visitorRef, record, { merge: true });
    }
    try {
        await batch.commit();
        logger_1.logger.info(`[VisitorSync] Synced ${visitors.length} visitor(s) for org: ${orgId}`);
    }
    catch (err) {
        logger_1.logger.error(`[VisitorSync] Batch write failed: ${String(err)}`);
    }
    return visitors;
}
/**
 * Start a recurring visitor sync on a fixed interval.
 */
function startVisitorSyncInterval(orgId, unifiClient, intervalMs) {
    logger_1.logger.info(`[VisitorSync] Starting visitor sync interval — every ${intervalMs / 1000}s for org: ${orgId}`);
    const handle = setInterval(() => {
        syncVisitors(orgId, unifiClient).catch((err) => {
            logger_1.logger.error(`[VisitorSync] Unhandled error in visitor sync interval: ${String(err)}`);
        });
    }, intervalMs);
    if (handle.unref)
        handle.unref();
    return () => {
        clearInterval(handle);
        logger_1.logger.info('[VisitorSync] Visitor sync interval stopped.');
    };
}
