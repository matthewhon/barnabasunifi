"use strict";
/**
 * firebase/doorSync.ts
 * Syncs UniFi Access door state into Firestore.
 *
 * Fetches all doors from the local UniFi console and upserts their current
 * state into /organizations/{orgId}/doors/{doorId}. Runs on an interval to
 * keep the cloud dashboard in sync with physical door states.
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.syncDoors = syncDoors;
exports.startDoorSyncInterval = startDoorSyncInterval;
const firebase_1 = require("../firebase");
const logger_1 = require("../logger");
const admin = __importStar(require("firebase-admin"));
// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------
/**
 * Map the UniFi `door_lock_relay_status` field to a normalized state string.
 */
function normalizeDoorState(relayStatus) {
    switch (relayStatus) {
        case 'lock':
            return 'locked';
        case 'unlock':
            return 'unlocked';
        default:
            return 'unknown';
    }
}
// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------
/**
 * Fetch all doors from UniFi Access and upsert their state into Firestore.
 *
 * @param orgId       - Firestore organization document ID
 * @param unifiClient - Initialized UniFi Access API client
 */
async function syncDoors(orgId, unifiClient) {
    const db = (0, firebase_1.getDb)();
    let doors;
    try {
        doors = await unifiClient.getDoors();
    }
    catch (err) {
        logger_1.logger.error(`[DoorSync] Failed to fetch doors from UniFi: ${String(err)}`);
        return;
    }
    if (doors.length === 0) {
        logger_1.logger.warn('[DoorSync] No doors returned from UniFi Access — nothing to sync.');
        return;
    }
    const batch = db.batch();
    const now = admin.firestore.Timestamp.now();
    for (const door of doors) {
        const doorRef = db.doc(`organizations/${orgId}/doors/${door.id}`);
        const record = {
            unifi_door_id: door.id,
            label: door.full_name ?? door.name ?? door.id,
            current_state: normalizeDoorState(door.door_lock_relay_status),
            door_position_status: door.door_position_status ?? null,
            device_state: door.device_state ?? null,
            last_synced: now,
            org_id: orgId,
        };
        // set with merge:true so we don't overwrite fields managed by the web app
        batch.set(doorRef, record, { merge: true });
    }
    try {
        await batch.commit();
        logger_1.logger.info(`[DoorSync] Synced ${doors.length} door(s) for org: ${orgId}`);
    }
    catch (err) {
        logger_1.logger.error(`[DoorSync] Batch write failed: ${String(err)}`);
    }
}
/**
 * Start a recurring door sync on a fixed interval.
 *
 * Runs an initial sync immediately, then repeats every `intervalMs` ms.
 * Returns a cleanup function that stops the interval.
 *
 * @param orgId       - Firestore organization document ID
 * @param unifiClient - Initialized UniFi Access API client
 * @param intervalMs  - Sync frequency in milliseconds (default: 5 minutes)
 */
function startDoorSyncInterval(orgId, unifiClient, intervalMs) {
    logger_1.logger.info(`[DoorSync] Starting door sync interval — every ${intervalMs / 1000}s for org: ${orgId}`);
    const handle = setInterval(() => {
        syncDoors(orgId, unifiClient).catch((err) => {
            logger_1.logger.error(`[DoorSync] Unhandled error in sync interval: ${String(err)}`);
        });
    }, intervalMs);
    // Allow the Node.js process to exit even if this interval is active
    if (handle.unref)
        handle.unref();
    return () => {
        clearInterval(handle);
        logger_1.logger.info('[DoorSync] Door sync interval stopped.');
    };
}
