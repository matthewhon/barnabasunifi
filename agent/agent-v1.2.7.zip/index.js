"use strict";
/**
 * index.ts
 * Main entry point for the UnFi-PCO Local Agent.
 *
 * Boots an always-on Web Configuration & Management Portal on port 8080.
 * If credentials and configuration are present, starts the background bridge worker.
 * If configuration is incomplete, stays alive in setup mode and allows configuration
 * via the web portal.
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
require("dotenv/config");
const config_1 = require("./config");
const logger_1 = require("./logger");
const firebase_1 = require("./firebase");
const access_1 = require("./unifi/access");
const heartbeat_1 = require("./firebase/heartbeat");
const doorSync_1 = require("./firebase/doorSync");
const scheduleSync_1 = require("./firebase/scheduleSync");
const visitorSync_1 = require("./firebase/visitorSync");
const accessLogSync_1 = require("./firebase/accessLogSync");
const userSync_1 = require("./firebase/userSync");
const commandListener_1 = require("./firebase/commandListener");
const updateChecker_1 = require("./firebase/updateChecker");
const server_1 = require("./web/server");
const scanner_1 = require("./web/scanner");
const cacheStore_1 = require("./storage/cacheStore");
const localScheduler_1 = require("./scheduler/localScheduler");
const scheduleWindowSync_1 = require("./firebase/scheduleWindowSync");
const reconciliation_1 = require("./firebase/reconciliation");
const axios_1 = __importDefault(require("axios"));
const admin = __importStar(require("firebase-admin"));
// ---------------------------------------------------------------------------
// Lifecycle State
// ---------------------------------------------------------------------------
let cleanupPreviousWorker = null;
const bridgeState = {
    status: 'unconfigured',
    unifiConnected: false,
    firebaseConnected: false,
    doorCount: 0,
    lastSync: null,
    offlineMode: false,
    cachedWindowsCount: 0,
    pendingOfflineActionsCount: 0,
    onRestartRequest: async () => {
        logger_1.logger.info('[Bridge] Reload/restart requested — exiting process for supervisor/Docker reboot…');
        setTimeout(() => {
            process.exit(0);
        }, 500);
    },
};
/**
 * Automatically exchange CONNECTION_TOKEN with Cloud Functions to configure the agent.
 */
async function attemptAutoRegistration(connectionToken) {
    try {
        const base64Str = connectionToken.replace(/^UPCO_/, '').trim();
        const raw = Buffer.from(base64Str, 'base64').toString('utf-8');
        const parsed = JSON.parse(raw);
        const endpoint = parsed.endpoint ||
            `https://us-central1-${parsed.projectId || 'barnabasunfi'}.cloudfunctions.net/registerAgentWithToken`;
        logger_1.logger.info(`[AutoRegister] Discovered CONNECTION_TOKEN. Contacting pairing endpoint: ${endpoint}…`);
        const response = await axios_1.default.post(endpoint, {
            token: connectionToken,
            agentId: process.env.AGENT_ID || 'agent-main-campus',
            label: process.env.AGENT_LABEL || 'Main Campus Agent',
            unifiHost: process.env.UNIFI_HOST || '',
            version: process.env.npm_package_version || '1.0.0',
        }, { timeout: 15000 });
        if (response.data?.ok) {
            const { orgId, customToken, projectId, unifiHost, unifiAccessToken, unifiApiKey, skipTlsVerify } = response.data;
            logger_1.logger.info(`[AutoRegister] ✓ Paired successfully with Organization: ${orgId}`);
            (0, config_1.saveConfig)({
                ORG_ID: orgId,
                FIREBASE_PROJECT_ID: projectId || 'barnabasunfi',
                AGENT_AUTH_TOKEN: customToken,
                ...(unifiHost ? { UNIFI_HOST: unifiHost } : {}),
                ...(unifiAccessToken ? { UNIFI_ACCESS_TOKEN: unifiAccessToken } : {}),
                ...(unifiApiKey ? { UNIFI_API_KEY: unifiApiKey } : {}),
                ...(skipTlsVerify !== undefined ? { SKIP_TLS_VERIFY: String(skipTlsVerify) } : {}),
            });
            return true;
        }
        else {
            logger_1.logger.warn(`[AutoRegister] Pairing failed: ${response.data?.error || 'Unknown error'}`);
        }
    }
    catch (err) {
        const msg = err.response?.data?.error || err.message;
        logger_1.logger.warn(`[AutoRegister] Pairing handshake error: ${msg}`);
    }
    return false;
}
// ---------------------------------------------------------------------------
// Worker Launcher
// ---------------------------------------------------------------------------
async function startBridgeWorker() {
    // Stop existing worker if one was running
    if (cleanupPreviousWorker) {
        try {
            cleanupPreviousWorker();
        }
        catch (err) {
            logger_1.logger.warn(`[Bridge] Error cleaning up previous worker: ${err}`);
        }
        cleanupPreviousWorker = null;
    }
    let configStatus = (0, config_1.getConfigurationStatus)();
    // 1. If not yet fully configured but Connection Token is present, attempt auto-pairing handshake
    if (!configStatus.isConfigured && configStatus.canAutoRegister) {
        const token = process.env.CONNECTION_TOKEN || configStatus.config?.connectionToken;
        if (token) {
            await attemptAutoRegistration(token);
            configStatus = (0, config_1.getConfigurationStatus)();
        }
    }
    // 2. If token is present but host is missing, auto-scan local subnets to discover console
    if (!configStatus.isConfigured &&
        process.env.UNIFI_ACCESS_TOKEN &&
        (!process.env.UNIFI_HOST || configStatus.missing.some((m) => m.startsWith('UNIFI_HOST')))) {
        logger_1.logger.info('[Bridge] UniFi Host URL not set. Scanning local network for UniFi Access console…');
        const discovered = await (0, scanner_1.autoDiscoverUnifiConsole)(process.env.UNIFI_ACCESS_TOKEN);
        if (discovered) {
            logger_1.logger.info(`[Bridge] Discovered UniFi Access console on LAN at: ${discovered}`);
            (0, config_1.saveConfig)({ UNIFI_HOST: discovered });
            configStatus = (0, config_1.getConfigurationStatus)();
        }
    }
    if (!configStatus.isConfigured || !configStatus.config) {
        bridgeState.status = 'unconfigured';
        bridgeState.unifiConnected = false;
        bridgeState.firebaseConnected = false;
        bridgeState.errorMessage = `Missing: ${configStatus.missing.join(', ')}`;
        logger_1.logger.warn(`⚠️ Agent is unconfigured (${bridgeState.errorMessage}). ` +
            `Open http://localhost:${process.env.PORT || 8080} to configure.`);
        return;
    }
    const config = configStatus.config;
    (0, logger_1.setLogLevel)(config.logLevel);
    logger_1.logger.info('═══════════════════════════════════════════════');
    logger_1.logger.info('  UnFi-PCO Local Agent');
    logger_1.logger.info(`  Version : ${config.version}`);
    logger_1.logger.info(`  Org     : ${config.orgId}`);
    logger_1.logger.info(`  Agent   : ${config.agentId} (${config.agentLabel})`);
    logger_1.logger.info(`  UniFi   : ${config.unifiHost || '(Scanning network...)'}`);
    logger_1.logger.info('═══════════════════════════════════════════════');
    bridgeState.status = 'starting';
    const cacheStore = (0, cacheStore_1.getCacheStore)();
    cacheStore.setOrgId(config.orgId);
    bridgeState.cachedWindowsCount = cacheStore.getScheduleWindows().length;
    bridgeState.pendingOfflineActionsCount = cacheStore.getPendingOfflineActions().length;
    // 1. Initialize UniFi Access client over LAN first
    const unifiClient = new access_1.UnifiAccessClient(config.unifiHost, config.unifiAccessToken, config.skipTlsVerify, config.unifiApiKey);
    // 2. Test UniFi connectivity on LAN with auto-discovery fallback
    logger_1.logger.info('Testing UniFi Access connection on LAN…');
    try {
        let connected = await unifiClient.testConnection();
        if (!connected) {
            logger_1.logger.warn(`[Bridge] Could not connect to configured host (${config.unifiHost}). Scanning LAN for active console…`);
            const discovered = await (0, scanner_1.autoDiscoverUnifiConsole)(config.unifiAccessToken);
            if (discovered && discovered !== config.unifiHost) {
                logger_1.logger.info(`[Bridge] Discovered active console on LAN at: ${discovered}. Connecting…`);
                config.unifiHost = discovered;
                (0, config_1.saveConfig)({ UNIFI_HOST: discovered });
                unifiClient.updateCredentials(discovered, config.unifiAccessToken, config.skipTlsVerify, config.unifiApiKey);
                connected = await unifiClient.testConnection();
            }
        }
        if (!connected) {
            bridgeState.status = 'error';
            bridgeState.unifiConnected = false;
            bridgeState.errorMessage = 'Could not connect to UniFi Access API on LAN. Check host & token.';
            logger_1.logger.error('[Bridge] Could not connect to UniFi Access API. ' +
                'Check UNIFI_HOST, UNIFI_ACCESS_TOKEN, and network reachability.');
            return;
        }
        bridgeState.unifiConnected = true;
        // Update door count from local UniFi console or cached doors
        try {
            const liveDoors = await unifiClient.getDoors();
            bridgeState.doorCount = liveDoors.length;
        }
        catch {
            bridgeState.doorCount = cacheStore.getDoors().length;
        }
    }
    catch (err) {
        bridgeState.status = 'error';
        bridgeState.unifiConnected = false;
        bridgeState.errorMessage = `UniFi connection error: ${err.message}`;
        logger_1.logger.error(`[Bridge] UniFi connection error: ${err.message}`);
        return;
    }
    // 3. Start Local Autonomous Scheduler
    // Runs continuously regardless of online/offline status, triggering LAN unlocks/locks
    const localScheduler = new localScheduler_1.LocalScheduler(config.orgId, config.agentId, unifiClient, () => bridgeState.firebaseConnected);
    localScheduler.start(10000);
    bridgeState.getNextUpcomingActions = () => localScheduler.getNextUpcomingActions();
    // 4. Manage Firebase Online Workers & Connection State
    let stopOnlineWorkers = null;
    let reconnectInterval = null;
    async function startOnlineWorkers() {
        if (stopOnlineWorkers) {
            try {
                stopOnlineWorkers();
            }
            catch { }
            stopOnlineWorkers = null;
        }
        const db = (0, firebase_1.getDb)();
        bridgeState.firebaseConnected = true;
        bridgeState.offlineMode = false;
        bridgeState.status = 'running';
        bridgeState.errorMessage = undefined;
        // Reconcile any actions executed while offline
        try {
            const reconciled = await (0, reconciliation_1.reconcileOfflineActions)(config.orgId, config.agentId);
            bridgeState.pendingOfflineActionsCount = cacheStore.getPendingOfflineActions().length;
            if (reconciled > 0) {
                logger_1.logger.info(`[Bridge] Reconciled ${reconciled} offline action(s) to Firestore.`);
            }
        }
        catch (recErr) {
            logger_1.logger.warn(`[Bridge] Offline reconciliation notice: ${String(recErr)}`);
        }
        // Register / update agent document in Firestore
        try {
            await db.doc(`agents/${config.agentId}`).set({
                org_id: config.orgId,
                label: config.agentLabel,
                version: config.version,
                status: 'online',
                registered_at: admin.firestore.Timestamp.now(),
                unifi_host: config.unifiHost,
                capabilities: ['unlock', 'lock', 'door_sync'],
                offline_resilience: {
                    cached_windows: cacheStore.getScheduleWindows().length,
                    last_cache_sync: cacheStore.getCache().last_sync,
                    mode: 'autonomous_lan',
                },
            }, { merge: true });
            logger_1.logger.info(`Agent document registered: agents/${config.agentId}`);
        }
        catch (err) {
            logger_1.logger.error(`Failed to register agent document: ${String(err)}`);
        }
        // Proactive schedule window sync (14-day lookahead)
        const stopWindowSync = (0, scheduleWindowSync_1.startScheduleWindowSync)(config.orgId, (count) => {
            bridgeState.cachedWindowsCount = count;
            bridgeState.pendingOfflineActionsCount = cacheStore.getPendingOfflineActions().length;
        });
        // Start heartbeat
        const stopHeartbeat = (0, heartbeat_1.startHeartbeat)(config.orgId, config.agentId, config.agentLabel, config.version, config.heartbeatIntervalMs);
        // Start OTA update checker
        const stopUpdateChecker = (0, updateChecker_1.startUpdateChecker)(config.agentId, config.orgId, 60 * 1000, bridgeState.onRestartRequest);
        // Initial door sync & recurring
        try {
            const doors = await (0, doorSync_1.syncDoors)(config.orgId, unifiClient);
            bridgeState.doorCount = doors.length;
            bridgeState.lastSync = new Date();
        }
        catch (err) {
            logger_1.logger.error(`[DoorSync] Initial sync error: ${err.message}`);
        }
        const stopDoorSync = (0, doorSync_1.startDoorSyncInterval)(config.orgId, unifiClient, config.doorSyncIntervalMs);
        // Initial schedule sync & recurring
        try {
            const schedules = await (0, scheduleSync_1.syncSchedules)(config.orgId, unifiClient);
            logger_1.logger.info(`[ScheduleSync] Initial sync completed (${schedules.length} schedules found).`);
        }
        catch (err) {
            logger_1.logger.error(`[ScheduleSync] Initial sync error: ${err.message}`);
        }
        const stopScheduleSync = (0, scheduleSync_1.startScheduleSyncInterval)(config.orgId, unifiClient, 60 * 1000);
        // Initial access policy sync & recurring
        try {
            const policies = await (0, userSync_1.syncAccessPolicies)(config.orgId, unifiClient);
            logger_1.logger.info(`[PolicySync] Initial sync completed (${policies.length} policies found).`);
        }
        catch (err) {
            logger_1.logger.error(`[PolicySync] Initial sync error: ${err.message}`);
        }
        const stopPolicySync = (0, userSync_1.startPolicySyncInterval)(config.orgId, unifiClient, 60 * 1000);
        // Initial visitor sync & recurring
        try {
            const visitors = await (0, visitorSync_1.syncVisitors)(config.orgId, unifiClient);
            logger_1.logger.info(`[VisitorSync] Initial sync completed (${visitors.length} visitors found).`);
        }
        catch (err) {
            logger_1.logger.error(`[VisitorSync] Initial sync error: ${err.message}`);
        }
        const stopVisitorSync = (0, visitorSync_1.startVisitorSyncInterval)(config.orgId, unifiClient, 60 * 1000);
        // Initial access log sync & recurring
        try {
            const logs = await (0, accessLogSync_1.syncAccessLogs)(config.orgId, unifiClient);
            logger_1.logger.info(`[AccessLogSync] Initial sync completed (${logs.length} access logs found).`);
        }
        catch (err) {
            logger_1.logger.error(`[AccessLogSync] Initial sync error: ${err.message}`);
        }
        const stopAccessLogSync = (0, accessLogSync_1.startAccessLogSyncInterval)(config.orgId, unifiClient, 25 * 1000);
        // Start Firestore command listener
        const stopCommandListener = (0, commandListener_1.startCommandListener)(config.orgId, config.agentId, unifiClient, (cmd) => {
            logger_1.logger.debug(`[Main] Command callback — id: ${cmd.id} action: ${cmd.action} door: ${cmd.door_id}`);
        }, bridgeState.onRestartRequest);
        // Cloud settings listener
        const stopSettingsListener = db.doc(`organizations/${config.orgId}/settings/config`).onSnapshot(async (snap) => {
            if (!snap.exists)
                return;
            const data = snap.data();
            const unifiConfig = data?.unifi_agent || data?.unifi_remote;
            if (!unifiConfig)
                return;
            let changed = false;
            if (unifiConfig.access_token && unifiConfig.access_token !== config.unifiAccessToken) {
                logger_1.logger.info('[Bridge] Detected updated UniFi Access API token in cloud settings. Updating…');
                config.unifiAccessToken = unifiConfig.access_token;
                (0, config_1.saveConfig)({ UNIFI_ACCESS_TOKEN: unifiConfig.access_token });
                changed = true;
            }
            const incomingApiKey = unifiConfig.api_key || unifiConfig.developer_api_key || '';
            if (incomingApiKey && incomingApiKey !== config.unifiApiKey) {
                logger_1.logger.info('[Bridge] Detected updated UniFi Developer API key in cloud settings. Updating…');
                config.unifiApiKey = incomingApiKey;
                (0, config_1.saveConfig)({ UNIFI_API_KEY: incomingApiKey });
                changed = true;
            }
            if (unifiConfig.host && unifiConfig.host !== config.unifiHost) {
                logger_1.logger.info(`[Bridge] Detected updated UniFi Host (${unifiConfig.host}) in cloud settings. Updating…`);
                config.unifiHost = unifiConfig.host;
                (0, config_1.saveConfig)({ UNIFI_HOST: unifiConfig.host });
                changed = true;
            }
            if (unifiConfig.skip_tls_verify !== undefined && Boolean(unifiConfig.skip_tls_verify) !== config.skipTlsVerify) {
                logger_1.logger.info(`[Bridge] Detected updated skip_tls_verify (${unifiConfig.skip_tls_verify}) in cloud settings. Updating…`);
                config.skipTlsVerify = Boolean(unifiConfig.skip_tls_verify);
                (0, config_1.saveConfig)({ SKIP_TLS_VERIFY: String(config.skipTlsVerify) });
                changed = true;
            }
            if (changed) {
                logger_1.logger.info('[Bridge] Re-applying cloud credentials to UniFi client…');
                unifiClient.updateCredentials(config.unifiHost, config.unifiAccessToken, config.skipTlsVerify, config.unifiApiKey);
                const testOk = await unifiClient.testConnection();
                bridgeState.unifiConnected = testOk;
                if (testOk) {
                    logger_1.logger.info('[Bridge] ✓ Connection verified with new credentials! Running door sync…');
                    await (0, doorSync_1.syncDoors)(config.orgId, unifiClient);
                    bridgeState.lastSync = new Date();
                }
            }
        }, (err) => {
            logger_1.logger.warn(`[Bridge] Cloud settings listener notice: ${err.message}`);
            if (err?.code === 'unavailable' || err?.message?.includes('offline') || err?.message?.includes('network')) {
                bridgeState.firebaseConnected = false;
                bridgeState.offlineMode = true;
            }
        });
        stopOnlineWorkers = () => {
            stopSettingsListener();
            stopCommandListener();
            stopAccessLogSync();
            stopVisitorSync();
            stopPolicySync();
            stopScheduleSync();
            stopDoorSync();
            stopHeartbeat();
            stopUpdateChecker();
            stopWindowSync();
        };
        logger_1.logger.info('✓ Agent cloud bridge running — listening for cloud commands and syncs.');
    }
    // 5. Initialize Firebase or enter Autonomous Offline Mode
    try {
        await (0, firebase_1.initializeFirebase)(config.firebaseServiceAccountPath, config.firebaseProjectId);
        bridgeState.firebaseConnected = true;
        bridgeState.offlineMode = false;
        await startOnlineWorkers();
    }
    catch (err) {
        bridgeState.firebaseConnected = false;
        bridgeState.offlineMode = true;
        bridgeState.status = 'running';
        bridgeState.errorMessage = undefined;
        logger_1.logger.warn(`[Bridge] ⚠️ Firebase initialization failed on startup: ${err.message}`);
        logger_1.logger.warn(`[Bridge] 🛡️ Entered Autonomous Offline Mode: ${cacheStore.getScheduleWindows().length} schedule window(s) cached locally. ` +
            `LocalScheduler will continue executing scheduled unlocks and locks over LAN!`);
        // Launch background reconnection retry loop
        reconnectInterval = setInterval(async () => {
            if (bridgeState.firebaseConnected)
                return;
            try {
                await (0, firebase_1.initializeFirebase)(config.firebaseServiceAccountPath, config.firebaseProjectId);
                logger_1.logger.info('[Bridge] ✓ Firebase connection established! Transitioning to online mode…');
                if (reconnectInterval) {
                    clearInterval(reconnectInterval);
                    reconnectInterval = null;
                }
                await startOnlineWorkers();
            }
            catch {
                // Still offline, will retry on next interval
            }
        }, 20000);
        if (reconnectInterval.unref)
            reconnectInterval.unref();
    }
    bridgeState.onSyncDoors = async () => {
        logger_1.logger.info('[Bridge] Executing on-demand door discovery sync…');
        const doors = await (0, doorSync_1.syncDoors)(config.orgId, unifiClient);
        bridgeState.doorCount = doors.length;
        bridgeState.lastSync = new Date();
        return doors.length;
    };
    cleanupPreviousWorker = () => {
        logger_1.logger.info('[Bridge] Stopping previous bridge worker…');
        bridgeState.onSyncDoors = undefined;
        bridgeState.getNextUpcomingActions = undefined;
        if (reconnectInterval) {
            clearInterval(reconnectInterval);
            reconnectInterval = null;
        }
        localScheduler.stop();
        if (stopOnlineWorkers) {
            stopOnlineWorkers();
            stopOnlineWorkers = null;
        }
    };
}
// ---------------------------------------------------------------------------
// Main
// ---------------------------------------------------------------------------
async function main() {
    const port = parseInt(process.env.PORT || '8080', 10);
    // 1. Launch the web configuration portal immediately
    (0, server_1.startWebServer)(port, bridgeState);
    // 2. Start bridge worker (will run if configured, or stay in setup mode)
    await startBridgeWorker();
    // 3. Graceful shutdown
    const shutdown = (signal) => {
        logger_1.logger.info(`Received ${signal} — shutting down gracefully.`);
        if (cleanupPreviousWorker) {
            cleanupPreviousWorker();
        }
        process.exit(0);
    };
    process.once('SIGINT', () => shutdown('SIGINT'));
    process.once('SIGTERM', () => shutdown('SIGTERM'));
}
main().catch((err) => {
    logger_1.logger.error(`[FATAL] Startup failure: ${String(err)}`);
});
