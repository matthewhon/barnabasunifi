"use strict";
/**
 * firebase/scheduleWindowSync.ts
 * Proactively caches upcoming schedule windows, org settings, and doors
 * to the local CacheStore for offline execution.
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.syncScheduleWindowsNow = syncScheduleWindowsNow;
exports.startScheduleWindowSync = startScheduleWindowSync;
const admin = __importStar(require("firebase-admin"));
const firebase_1 = require("../firebase");
const logger_1 = require("../logger");
const cacheStore_1 = require("../storage/cacheStore");
/**
 * Safely parse a Firestore Timestamp, Date, or string into an ISO 8601 string.
 */
function toIsoString(val) {
    if (!val)
        return new Date().toISOString();
    if (typeof val.toDate === 'function') {
        return val.toDate().toISOString();
    }
    if (val instanceof Date) {
        return isNaN(val.getTime()) ? new Date().toISOString() : val.toISOString();
    }
    if (typeof val === 'object' && ('_seconds' in val || 'seconds' in val)) {
        const sec = val._seconds ?? val.seconds;
        const nano = val._nanoseconds ?? val.nanoseconds ?? 0;
        return new Date(sec * 1000 + Math.floor(nano / 1000000)).toISOString();
    }
    if (typeof val === 'string' || typeof val === 'number') {
        const parsed = new Date(val);
        return isNaN(parsed.getTime()) ? new Date().toISOString() : parsed.toISOString();
    }
    return new Date().toISOString();
}
/**
 * One-shot sync of schedule windows, settings, and doors into local cache.
 */
async function syncScheduleWindowsNow(orgId) {
    const db = (0, firebase_1.getDb)();
    const cacheStore = (0, cacheStore_1.getCacheStore)();
    cacheStore.setOrgId(orgId);
    try {
        // 1. Sync settings
        const settingsDoc = await db.doc(`organizations/${orgId}/settings/config`).get();
        if (settingsDoc.exists) {
            const data = settingsDoc.data() || {};
            const unifiConfig = data.unifi_agent || data.unifi_remote || {};
            cacheStore.updateSettings({
                timezone: data.timezone || 'UTC',
                unlock_buffer_before_min: data.unlock_buffer_before_min ?? 15,
                lock_buffer_after_min: data.lock_buffer_after_min ?? 15,
                lock_timing_mode: data.lock_timing_mode || 'after_end',
                lock_after_start_min: data.lock_after_start_min ?? 15,
                unifi_host: unifiConfig.host,
                unifi_access_token: unifiConfig.access_token,
                unifi_api_key: unifiConfig.api_key || unifiConfig.developer_api_key,
            });
        }
        // 2. Sync doors
        const doorsSnap = await db.collection(`organizations/${orgId}/doors`).get();
        const cachedDoors = doorsSnap.docs.map((doc) => {
            const d = doc.data();
            return {
                id: doc.id,
                name: d.label || d.name || doc.id,
                unifi_door_id: d.unifi_door_id || doc.id,
                current_state: d.current_state || 'unknown',
                is_held_unlocked: d.is_held_unlocked || false,
            };
        });
        cacheStore.updateDoors(cachedDoors);
        // 3. Sync schedule windows for the next 14 days (and windows from the last 2 hours to avoid dropping currently active events)
        const twoHoursAgo = admin.firestore.Timestamp.fromMillis(Date.now() - 2 * 60 * 60 * 1000);
        const fourteenDaysAhead = admin.firestore.Timestamp.fromMillis(Date.now() + 14 * 24 * 60 * 60 * 1000);
        const windowsSnap = await db
            .collection(`organizations/${orgId}/schedule_windows`)
            .where('lock_at', '>=', twoHoursAgo)
            .where('unlock_at', '<=', fourteenDaysAhead)
            .get();
        const cachedWindows = [];
        for (const doc of windowsSnap.docs) {
            const d = doc.data();
            if (!d)
                continue;
            const doorIds = Array.isArray(d.door_ids) ? d.door_ids : [];
            if (doorIds.length === 0)
                continue;
            let doorTimings;
            if (d.door_timings && typeof d.door_timings === 'object') {
                doorTimings = {};
                for (const [doorId, t] of Object.entries(d.door_timings)) {
                    if (t && typeof t === 'object') {
                        doorTimings[doorId] = {
                            unlock_at: toIsoString(t.unlock_at),
                            lock_at: toIsoString(t.lock_at),
                            unlock_offset_min: t.unlock_offset_min,
                            lock_offset_min: t.lock_offset_min,
                            lock_timing_mode: t.lock_timing_mode,
                        };
                    }
                }
            }
            cachedWindows.push({
                id: doc.id,
                org_id: orgId,
                source_label: String(d.source_label || d.title || 'Scheduled Window'),
                starts_at: toIsoString(d.starts_at),
                ends_at: toIsoString(d.ends_at),
                unlock_at: toIsoString(d.unlock_at),
                lock_at: toIsoString(d.lock_at),
                lock_timing_mode: d.lock_timing_mode,
                door_ids: doorIds,
                door_labels: Array.isArray(d.door_labels) ? d.door_labels : [],
                door_timings: doorTimings,
                status: d.status || 'pending',
            });
        }
        cacheStore.updateScheduleWindows(cachedWindows);
        logger_1.logger.info(`[ScheduleWindowSync] Successfully synced ${cachedWindows.length} upcoming window(s) and ${cachedDoors.length} door(s) to local cache.`);
        return cachedWindows.length;
    }
    catch (err) {
        logger_1.logger.warn(`[ScheduleWindowSync] One-shot sync notice: ${String(err)}`);
        return 0;
    }
}
/**
 * Start real-time listeners for schedule windows, settings, and doors.
 * Returns a cleanup function to unsubscribe listeners.
 */
function startScheduleWindowSync(orgId, onCacheUpdated) {
    const db = (0, firebase_1.getDb)();
    const cacheStore = (0, cacheStore_1.getCacheStore)();
    cacheStore.setOrgId(orgId);
    logger_1.logger.info(`[ScheduleWindowSync] Starting proactive schedule caching for org: ${orgId}`);
    // Run initial one-shot sync immediately
    void syncScheduleWindowsNow(orgId).then((count) => {
        onCacheUpdated?.(count);
    });
    // 1. Settings listener
    const unsubSettings = db.doc(`organizations/${orgId}/settings/config`).onSnapshot((snap) => {
        if (!snap.exists)
            return;
        const data = snap.data() || {};
        const unifiConfig = data.unifi_agent || data.unifi_remote || {};
        cacheStore.updateSettings({
            timezone: data.timezone || 'UTC',
            unlock_buffer_before_min: data.unlock_buffer_before_min ?? 15,
            lock_buffer_after_min: data.lock_buffer_after_min ?? 15,
            lock_timing_mode: data.lock_timing_mode || 'after_end',
            lock_after_start_min: data.lock_after_start_min ?? 15,
            unifi_host: unifiConfig.host,
            unifi_access_token: unifiConfig.access_token,
            unifi_api_key: unifiConfig.api_key || unifiConfig.developer_api_key,
        });
        logger_1.logger.debug('[ScheduleWindowSync] Updated cached org settings.');
    }, (err) => {
        logger_1.logger.warn(`[ScheduleWindowSync] Settings listener notice: ${err.message}`);
    });
    // 2. Doors listener
    const unsubDoors = db.collection(`organizations/${orgId}/doors`).onSnapshot((snap) => {
        const cachedDoors = snap.docs.map((doc) => {
            const d = doc.data();
            return {
                id: doc.id,
                name: d.label || d.name || doc.id,
                unifi_door_id: d.unifi_door_id || doc.id,
                current_state: d.current_state || 'unknown',
                is_held_unlocked: d.is_held_unlocked || false,
            };
        });
        cacheStore.updateDoors(cachedDoors);
        logger_1.logger.debug(`[ScheduleWindowSync] Updated ${cachedDoors.length} cached door(s).`);
    }, (err) => {
        logger_1.logger.warn(`[ScheduleWindowSync] Doors listener notice: ${err.message}`);
    });
    // 3. Periodic recurring re-sync of schedule windows (every 5 minutes)
    // to slide the 14-day lookahead window forward as time advances
    const intervalHandle = setInterval(() => {
        syncScheduleWindowsNow(orgId)
            .then((count) => onCacheUpdated?.(count))
            .catch((err) => {
            logger_1.logger.debug(`[ScheduleWindowSync] Periodic sync notice: ${err}`);
        });
    }, 5 * 60 * 1000);
    if (intervalHandle.unref)
        intervalHandle.unref();
    return () => {
        unsubSettings();
        unsubDoors();
        clearInterval(intervalHandle);
        logger_1.logger.info('[ScheduleWindowSync] Proactive schedule caching stopped.');
    };
}
