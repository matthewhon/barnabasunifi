"use strict";
/**
 * firebase/reconciliation.ts
 * Reconciles offline door actions to Firestore once internet connectivity is restored.
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.reconcileOfflineActions = reconcileOfflineActions;
const admin = __importStar(require("firebase-admin"));
const firebase_1 = require("../firebase");
const logger_1 = require("../logger");
const cacheStore_1 = require("../storage/cacheStore");
/**
 * Reconcile all pending offline actions to Firestore.
 */
async function reconcileOfflineActions(orgId, agentId) {
    const cacheStore = (0, cacheStore_1.getCacheStore)();
    const pendingActions = cacheStore.getPendingOfflineActions();
    if (pendingActions.length === 0) {
        return 0;
    }
    logger_1.logger.info(`[Reconciliation] Found ${pendingActions.length} offline action(s) to reconcile with Firestore.`);
    const db = (0, firebase_1.getDb)();
    const successfulActionIds = [];
    for (const record of pendingActions) {
        try {
            const executedAtTimestamp = admin.firestore.Timestamp.fromDate(new Date(record.executed_at));
            const now = admin.firestore.Timestamp.now();
            // 1. Write Audit Log
            await db.collection(`organizations/${orgId}/audit_log`).add({
                action: record.action,
                door_id: record.door_id,
                door_label: record.door_label,
                schedule_window_id: record.schedule_window_id,
                status: record.status,
                result: record.status === 'done' ? 'success' : 'error',
                result_message: `${record.result_message} [Executed offline at ${record.executed_at}]`,
                message: `${record.result_message} [Executed offline at ${record.executed_at}]`,
                triggered_by: 'offline_scheduler',
                agent_id: agentId,
                org_id: orgId,
                executed_at: executedAtTimestamp,
                timestamp: executedAtTimestamp,
                reconciled_at: now,
            });
            // 2. Update Door state in Firestore
            const doorUpdate = {
                current_state: record.action === 'unlock' ? 'unlocked' : 'locked',
                last_synced: now,
            };
            if (record.action === 'unlock') {
                doorUpdate.last_unlocked_at = executedAtTimestamp;
                doorUpdate.is_held_unlocked = true;
                doorUpdate.unlock_trigger = 'offline_scheduler';
                if (record.duration_min) {
                    doorUpdate.unlock_duration_min = record.duration_min;
                    doorUpdate.hold_unlock_expires_at = admin.firestore.Timestamp.fromMillis(new Date(record.executed_at).getTime() + record.duration_min * 60 * 1000);
                }
            }
            else {
                doorUpdate.last_locked_at = executedAtTimestamp;
                doorUpdate.is_held_unlocked = false;
                doorUpdate.hold_unlock_expires_at = null;
                doorUpdate.unlock_duration_min = null;
            }
            await db.doc(`organizations/${orgId}/doors/${record.door_id}`).set(doorUpdate, { merge: true });
            // 3. Update Schedule Window document
            if (record.schedule_window_id) {
                try {
                    const windowStatus = record.action === 'unlock'
                        ? (record.status === 'done' ? 'unlocked' : 'unlock_failed')
                        : (record.status === 'done' ? 'locked' : 'lock_failed');
                    await db.doc(`organizations/${orgId}/schedule_windows/${record.schedule_window_id}`).update({
                        status: windowStatus,
                        last_command_status: record.status,
                        last_updated: now,
                    });
                }
                catch (wErr) {
                    logger_1.logger.debug(`[Reconciliation] Notice updating window ${record.schedule_window_id}: ${wErr}`);
                }
            }
            // 4. If any pending/queued door_commands exist for this window + door + action, mark done
            try {
                const matchingCommandsSnap = await db
                    .collection(`organizations/${orgId}/door_commands`)
                    .where('door_id', '==', record.door_id)
                    .where('action', '==', record.action)
                    .where('schedule_window_id', '==', record.schedule_window_id)
                    .where('status', 'in', ['pending', 'queued'])
                    .get();
                for (const cmdDoc of matchingCommandsSnap.docs) {
                    await cmdDoc.ref.update({
                        status: 'done',
                        executed_at: executedAtTimestamp,
                        result_message: 'Executed locally via offline autonomous scheduler.',
                        agent_id: agentId,
                    });
                }
            }
            catch (cmdErr) {
                logger_1.logger.debug(`[Reconciliation] Notice updating matching commands: ${cmdErr}`);
            }
            successfulActionIds.push(record.id);
        }
        catch (itemErr) {
            logger_1.logger.error(`[Reconciliation] Failed to reconcile action ${record.id}: ${String(itemErr)}`);
        }
    }
    if (successfulActionIds.length > 0) {
        cacheStore.clearFlushedOfflineActions(successfulActionIds);
        logger_1.logger.info(`[Reconciliation] ✓ Successfully reconciled and cleared ${successfulActionIds.length} offline action(s).`);
    }
    return successfulActionIds.length;
}
