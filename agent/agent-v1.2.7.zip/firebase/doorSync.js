"use strict";
/**
 * firebase/doorSync.ts
 * Syncs UniFi Access door state into Firestore.
 *
 * Fetches all doors from the local UniFi console and upserts their current
 * state into /organizations/{orgId}/doors/{doorId}. Runs on an interval to
 * keep the cloud dashboard in sync with physical door states.
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.syncDoors = syncDoors;
exports.startDoorSyncInterval = startDoorSyncInterval;
const firebase_1 = require("../firebase");
const logger_1 = require("../logger");
const admin = __importStar(require("firebase-admin"));
// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------
/**
 * Map the UniFi `door_lock_relay_status` field to a normalized state string.
 */
function normalizeDoorState(relayStatus) {
    switch (relayStatus) {
        case 'lock':
            return 'locked';
        case 'unlock':
            return 'unlocked';
        default:
            return 'unknown';
    }
}
// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------
/**
 * Fetch all doors from UniFi Access and upsert their state into Firestore.
 *
 * @param orgId       - Firestore organization document ID
 * @param unifiClient - Initialized UniFi Access API client
 */
async function syncDoors(orgId, unifiClient) {
    const db = (0, firebase_1.getDb)();
    let doors;
    try {
        doors = await unifiClient.getDoors();
    }
    catch (err) {
        logger_1.logger.error(`[DoorSync] Failed to fetch doors from UniFi: ${String(err)}`);
        return [];
    }
    if (doors.length === 0) {
        logger_1.logger.warn('[DoorSync] No doors returned from UniFi Access — nothing to sync.');
        return [];
    }
    const isUuid = (str) => /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(str.trim());
    const batch = db.batch();
    const now = admin.firestore.Timestamp.now();
    const validDoorIds = new Set();
    for (const door of doors) {
        const rawLabel = (door.full_name || door.name || '').trim();
        const label = rawLabel || (door.id ? `Door ${door.id.slice(0, 8)}` : 'Door');
        validDoorIds.add(door.id);
        const doorRef = db.doc(`organizations/${orgId}/doors/${door.id}`);
        const normalizedState = normalizeDoorState(door.door_lock_relay_status);
        const holdExpiresAt = typeof door.hold_unlock_end_time === 'number'
            ? admin.firestore.Timestamp.fromMillis(door.hold_unlock_end_time * 1000)
            : null;
        const record = {
            unifi_door_id: door.id,
            label,
            current_state: normalizedState,
            door_position_status: door.door_position_status ?? null,
            device_state: door.device_state ?? null,
            is_held_unlocked: Boolean(door.is_held_unlocked || holdExpiresAt),
            hold_unlock_expires_at: holdExpiresAt,
            last_synced: now,
            org_id: orgId,
        };
        if (normalizedState === 'locked') {
            record.is_held_unlocked = false;
            record.hold_unlock_expires_at = null;
            record.unlock_duration_min = null;
        }
        const schedId = door.unlock_schedule_id || door.schedule_id;
        if (schedId) {
            record.schedule_id = String(schedId);
        }
        if (door.schedule_name) {
            const cleanSchedName = String(door.schedule_name).trim();
            record.schedule_name =
                cleanSchedName && !isUuid(cleanSchedName) && !cleanSchedName.startsWith('unlock-')
                    ? cleanSchedName
                    : `${label} Unlock Schedule`;
        }
        const unifiThumbnail = door.thumbnail_url ||
            door.thumbnail ||
            door.avatar ||
            door.cover_image ||
            door.picture ||
            null;
        if (unifiThumbnail && typeof unifiThumbnail === 'string') {
            record.unifi_thumbnail_url = unifiThumbnail;
        }
        // set with merge:true so we don't overwrite fields managed by the web app or schedule sync
        batch.set(doorRef, record, { merge: true });
    }
    // Prune phantom or orphaned door documents in Firestore
    try {
        const existingDoorsSnap = await db.collection(`organizations/${orgId}/doors`).get();
        let prunedCount = 0;
        for (const docSnap of existingDoorsSnap.docs) {
            const docId = docSnap.id;
            const data = docSnap.data();
            const docLabel = (data.label || '').trim();
            // If document does not match a valid physical door returned by UniFi
            if (!validDoorIds.has(docId)) {
                // Prune if blank, or matches a rule UUID, or is unknown state without recent access
                if (!docLabel || isUuid(docLabel) || (isUuid(docId) && !data.last_accessed_at)) {
                    batch.delete(docSnap.ref);
                    prunedCount++;
                    logger_1.logger.info(`[DoorSync] Pruning phantom/stale door ${docId} (label: "${docLabel}")`);
                }
            }
        }
        if (prunedCount > 0) {
            logger_1.logger.info(`[DoorSync] Pruned ${prunedCount} phantom door document(s) from Firestore.`);
        }
    }
    catch (pruneErr) {
        logger_1.logger.debug(`[DoorSync] Error during phantom door pruning: ${pruneErr}`);
    }
    try {
        await batch.commit();
        logger_1.logger.info(`[DoorSync] Synced ${doors.length} door(s) for org: ${orgId}`);
    }
    catch (err) {
        logger_1.logger.error(`[DoorSync] Batch write failed: ${String(err)}`);
    }
    return doors;
}
/**
 * Start a recurring door sync on a fixed interval.
 *
 * Runs an initial sync immediately, then repeats every `intervalMs` ms.
 * Returns a cleanup function that stops the interval.
 *
 * @param orgId       - Firestore organization document ID
 * @param unifiClient - Initialized UniFi Access API client
 * @param intervalMs  - Sync frequency in milliseconds (default: 5 minutes)
 */
function startDoorSyncInterval(orgId, unifiClient, intervalMs) {
    logger_1.logger.info(`[DoorSync] Starting door sync interval — every ${intervalMs / 1000}s for org: ${orgId}`);
    const handle = setInterval(() => {
        syncDoors(orgId, unifiClient).catch((err) => {
            logger_1.logger.error(`[DoorSync] Unhandled error in sync interval: ${String(err)}`);
        });
    }, intervalMs);
    // Allow the Node.js process to exit even if this interval is active
    if (handle.unref)
        handle.unref();
    return () => {
        clearInterval(handle);
        logger_1.logger.info('[DoorSync] Door sync interval stopped.');
    };
}
