"use strict";
/**
 * storage/cacheStore.ts
 * Local persistent cache for offline resilience.
 *
 * Persists organization settings, door inventory, upcoming schedule windows,
 * and pending offline action records to disk (data/offline_cache.json).
 * Uses atomic writes (write-to-temp then rename) to prevent corruption.
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.CacheStore = void 0;
exports.getCacheStore = getCacheStore;
const fs = __importStar(require("fs"));
const path = __importStar(require("path"));
const logger_1 = require("../logger");
const DEFAULT_CACHE = {
    version: 1,
    org_id: '',
    last_sync: null,
    settings: {
        timezone: 'UTC',
        unlock_buffer_before_min: 15,
        lock_buffer_after_min: 15,
        lock_timing_mode: 'after_end',
        lock_after_start_min: 15,
    },
    doors: [],
    schedule_windows: [],
    offline_actions: [],
    executed_action_keys: [],
};
class CacheStore {
    constructor(customPath) {
        this.saveTimeout = null;
        if (customPath) {
            this.cacheFilePath = path.resolve(customPath);
        }
        else {
            const dataDir = process.env.DATA_DIR || path.resolve(process.cwd(), 'data');
            this.cacheFilePath = path.join(dataDir, 'offline_cache.json');
        }
        this.memoryCache = { ...DEFAULT_CACHE };
        this.ensureDirectoryExists();
        this.loadFromDisk();
    }
    ensureDirectoryExists() {
        const dir = path.dirname(this.cacheFilePath);
        try {
            if (!fs.existsSync(dir)) {
                fs.mkdirSync(dir, { recursive: true });
            }
        }
        catch (err) {
            logger_1.logger.warn(`[CacheStore] Could not create cache directory ${dir}: ${String(err)}`);
        }
    }
    /**
     * Load cache from disk into memory.
     */
    loadFromDisk() {
        try {
            if (fs.existsSync(this.cacheFilePath)) {
                const raw = fs.readFileSync(this.cacheFilePath, 'utf-8');
                const parsed = JSON.parse(raw);
                this.memoryCache = {
                    version: parsed.version || 1,
                    org_id: parsed.org_id || '',
                    last_sync: parsed.last_sync || null,
                    settings: { ...DEFAULT_CACHE.settings, ...(parsed.settings || {}) },
                    doors: Array.isArray(parsed.doors) ? parsed.doors : [],
                    schedule_windows: Array.isArray(parsed.schedule_windows) ? parsed.schedule_windows : [],
                    offline_actions: Array.isArray(parsed.offline_actions) ? parsed.offline_actions : [],
                    executed_action_keys: Array.isArray(parsed.executed_action_keys) ? parsed.executed_action_keys : [],
                };
                logger_1.logger.debug(`[CacheStore] Loaded cache from disk: ${this.memoryCache.schedule_windows.length} windows, ${this.memoryCache.doors.length} doors.`);
            }
        }
        catch (err) {
            logger_1.logger.error(`[CacheStore] Failed to parse cache file at ${this.cacheFilePath}: ${String(err)}`);
        }
        return this.memoryCache;
    }
    /**
     * Atomically save the memory cache to disk.
     */
    saveToDiskSync() {
        try {
            this.ensureDirectoryExists();
            const tmpPath = `${this.cacheFilePath}.${Date.now()}.tmp`;
            const dataStr = JSON.stringify(this.memoryCache, null, 2);
            fs.writeFileSync(tmpPath, dataStr, 'utf-8');
            fs.renameSync(tmpPath, this.cacheFilePath);
        }
        catch (err) {
            logger_1.logger.error(`[CacheStore] Failed to write cache to ${this.cacheFilePath}: ${String(err)}`);
        }
    }
    /**
     * Debounced save to reduce frequent disk I/O.
     */
    scheduleSave() {
        if (this.saveTimeout) {
            clearTimeout(this.saveTimeout);
        }
        this.saveTimeout = setTimeout(() => {
            this.saveTimeout = null;
            this.saveToDiskSync();
        }, 1000);
    }
    // ---------------------------------------------------------------------------
    // Getters
    // ---------------------------------------------------------------------------
    getCache() {
        return this.memoryCache;
    }
    getSettings() {
        return this.memoryCache.settings;
    }
    getDoors() {
        return this.memoryCache.doors;
    }
    getScheduleWindows() {
        return this.memoryCache.schedule_windows;
    }
    getPendingOfflineActions() {
        return this.memoryCache.offline_actions;
    }
    hasExecutedAction(key) {
        return this.memoryCache.executed_action_keys.includes(key);
    }
    // ---------------------------------------------------------------------------
    // Setters & Mutators
    // ---------------------------------------------------------------------------
    setOrgId(orgId) {
        if (this.memoryCache.org_id !== orgId) {
            this.memoryCache.org_id = orgId;
            this.scheduleSave();
        }
    }
    updateSettings(updates) {
        this.memoryCache.settings = {
            ...this.memoryCache.settings,
            ...updates,
        };
        this.scheduleSave();
    }
    updateDoors(doors) {
        this.memoryCache.doors = doors;
        this.scheduleSave();
    }
    updateScheduleWindows(windows) {
        this.memoryCache.schedule_windows = windows;
        this.memoryCache.last_sync = new Date().toISOString();
        this.pruneOldExecutedKeys();
        this.scheduleSave();
    }
    recordExecutedAction(key) {
        if (!this.memoryCache.executed_action_keys.includes(key)) {
            this.memoryCache.executed_action_keys.push(key);
            this.scheduleSave();
        }
    }
    enqueueOfflineAction(action) {
        this.memoryCache.offline_actions.push(action);
        this.saveToDiskSync(); // Always flush offline actions immediately for durability
    }
    clearFlushedOfflineActions(actionIds) {
        if (actionIds.length === 0)
            return;
        const idsSet = new Set(actionIds);
        this.memoryCache.offline_actions = this.memoryCache.offline_actions.filter((a) => !idsSet.has(a.id));
        this.saveToDiskSync();
    }
    /**
     * Prunes executed keys older than the windows currently stored
     * to keep the key list bounded.
     */
    pruneOldExecutedKeys() {
        const validWindowIds = new Set(this.memoryCache.schedule_windows.map((w) => w.id));
        this.memoryCache.executed_action_keys = this.memoryCache.executed_action_keys.filter((k) => {
            const parts = k.split(':');
            const windowId = parts[0];
            return validWindowIds.has(windowId);
        });
    }
    /**
     * Checks if valid cache exists on disk.
     */
    static hasExistingCache(customPath) {
        const dataDir = process.env.DATA_DIR || path.resolve(process.cwd(), 'data');
        const p = customPath || path.join(dataDir, 'offline_cache.json');
        if (!fs.existsSync(p))
            return false;
        try {
            const stat = fs.statSync(p);
            return stat.size > 10;
        }
        catch {
            return false;
        }
    }
}
exports.CacheStore = CacheStore;
// Global default instance
let globalCacheStore = null;
function getCacheStore() {
    if (!globalCacheStore) {
        globalCacheStore = new CacheStore();
    }
    return globalCacheStore;
}
