"use strict";
/**
 * logger.ts
 * Winston logger instance configured with colorized console output,
 * timestamp formatting, and log level from the environment config.
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.logger = void 0;
exports.getRecentLogs = getRecentLogs;
exports.setLogLevel = setLogLevel;
const winston_1 = __importDefault(require("winston"));
const { combine, timestamp, colorize, printf, errors } = winston_1.default.format;
/**
 * Custom log line format:
 *   [2024-01-15 10:30:45] [INFO] Agent started for org my-org
 */
const logFormat = printf(({ level, message, timestamp: ts, stack }) => {
    const base = `[${ts}] [${level.toUpperCase()}] ${message}`;
    // Include stack trace for error-level logs when available
    return stack ? `${base}\n${stack}` : base;
});
const recentLogs = [];
const MAX_RECENT_LOGS = 100;
function getRecentLogs() {
    return [...recentLogs];
}
const memoryBufferFormat = winston_1.default.format((info) => {
    const ts = info.timestamp || new Date().toISOString();
    const lvl = String(info.level || 'info').toUpperCase();
    const line = `[${ts}] [${lvl}] ${info.message}`;
    recentLogs.push(line);
    if (recentLogs.length > MAX_RECENT_LOGS) {
        recentLogs.shift();
    }
    return info;
});
/**
 * Create and configure the singleton logger.
 * Call `setLogLevel` after config is loaded to apply the configured level.
 */
exports.logger = winston_1.default.createLogger({
    level: 'info', // default; overridden by setLogLevel() after config loads
    format: combine(errors({ stack: true }), timestamp({ format: 'YYYY-MM-DD HH:mm:ss' }), colorize({ all: true }), memoryBufferFormat(), logFormat),
    transports: [
        new winston_1.default.transports.Console({
            handleExceptions: true,
            handleRejections: true,
        }),
    ],
    exitOnError: false,
});
/**
 * Update the logger's level at runtime (called once config is loaded).
 */
function setLogLevel(level) {
    exports.logger.level = level;
    exports.logger.transports.forEach((t) => {
        t.level = level;
    });
}
