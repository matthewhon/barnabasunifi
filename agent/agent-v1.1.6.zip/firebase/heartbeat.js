"use strict";
/**
 * firebase/heartbeat.ts
 * Periodic heartbeat that reports agent liveness to Firestore.
 *
 * Writes to /agents/{agentId} on a fixed interval so the dashboard can
 * display the agent's online/offline status and last-seen time.
 * Registers SIGINT/SIGTERM handlers to cleanly mark the agent offline
 * before the process exits.
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.startHeartbeat = startHeartbeat;
const admin = __importStar(require("firebase-admin"));
const firebase_1 = require("../firebase");
const logger_1 = require("../logger");
// ---------------------------------------------------------------------------
// Constants
// ---------------------------------------------------------------------------
const AGENT_CAPABILITIES = ['unlock', 'lock', 'door_sync'];
// ---------------------------------------------------------------------------
// Internal helpers
// ---------------------------------------------------------------------------
async function writeHeartbeat(agentId, orgId, agentLabel, version, status) {
    const db = (0, firebase_1.getDb)();
    const payload = {
        org_id: orgId,
        label: agentLabel,
        status,
        last_heartbeat: admin.firestore.Timestamp.now(),
        version,
        capabilities: [...AGENT_CAPABILITIES],
    };
    await db.doc(`agents/${agentId}`).set(payload, { merge: true });
}
// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------
/**
 * Start the agent heartbeat. Writes to Firestore immediately, then on every
 * `intervalMs` milliseconds. Registers shutdown handlers to mark offline.
 *
 * @param orgId      - Firestore organization document ID
 * @param agentId    - Unique agent identifier (used as Firestore doc ID)
 * @param agentLabel - Human-readable name shown in the dashboard
 * @param version    - Agent version string (from package.json)
 * @param intervalMs - How often to write a heartbeat (default: 60 seconds)
 * @returns A cleanup function that stops the heartbeat interval.
 */
function startHeartbeat(orgId, agentId, agentLabel, version, intervalMs) {
    logger_1.logger.info(`[Heartbeat] Starting heartbeat for agent "${agentId}" every ${intervalMs / 1000}s`);
    // Write immediately on startup
    writeHeartbeat(agentId, orgId, agentLabel, version, 'online').catch((err) => {
        logger_1.logger.error(`[Heartbeat] Initial heartbeat write failed: ${String(err)}`);
    });
    const handle = setInterval(() => {
        writeHeartbeat(agentId, orgId, agentLabel, version, 'online').catch((err) => {
            logger_1.logger.error(`[Heartbeat] Heartbeat write failed: ${String(err)}`);
        });
    }, intervalMs);
    if (handle.unref)
        handle.unref();
    // ---------------------------------------------------------------------------
    // Graceful shutdown: mark agent offline before the process exits
    // ---------------------------------------------------------------------------
    const shutdown = async (signal) => {
        logger_1.logger.info(`[Heartbeat] Received ${signal} — marking agent offline and exiting.`);
        clearInterval(handle);
        try {
            await writeHeartbeat(agentId, orgId, agentLabel, version, 'offline');
            logger_1.logger.info('[Heartbeat] Agent marked offline in Firestore.');
        }
        catch (err) {
            logger_1.logger.error(`[Heartbeat] Failed to write offline status: ${String(err)}`);
        }
        process.exit(0);
    };
    const sigintHandler = () => { void shutdown('SIGINT'); };
    const sigtermHandler = () => { void shutdown('SIGTERM'); };
    process.once('SIGINT', sigintHandler);
    process.once('SIGTERM', sigtermHandler);
    // Return a cleanup function that cancels the interval and removes handlers
    return () => {
        clearInterval(handle);
        process.off('SIGINT', sigintHandler);
        process.off('SIGTERM', sigtermHandler);
        logger_1.logger.info('[Heartbeat] Heartbeat stopped.');
    };
}
