"use strict";
/**
 * firebase.ts
 * Firebase connection initialization.
 * Supports BOTH:
 *  1. Service Account JSON file (Admin SDK)
 *  2. Connection Token / Custom Token (Firebase Client SDK via Custom Token)
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.db = exports.admin = void 0;
exports.initializeFirebase = initializeFirebase;
exports.getDb = getDb;
const admin = __importStar(require("firebase-admin"));
exports.admin = admin;
const app_1 = __importDefault(require("firebase/compat/app"));
require("firebase/compat/firestore");
require("firebase/compat/auth");
const fs = __importStar(require("fs"));
const path = __importStar(require("path"));
const logger_1 = require("./logger");
let _db = null;
let _isInitialized = false;
const DEFAULT_API_KEY = process.env.FIREBASE_API_KEY || 'AIzaSyCBu6tWWWx50VqSkTUGEAYy6fShFGIpZRk';
/**
 * Initialize Firebase connection.
 * Checks for service-account.json first; if absent, uses AGENT_AUTH_TOKEN custom token.
 */
async function initializeFirebase(serviceAccountPath, projectId) {
    if (_isInitialized) {
        logger_1.logger.warn('Firebase already initialized — skipping.');
        return;
    }
    const resolvedPath = path.resolve(serviceAccountPath);
    const hasServiceAccount = fs.existsSync(resolvedPath) &&
        !fs.statSync(resolvedPath).isDirectory() &&
        fs.readFileSync(resolvedPath, 'utf-8').includes('private_key');
    if (hasServiceAccount) {
        try {
            const raw = fs.readFileSync(resolvedPath, 'utf-8');
            const serviceAccount = JSON.parse(raw);
            if (admin.apps.length === 0) {
                admin.initializeApp({
                    credential: admin.credential.cert(serviceAccount),
                    projectId,
                });
            }
            _db = admin.firestore();
            _db.settings({ ignoreUndefinedProperties: true });
            _isInitialized = true;
            logger_1.logger.info(`✓ Firebase initialized via Service Account for project: ${projectId}`);
            return;
        }
        catch (err) {
            logger_1.logger.warn(`Failed to initialize via service account: ${err} — checking for auth token…`);
        }
    }
    // Fallback: Initialize via Firebase Client SDK with AGENT_AUTH_TOKEN
    const authToken = process.env.AGENT_AUTH_TOKEN;
    if (authToken) {
        logger_1.logger.info(`Connecting to Firebase using Agent Connection Token for project: ${projectId}…`);
        if (app_1.default.apps.length === 0) {
            app_1.default.initializeApp({
                apiKey: DEFAULT_API_KEY,
                projectId,
                authDomain: `${projectId}.firebaseapp.com`,
            });
        }
        try {
            await app_1.default.auth().signInWithCustomToken(authToken);
            logger_1.logger.info(`✓ Successfully authenticated agent with Firebase Auth via Connection Token.`);
            _db = app_1.default.firestore();
            _isInitialized = true;
            return;
        }
        catch (err) {
            logger_1.logger.error(`Failed to authenticate with custom token: ${err.message}`);
            throw new Error(`Agent token authentication failed: ${err.message}`);
        }
    }
    throw new Error(`No valid Firebase credentials found. Provide a Connection Token or service-account.json.`);
}
/**
 * Returns the Firestore database instance.
 */
function getDb() {
    if (!_db) {
        throw new Error('Firebase has not been initialized. Call initializeFirebase() first.');
    }
    return _db;
}
exports.db = new Proxy({}, {
    get(_target, prop) {
        return getDb()[prop];
    },
});
