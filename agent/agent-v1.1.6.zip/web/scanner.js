"use strict";
/**
 * scanner.ts
 * Scans local subnets for active UniFi Consoles (UDM, Cloud Key, etc.).
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getCandidateSubnets = getCandidateSubnets;
exports.scanSubnet = scanSubnet;
exports.autoDiscoverUnifiConsole = autoDiscoverUnifiConsole;
const https = __importStar(require("https"));
const os = __importStar(require("os"));
const axios_1 = __importDefault(require("axios"));
/**
 * Get candidate subnets based on local interfaces, plus common LAN defaults.
 */
function getCandidateSubnets() {
    const subnets = new Set();
    const interfaces = os.networkInterfaces();
    for (const name of Object.keys(interfaces)) {
        const addrs = interfaces[name];
        if (!addrs)
            continue;
        for (const addr of addrs) {
            if (addr.family === 'IPv4' && !addr.internal) {
                const parts = addr.address.split('.');
                if (parts.length === 4) {
                    // If not a docker-internal 172.x subnet, add as high priority
                    if (parts[0] === '192' && parts[1] === '168') {
                        subnets.add(`192.168.${parts[2]}`);
                    }
                    else if (parts[0] === '10') {
                        subnets.add(`10.${parts[1]}.${parts[2]}`);
                    }
                }
            }
        }
    }
    // Common church / small business subnets as defaults
    subnets.add('192.168.1');
    subnets.add('192.168.0');
    subnets.add('192.168.2');
    subnets.add('10.0.0');
    subnets.add('10.0.1');
    return Array.from(subnets);
}
/**
 * Probe an individual IP on port 443 with a short timeout to see if it is a UniFi console.
 */
async function probeHost(ip, timeoutMs = 800) {
    const start = Date.now();
    const httpsAgent = new https.Agent({
        rejectUnauthorized: false,
        timeout: timeoutMs,
    });
    try {
        const url = `https://${ip}`;
        const res = await axios_1.default.get(`${url}/api/v1/developer/doors`, {
            httpsAgent,
            timeout: timeoutMs,
            validateStatus: () => true, // Don't throw on 401 or 403
        });
        const elapsed = Date.now() - start;
        // UniFi Access developer API returns 401 Unauthorized with JSON or specific headers
        if (res.status === 401 || res.status === 200 || res.status === 403) {
            const dataStr = typeof res.data === 'object' ? JSON.stringify(res.data) : String(res.data || '');
            const serverHeader = String(res.headers['server'] || '').toLowerCase();
            const isUnifi = dataStr.includes('code') ||
                dataStr.includes('UNAUTHORIZED') ||
                dataStr.includes('access') ||
                serverHeader.includes('nginx') ||
                res.headers['x-accel-version'] !== undefined;
            return {
                ip,
                url,
                isConfirmedUnifi: isUnifi,
                statusText: `Responded (HTTP ${res.status}) in ${elapsed}ms`,
                responseTimeMs: elapsed,
            };
        }
    }
    catch (err) {
        // Check if it failed with TLS cert error or HTTP connection
        if (err.code === 'ECONNRESET' || err.response?.status === 401) {
            return {
                ip,
                url: `https://${ip}`,
                isConfirmedUnifi: true,
                statusText: `Active HTTPS host`,
                responseTimeMs: Date.now() - start,
            };
        }
    }
    return null;
}
/**
 * Scan a /24 subnet prefix (e.g. "192.168.1") concurrently with concurrency limit.
 */
async function scanSubnet(subnetPrefix, onProgress) {
    const cleanPrefix = subnetPrefix.replace(/\.0$/, '').replace(/\.$/, '');
    const ips = [];
    for (let i = 1; i <= 254; i++) {
        ips.push(`${cleanPrefix}.${i}`);
    }
    const results = [];
    const concurrency = 30;
    let scanned = 0;
    for (let i = 0; i < ips.length; i += concurrency) {
        const batch = ips.slice(i, i + concurrency);
        const batchResults = await Promise.all(batch.map(async (ip) => {
            const found = await probeHost(ip);
            scanned++;
            if (onProgress)
                onProgress(scanned, ips.length);
            return found;
        }));
        for (const r of batchResults) {
            if (r)
                results.push(r);
        }
    }
    // Sort confirmed UniFi first, then by response time
    return results.sort((a, b) => {
        if (a.isConfirmedUnifi && !b.isConfirmedUnifi)
            return -1;
        if (!a.isConfirmedUnifi && b.isConfirmedUnifi)
            return 1;
        return a.responseTimeMs - b.responseTimeMs;
    });
}
/**
 * Automatically scan candidate subnets to find the UniFi Access console on LAN.
 * If token is provided, tests the token against candidate consoles to ensure authentication.
 */
async function autoDiscoverUnifiConsole(token) {
    const candidateSubnets = getCandidateSubnets();
    for (const subnet of candidateSubnets) {
        const consoles = await scanSubnet(subnet);
        if (consoles.length > 0) {
            if (token) {
                for (const candidate of consoles) {
                    try {
                        const httpsAgent = new https.Agent({ rejectUnauthorized: false });
                        const res = await axios_1.default.get(`${candidate.url}/api/v1/developer/doors`, {
                            headers: { Authorization: `Bearer ${token}` },
                            httpsAgent,
                            timeout: 1500,
                            validateStatus: () => true,
                        });
                        if (res.status === 200) {
                            return candidate.url;
                        }
                    }
                    catch {
                        // continue checking
                    }
                }
            }
            const confirmed = consoles.find((c) => c.isConfirmedUnifi) || consoles[0];
            if (confirmed) {
                return confirmed.url;
            }
        }
    }
    return null;
}
