"use strict";
/**
 * firebase/accessLogSync.ts
 * Syncs UniFi Access door opening/closing activity & access methods into Firestore.
 *
 * Fetches access logs (user credentials, access method, timestamps, door open/close)
 * from UniFi Access and streams them into:
 * /organizations/{orgId}/access_logs/{logId}
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.syncAccessLogs = syncAccessLogs;
exports.startAccessLogSyncInterval = startAccessLogSyncInterval;
const firebase_1 = require("../firebase");
const logger_1 = require("../logger");
const admin = __importStar(require("firebase-admin"));
let _lastSyncedEpochSeconds = 0;
/**
 * Fetch new access logs from UniFi Access and upsert into Firestore.
 */
async function syncAccessLogs(orgId, unifiClient) {
    const db = (0, firebase_1.getDb)();
    let entries = [];
    // 1. Look up last synced timestamp if not cached in memory
    if (_lastSyncedEpochSeconds === 0) {
        try {
            const stateSnap = await db
                .doc(`organizations/${orgId}/settings/access_log_sync`)
                .get();
            if (stateSnap.exists) {
                _lastSyncedEpochSeconds = stateSnap.data()?.last_synced_epoch || 0;
            }
        }
        catch { }
    }
    // Lookback with a 120s buffer for clock drift / delayed reporting, or default to last 24h on first run
    const nowEpoch = Math.floor(Date.now() / 1000);
    const since = _lastSyncedEpochSeconds > 0
        ? Math.max(0, _lastSyncedEpochSeconds - 120)
        : nowEpoch - 24 * 60 * 60;
    try {
        entries = await unifiClient.getAccessLogs({
            since,
            pageSize: 100,
            topic: 'door_openings',
        });
    }
    catch (err) {
        logger_1.logger.error(`[AccessLogSync] Failed to fetch access logs from UniFi: ${String(err)}`);
        return [];
    }
    if (entries.length === 0) {
        logger_1.logger.debug('[AccessLogSync] No new access logs from UniFi.');
        return [];
    }
    // 2. Commit logs to Firestore in batches (max 500 operations per batch)
    const batch = db.batch();
    const now = admin.firestore.Timestamp.now();
    let latestEventEpoch = _lastSyncedEpochSeconds;
    // Track latest access per door to update door document
    const doorLatestAccess = new Map();
    for (const entry of entries) {
        if (!entry.id)
            continue;
        const docRef = db.doc(`organizations/${orgId}/access_logs/${entry.id}`);
        const record = {
            ...entry,
            org_id: orgId,
            synced_at: now,
        };
        batch.set(docRef, record, { merge: true });
        // Track latest timestamp seen
        const eventEpoch = Math.floor(new Date(entry.timestamp).getTime() / 1000);
        if (!isNaN(eventEpoch) && eventEpoch > latestEventEpoch) {
            latestEventEpoch = eventEpoch;
        }
        // Door last accessed metadata
        if (entry.door_id && entry.user_name && entry.event_result === 'success') {
            const existing = doorLatestAccess.get(entry.door_id);
            if (!existing || new Date(entry.timestamp).getTime() > new Date(existing.timestamp).getTime()) {
                doorLatestAccess.set(entry.door_id, {
                    timestamp: entry.timestamp,
                    userName: entry.user_name,
                    accessMethod: entry.access_method,
                    accessMethodLabel: entry.access_method_label,
                });
            }
        }
    }
    // 3. Update doors with last accessed metadata
    for (const [doorId, info] of doorLatestAccess.entries()) {
        const doorRef = db.doc(`organizations/${orgId}/doors/${doorId}`);
        batch.set(doorRef, {
            last_accessed_at: info.timestamp,
            last_accessed_by: info.userName,
            last_access_method: info.accessMethod,
            last_access_method_label: info.accessMethodLabel,
        }, { merge: true });
    }
    // 4. Update sync state
    _lastSyncedEpochSeconds = Math.max(_lastSyncedEpochSeconds, latestEventEpoch);
    const syncStateRef = db.doc(`organizations/${orgId}/settings/access_log_sync`);
    batch.set(syncStateRef, {
        last_synced_epoch: _lastSyncedEpochSeconds,
        last_synced_at: now,
        total_synced: entries.length,
    }, { merge: true });
    try {
        await batch.commit();
        logger_1.logger.info(`[AccessLogSync] Synced ${entries.length} access log(s) for org: ${orgId}`);
    }
    catch (err) {
        logger_1.logger.error(`[AccessLogSync] Batch write failed: ${String(err)}`);
    }
    return entries;
}
/**
 * Start a recurring access log sync on a fixed interval (e.g. every 25 seconds).
 */
function startAccessLogSyncInterval(orgId, unifiClient, intervalMs = 25000) {
    logger_1.logger.info(`[AccessLogSync] Starting access log sync interval — every ${intervalMs / 1000}s for org: ${orgId}`);
    // Initial sync after 3 seconds
    setTimeout(() => {
        syncAccessLogs(orgId, unifiClient).catch((err) => {
            logger_1.logger.error(`[AccessLogSync] Error in initial sync: ${String(err)}`);
        });
    }, 3000);
    const handle = setInterval(() => {
        syncAccessLogs(orgId, unifiClient).catch((err) => {
            logger_1.logger.error(`[AccessLogSync] Unhandled error in sync interval: ${String(err)}`);
        });
    }, intervalMs);
    if (handle.unref)
        handle.unref();
    return () => {
        clearInterval(handle);
        logger_1.logger.info('[AccessLogSync] Access log sync interval stopped.');
    };
}
