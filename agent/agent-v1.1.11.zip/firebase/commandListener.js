"use strict";
/**
 * firebase/commandListener.ts
 * Real-time Firestore listener for door commands.
 *
 * Listens for documents in organizations/{orgId}/door_commands with
 * status == 'queued' that are due for execution (execute_at <= now).
 * Uses Firestore transactions to claim commands atomically, preventing
 * double-execution in multi-agent deployments.
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.startCommandListener = startCommandListener;
const admin = __importStar(require("firebase-admin"));
const firebase_1 = require("../firebase");
const logger_1 = require("../logger");
const doorSync_1 = require("./doorSync");
const scheduleSync_1 = require("./scheduleSync");
const visitorSync_1 = require("./visitorSync");
const accessLogSync_1 = require("./accessLogSync");
const updateChecker_1 = require("./updateChecker");
// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------
function nowTimestamp() {
    return admin.firestore.Timestamp.now();
}
function parseExecuteAtMillis(executeAt) {
    if (!executeAt)
        return 0;
    if (typeof executeAt.toMillis === 'function') {
        return executeAt.toMillis();
    }
    if (executeAt instanceof Date) {
        return isNaN(executeAt.getTime()) ? 0 : executeAt.getTime();
    }
    if (typeof executeAt === 'string' || typeof executeAt === 'number') {
        const ms = new Date(executeAt).getTime();
        return isNaN(ms) ? 0 : ms;
    }
    return 0;
}
async function writeAuditLog(db, orgId, command, status, resultMessage, agentId) {
    try {
        const isManual = command.triggered_by === 'manual' || !command.schedule_window_id;
        let action;
        if (command.action === 'unlock') {
            action = isManual ? 'manual_unlock' : 'unlock';
        }
        else if (command.action === 'lock') {
            action = isManual ? 'manual_lock' : 'lock';
        }
        else if (command.action === 'sync_doors') {
            action = 'doors_synced';
        }
        else if (command.action === 'sync_schedules') {
            action = 'schedule_synced';
        }
        else if (command.action === 'update_schedule') {
            action = 'schedule_updated';
        }
        else if (command.action === 'create_schedule') {
            action = 'schedule_created';
        }
        else if (command.action === 'delete_schedule') {
            action = 'schedule_deleted';
        }
        else if (command.action === 'sync_visitors') {
            action = 'visitor_synced';
        }
        else if (command.action === 'create_visitor') {
            action = 'visitor_created';
        }
        else if (command.action === 'update_visitor') {
            action = 'visitor_updated';
        }
        else if (command.action === 'delete_visitor') {
            action = 'visitor_deleted';
        }
        else if (command.action === 'sync_access_logs') {
            action = 'access_logs_synced';
        }
        else {
            action = command.action;
        }
        await db.collection(`organizations/${orgId}/audit_log`).add({
            command_id: command.id,
            action,
            door_id: command.door_id ?? null,
            door_label: command.door_label ?? null,
            unifi_door_id: command.unifi_door_id ?? null,
            schedule_id: command.schedule_id ?? null,
            status,
            result: status === 'done' ? 'success' : 'error',
            result_message: resultMessage,
            message: resultMessage,
            triggered_by: isManual ? 'manual' : 'scheduler',
            actor_uid: command.actor_uid ?? null,
            agent_id: agentId,
            org_id: orgId,
            schedule_window_id: command.schedule_window_id ?? null,
            executed_at: nowTimestamp(),
            timestamp: nowTimestamp(),
        });
    }
    catch (err) {
        logger_1.logger.error(`Failed to write audit log for command ${command.id}: ${String(err)}`);
    }
}
async function updateScheduleWindow(db, orgId, windowId, action, status) {
    try {
        const windowRef = db.doc(`organizations/${orgId}/schedule_windows/${windowId}`);
        const windowStatus = action === 'unlock'
            ? (status === 'done' ? 'unlocked' : 'unlock_failed')
            : (status === 'done' ? 'locked' : 'lock_failed');
        await windowRef.update({
            status: windowStatus,
            last_command_status: status,
            last_updated: nowTimestamp(),
        });
    }
    catch (err) {
        logger_1.logger.warn(`Could not update schedule_window ${windowId}: ${String(err)}`);
    }
}
// ---------------------------------------------------------------------------
// Main export
// ---------------------------------------------------------------------------
/**
 * Start listening for queued door commands and execute them against the
 * UniFi Access API. Returns an unsubscribe function.
 *
 * @param orgId       - Firestore organization document ID
 * @param agentId     - This agent's identifier (written into executed commands)
 * @param unifiClient - Initialized UniFi Access client
 * @param onCommand   - Optional callback invoked whenever a command is processed
 */
function startCommandListener(orgId, agentId, unifiClient, onCommand) {
    const db = (0, firebase_1.getDb)();
    const commandsRef = db.collection(`organizations/${orgId}/door_commands`);
    const activeTimers = new Map();
    logger_1.logger.info(`[CommandListener] Watching commands for org: ${orgId}`);
    async function processCommand(doc) {
        const commandId = doc.id;
        const rawData = doc.data();
        if (!rawData)
            return;
        // Step 1: Atomically claim the command with a Firestore transaction
        let command;
        try {
            const claimed = await db.runTransaction(async (tx) => {
                const freshDoc = await tx.get(doc.ref);
                if (!freshDoc.exists)
                    return false;
                const freshData = freshDoc.data();
                if (freshData.status !== 'queued')
                    return false;
                tx.update(doc.ref, {
                    status: 'executing',
                    agent_id: agentId,
                    claimed_at: nowTimestamp(),
                });
                return true;
            });
            if (!claimed) {
                logger_1.logger.debug(`[CommandListener] Command ${commandId} already claimed or not queued — skipping.`);
                return;
            }
            const unifiDoorId = (rawData.unifi_door_id || rawData.door_id);
            command = {
                id: commandId,
                action: rawData.action,
                door_id: rawData.door_id,
                door_label: rawData.door_label,
                unifi_door_id: unifiDoorId,
                schedule_id: rawData.schedule_id,
                schedule_data: rawData.schedule_data,
                visitor_id: rawData.visitor_id,
                unifi_visitor_id: rawData.unifi_visitor_id,
                firestore_visitor_id: rawData.firestore_visitor_id,
                visitor_data: rawData.visitor_data,
                status: 'executing',
                execute_at: rawData.execute_at,
                duration_min: rawData.duration_min,
                schedule_window_id: rawData.schedule_window_id,
                triggered_by: rawData.triggered_by,
                actor_uid: rawData.actor_uid,
                created_by: rawData.created_by,
                org_id: orgId,
            };
            logger_1.logger.info(`[CommandListener] Claimed command ${commandId}: ${command.action}${command.unifi_door_id ? ` door ${command.unifi_door_id}` : ''}${command.schedule_id ? ` schedule ${command.schedule_id}` : ''}${command.visitor_id ? ` visitor ${command.visitor_id}` : ''}`);
        }
        catch (err) {
            logger_1.logger.error(`[CommandListener] Transaction failed for command ${commandId}: ${String(err)}`);
            return;
        }
        // Step 2: Execute the command against the UniFi Access API
        let finalStatus = 'done';
        let resultMessage = '';
        try {
            if (command.action === 'unlock') {
                if (!command.unifi_door_id)
                    throw new Error('Missing unifi_door_id for unlock action');
                const durationMin = command.duration_min ?? 60;
                await unifiClient.unlockDoor(command.unifi_door_id, durationMin);
                resultMessage = `Door unlocked for ${durationMin} minute(s).`;
                (0, doorSync_1.syncDoors)(orgId, unifiClient).catch(() => { });
            }
            else if (command.action === 'lock') {
                if (!command.unifi_door_id)
                    throw new Error('Missing unifi_door_id for lock action');
                await unifiClient.lockDoor(command.unifi_door_id);
                resultMessage = 'Door locked successfully.';
                (0, doorSync_1.syncDoors)(orgId, unifiClient).catch(() => { });
            }
            else if (command.action === 'sync_doors') {
                const synced = await (0, doorSync_1.syncDoors)(orgId, unifiClient);
                resultMessage = `Discovered and synced ${synced.length} door(s) from UniFi Access.`;
            }
            else if (command.action === 'sync_schedules') {
                const synced = await (0, scheduleSync_1.syncSchedules)(orgId, unifiClient);
                resultMessage = `Synced ${synced.length} schedule(s) from UniFi Access.`;
            }
            else if (command.action === 'update_schedule') {
                if (!command.schedule_id)
                    throw new Error('Missing schedule_id for update_schedule');
                const updated = await unifiClient.updateSchedule(command.schedule_id, command.schedule_data || {});
                await db.doc(`organizations/${orgId}/unifi_schedules/${command.schedule_id}`).set({
                    ...updated,
                    org_id: orgId,
                    last_synced: nowTimestamp(),
                    sync_status: 'synced',
                    sync_error: null,
                    updated_at: nowTimestamp(),
                }, { merge: true });
                resultMessage = `Schedule ${command.schedule_id} updated successfully.`;
            }
            else if (command.action === 'create_schedule') {
                const created = await unifiClient.createSchedule(command.schedule_data || {});
                await db.doc(`organizations/${orgId}/unifi_schedules/${created.id}`).set({
                    ...created,
                    org_id: orgId,
                    last_synced: nowTimestamp(),
                    sync_status: 'synced',
                    sync_error: null,
                    updated_at: nowTimestamp(),
                }, { merge: true });
                resultMessage = `Schedule ${created.id} created successfully.`;
            }
            else if (command.action === 'delete_schedule') {
                if (!command.schedule_id)
                    throw new Error('Missing schedule_id for delete_schedule');
                await unifiClient.deleteSchedule(command.schedule_id);
                await db.doc(`organizations/${orgId}/unifi_schedules/${command.schedule_id}`).delete();
                resultMessage = `Schedule ${command.schedule_id} deleted successfully.`;
            }
            else if (command.action === 'sync_visitors') {
                const synced = await (0, visitorSync_1.syncVisitors)(orgId, unifiClient);
                resultMessage = `Synced ${synced.length} visitor(s) from UniFi Access.`;
            }
            else if (command.action === 'create_visitor' || command.action === 'update_visitor') {
                const rawUnifiId = command.visitor_data?.unifi_visitor_id || command.unifi_visitor_id;
                const unifiVisitorId = (rawUnifiId && rawUnifiId !== command.visitor_id) ? rawUnifiId : undefined;
                let resultVisitor;
                if (command.action === 'update_visitor' && unifiVisitorId) {
                    try {
                        resultVisitor = await unifiClient.updateVisitor(unifiVisitorId, command.visitor_data || {});
                        resultMessage = `Visitor ${command.visitor_id} updated successfully in UniFi.`;
                    }
                    catch (updateErr) {
                        const errStr = String(updateErr);
                        if (errStr.includes('160001') || errStr.includes('not found') || updateErr?.response?.status === 404) {
                            logger_1.logger.warn(`[CommandListener] Visitor ${unifiVisitorId} not found in UniFi. Creating new visitor…`);
                            resultVisitor = await unifiClient.createVisitor(command.visitor_data || {});
                            resultMessage = `Visitor created in UniFi (ID: ${resultVisitor.id}).`;
                        }
                        else {
                            throw updateErr;
                        }
                    }
                }
                else {
                    resultVisitor = await unifiClient.createVisitor(command.visitor_data || {});
                    resultMessage = `Visitor ${resultVisitor.full_name || resultVisitor.first_name} created successfully in UniFi.`;
                }
                const targetVisitorId = command.visitor_id || resultVisitor.id;
                await db.doc(`organizations/${orgId}/visitors/${targetVisitorId}`).set({
                    ...resultVisitor,
                    id: targetVisitorId,
                    org_id: orgId,
                    unifi_visitor_id: resultVisitor.unifi_visitor_id || resultVisitor.id,
                    last_synced: nowTimestamp(),
                    sync_status: 'synced',
                    sync_error: null,
                    updated_at: nowTimestamp(),
                }, { merge: true });
            }
            else if (command.action === 'delete_visitor') {
                if (!command.visitor_id)
                    throw new Error('Missing visitor_id for delete_visitor');
                const unifiVisitorId = command.visitor_data?.unifi_visitor_id || command.unifi_visitor_id;
                if (unifiVisitorId && unifiVisitorId !== command.visitor_id) {
                    try {
                        await unifiClient.deleteVisitor(unifiVisitorId);
                    }
                    catch (delErr) {
                        logger_1.logger.warn(`[CommandListener] UniFi deleteVisitor notice: ${delErr.message}`);
                    }
                }
                await db.doc(`organizations/${orgId}/visitors/${command.visitor_id}`).set({
                    status: 'revoked',
                    sync_status: 'synced',
                    updated_at: nowTimestamp(),
                }, { merge: true });
                resultMessage = `Visitor ${command.visitor_id} revoked successfully.`;
            }
            else if (command.action === 'sync_access_logs') {
                const synced = await (0, accessLogSync_1.syncAccessLogs)(orgId, unifiClient);
                resultMessage = `Synced ${synced.length} access log(s) from UniFi Access.`;
            }
            else if (command.action === 'apply_update' || command.action === 'upgrade_agent') {
                const updateState = await (0, updateChecker_1.checkForUpdate)();
                if (updateState.updateAvailable) {
                    (0, updateChecker_1.applyPendingUpdate)().catch((err) => {
                        logger_1.logger.error(`[CommandListener] Apply update failed: ${String(err)}`);
                    });
                    resultMessage = `Agent update to v${updateState.latestVersion} initiated. Restarting...`;
                }
                else {
                    resultMessage = `Agent is already up to date (v${updateState.currentVersion}).`;
                }
            }
            else {
                throw new Error(`Unknown action: ${String(command.action)}`);
            }
            // Immediately update the door's state in Firestore so the dashboard reflects the change
            const targetDoorId = command.door_id || command.unifi_door_id;
            if (targetDoorId && (command.action === 'unlock' || command.action === 'lock')) {
                try {
                    const newCurrentState = command.action === 'unlock' ? 'unlocked' : 'locked';
                    const updateData = {
                        current_state: newCurrentState,
                        last_synced: nowTimestamp(),
                    };
                    if (command.action === 'unlock') {
                        updateData.last_unlocked_at = nowTimestamp();
                    }
                    else {
                        updateData.last_locked_at = nowTimestamp();
                    }
                    await db.doc(`organizations/${orgId}/doors/${targetDoorId}`).set(updateData, { merge: true });
                }
                catch (doorUpdateErr) {
                    logger_1.logger.warn(`Could not update door document state: ${String(doorUpdateErr)}`);
                }
                // Trigger background sync to refresh full door info without blocking
                (0, doorSync_1.syncDoors)(orgId, unifiClient).catch((err) => {
                    logger_1.logger.debug(`[CommandListener] Post-command door sync notice: ${String(err)}`);
                });
            }
            logger_1.logger.info(`[CommandListener] Command ${commandId} executed successfully: ${resultMessage}`);
        }
        catch (err) {
            finalStatus = 'failed';
            resultMessage = String(err);
            logger_1.logger.error(`[CommandListener] Command ${commandId} failed: ${resultMessage}`);
        }
        // Step 3: Update the command document with the final status
        try {
            await doc.ref.update({
                status: finalStatus,
                executed_at: nowTimestamp(),
                result_message: resultMessage,
                agent_id: agentId,
            });
        }
        catch (err) {
            logger_1.logger.error(`[CommandListener] Failed to update command ${commandId} status: ${String(err)}`);
        }
        // Step 4: Write audit log entry
        await writeAuditLog(db, orgId, command, finalStatus, resultMessage, agentId);
        // Step 5: Update the associated schedule window if applicable
        if (command.schedule_window_id) {
            await updateScheduleWindow(db, orgId, command.schedule_window_id, command.action, finalStatus);
        }
        // Invoke optional callback
        onCommand?.(command);
    }
    const query = commandsRef.where('status', '==', 'queued');
    const unsubscribe = query.onSnapshot(async (snapshot) => {
        const nowMs = Date.now();
        for (const docChange of snapshot.docChanges()) {
            const doc = docChange.doc;
            const commandId = doc.id;
            if (docChange.type === 'removed') {
                const timer = activeTimers.get(commandId);
                if (timer) {
                    clearTimeout(timer);
                    activeTimers.delete(commandId);
                }
                continue;
            }
            const rawData = doc.data();
            if (rawData.status !== 'queued') {
                const timer = activeTimers.get(commandId);
                if (timer) {
                    clearTimeout(timer);
                    activeTimers.delete(commandId);
                }
                continue;
            }
            const executeAtMs = parseExecuteAtMillis(rawData.execute_at);
            const delayMs = executeAtMs - nowMs;
            // If due now or past due (or within 5 seconds in future)
            if (delayMs <= 5000) {
                const timer = activeTimers.get(commandId);
                if (timer) {
                    clearTimeout(timer);
                    activeTimers.delete(commandId);
                }
                void processCommand(doc);
            }
            else if (delayMs < 24 * 60 * 60 * 1000) {
                // Schedule execution if not already scheduled
                if (!activeTimers.has(commandId)) {
                    logger_1.logger.info(`[CommandListener] Scheduling command ${commandId} in ${Math.round(delayMs / 1000)}s`);
                    const timer = setTimeout(() => {
                        activeTimers.delete(commandId);
                        void processCommand(doc);
                    }, delayMs);
                    activeTimers.set(commandId, timer);
                }
            }
        }
    }, (err) => {
        logger_1.logger.error(`[CommandListener] Snapshot listener error: ${String(err)}`);
    });
    return () => {
        for (const timer of activeTimers.values()) {
            clearTimeout(timer);
        }
        activeTimers.clear();
        unsubscribe();
    };
}
