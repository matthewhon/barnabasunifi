"use strict";
/**
 * unifi/access.ts
 * UniFi Access API client.
 * Wraps the UniFi Access Developer API with typed methods for door management.
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UnifiAccessClient = exports.DAYS_OF_WEEK = void 0;
exports.normalizeUnifiVisitor = normalizeUnifiVisitor;
exports.serializeUnifiVisitor = serializeUnifiVisitor;
exports.normalizeAccessLogEntry = normalizeAccessLogEntry;
exports.normalizeUnifiSchedule = normalizeUnifiSchedule;
exports.serializeUnifiSchedule = serializeUnifiSchedule;
const axios_1 = __importDefault(require("axios"));
const https = __importStar(require("https"));
const logger_1 = require("../logger");
function normalizeUnifiVisitor(raw, orgId = '') {
    const id = String(raw.id || raw.unique_id || raw.visitor_id || raw.user_id || raw._id || '');
    const firstName = String(raw.first_name || raw.firstName || (raw.name ? String(raw.name).split(' ')[0] : 'Visitor'));
    const lastName = String(raw.last_name || raw.lastName || (raw.name ? String(raw.name).split(' ').slice(1).join(' ') : ''));
    const fullName = String(raw.full_name || raw.name || `${firstName} ${lastName}`.trim());
    let startTimeIso = new Date().toISOString();
    if (raw.start_time || raw.startTime) {
        const val = raw.start_time || raw.startTime;
        if (typeof val === 'number') {
            startTimeIso = new Date(val > 10000000000 ? val : val * 1000).toISOString();
        }
        else {
            startTimeIso = new Date(val).toISOString();
        }
    }
    let endTimeIso = new Date(Date.now() + 2 * 60 * 60 * 1000).toISOString();
    if (raw.end_time || raw.endTime) {
        const val = raw.end_time || raw.endTime;
        if (typeof val === 'number') {
            endTimeIso = new Date(val > 10000000000 ? val : val * 1000).toISOString();
        }
        else {
            endTimeIso = new Date(val).toISOString();
        }
    }
    const doorIds = [];
    const doorLabels = [];
    const rawDoors = raw.doors || raw.door_ids || raw.device_ids || raw.resources;
    if (Array.isArray(rawDoors)) {
        for (const d of rawDoors) {
            if (typeof d === 'string') {
                doorIds.push(d);
            }
            else if (d && typeof d === 'object') {
                const dId = d.id || d.unique_id || d.door_id;
                const dLabel = d.name || d.label;
                if (dId)
                    doorIds.push(String(dId));
                if (dLabel)
                    doorLabels.push(String(dLabel));
            }
        }
    }
    // Derive status
    const now = Date.now();
    const startMs = new Date(startTimeIso).getTime();
    const endMs = new Date(endTimeIso).getTime();
    let status = 'active';
    if (raw.status === 'canceled' || raw.status === 'revoked') {
        status = 'revoked';
    }
    else if (now < startMs) {
        status = 'upcoming';
    }
    else if (now >= endMs) {
        status = 'expired';
    }
    return {
        id,
        org_id: orgId,
        unifi_visitor_id: id,
        first_name: firstName,
        last_name: lastName,
        full_name: fullName,
        mobile_phone: raw.mobile_phone || raw.phone,
        email: raw.email,
        pin_code: raw.pin_code || raw.pin || raw.passcode,
        start_time: startTimeIso,
        end_time: endTimeIso,
        door_ids: doorIds,
        door_labels: doorLabels,
        status,
        purpose: raw.purpose || raw.note || raw.remarks || raw.visit_reason,
        raw_data: raw,
        last_synced: new Date().toISOString(),
        sync_status: 'synced',
    };
}
function serializeUnifiVisitor(visitor) {
    const base = visitor.raw_data ? { ...visitor.raw_data } : {};
    if (visitor.first_name)
        base.first_name = visitor.first_name;
    if (visitor.last_name !== undefined)
        base.last_name = visitor.last_name;
    if (visitor.mobile_phone !== undefined)
        base.mobile_phone = visitor.mobile_phone;
    if (visitor.email !== undefined)
        base.email = visitor.email;
    if (visitor.purpose !== undefined) {
        base.purpose = visitor.purpose;
        base.visit_reason = visitor.purpose || 'Other';
    }
    if (visitor.door_ids && visitor.door_ids.length > 0) {
        base.doors = visitor.door_ids;
        base.door_ids = visitor.door_ids;
        base.resources = visitor.door_ids.map((id) => ({
            id,
            type: 'door',
        }));
    }
    if (visitor.start_time) {
        const ms = new Date(visitor.start_time).getTime();
        base.start_time = Math.floor(ms / 1000);
        base.start_time_millis = ms;
    }
    if (visitor.end_time) {
        const ms = new Date(visitor.end_time).getTime();
        base.end_time = Math.floor(ms / 1000);
        base.end_time_millis = ms;
    }
    if (visitor.pin_code) {
        base.pin_code = String(visitor.pin_code);
        base.pin = String(visitor.pin_code);
    }
    return base;
}
function normalizeAccessLogEntry(raw, orgId = '') {
    const id = String(raw.id || raw._id || raw.event_id || `log-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`);
    // Parse timestamp
    let timestampIso = new Date().toISOString();
    const rawTs = raw.timestamp || raw.event_time || raw.created_at || raw.published;
    if (rawTs) {
        if (typeof rawTs === 'number') {
            timestampIso = new Date(rawTs > 10000000000 ? rawTs : rawTs * 1000).toISOString();
        }
        else {
            const parsed = new Date(rawTs).getTime();
            if (!isNaN(parsed))
                timestampIso = new Date(parsed).toISOString();
        }
    }
    const source = raw.source || {};
    const event = source.event || raw.event || {};
    const actor = source.actor || raw.actor || raw.user || {};
    const auth = source.authentication || raw.authentication || {};
    const target = source.target || raw.target || raw.door || {};
    // Event Type
    const rawEventType = String(event.type || raw.event_type || raw.type || '').toLowerCase();
    let eventType = 'door_unlock';
    if (rawEventType.includes('door.open') || rawEventType.includes('dps.open') || rawEventType.includes('open')) {
        eventType = 'door_open';
    }
    else if (rawEventType.includes('door.close') || rawEventType.includes('dps.close') || rawEventType.includes('close')) {
        eventType = 'door_close';
    }
    else if (rawEventType.includes('reject') || rawEventType.includes('denied') || rawEventType.includes('failed')) {
        eventType = 'access_denied';
    }
    else if (rawEventType.includes('unlock')) {
        eventType = 'door_unlock';
    }
    // Result
    const rawResult = String(event.result || raw.result || '').toUpperCase();
    const eventResult = rawResult.includes('DENIED') || rawResult.includes('REJECT') || eventType === 'access_denied'
        ? 'denied'
        : rawResult.includes('FAIL')
            ? 'failed'
            : 'success';
    // Access Method
    const rawMethod = String(auth.credential_provider ||
        raw.credential_type ||
        raw.method ||
        raw.access_method ||
        event.type ||
        '').toLowerCase();
    let accessMethod = 'unknown';
    let accessMethodLabel = 'Access Method';
    if (rawMethod.includes('card') || rawMethod.includes('nfc') || rawMethod.includes('rfid') || rawMethod.includes('fob')) {
        accessMethod = 'nfc_card';
        accessMethodLabel = 'Key Card / Fob';
    }
    else if (rawMethod.includes('pin') || rawMethod.includes('passcode') || rawMethod.includes('password')) {
        accessMethod = 'pin_code';
        accessMethodLabel = 'Keypad PIN';
    }
    else if (rawMethod.includes('mobile') || rawMethod.includes('bluetooth') || rawMethod.includes('bt') || rawMethod.includes('app')) {
        accessMethod = 'mobile_tap';
        accessMethodLabel = 'Mobile Tap';
    }
    else if (rawMethod.includes('wave') || rawMethod.includes('hand')) {
        accessMethod = 'hand_wave';
        accessMethodLabel = 'Hand Wave';
    }
    else if (rawMethod.includes('remote') || rawMethod.includes('manual') || rawMethod.includes('button')) {
        accessMethod = 'remote';
        accessMethodLabel = 'Remote Unlock';
    }
    else if (rawMethod.includes('face')) {
        accessMethod = 'face';
        accessMethodLabel = 'Face Recognition';
    }
    else if (rawMethod.includes('visitor') || rawMethod.includes('qr')) {
        accessMethod = 'visitor_pin';
        accessMethodLabel = 'Visitor PIN / QR';
    }
    else if (rawMethod.includes('schedule')) {
        accessMethod = 'schedule';
        accessMethodLabel = 'Schedule';
    }
    // User details
    const userName = String(actor.display_name ||
        actor.name ||
        actor.full_name ||
        raw.user_name ||
        (actor.id ? `User ${actor.id}` : 'Unknown User')).trim();
    const userId = actor.id ? String(actor.id) : (raw.user_id ? String(raw.user_id) : undefined);
    const userType = actor.type === 'visitor' ? 'visitor' : actor.type === 'admin' ? 'admin' : actor.type === 'user' ? 'user' : 'unknown';
    // Door details
    const doorId = String(target.id || raw.door_id || raw.unique_id || '');
    const doorLabel = String(target.display_name || target.name || raw.door_label || raw.door_name || 'Door');
    // Display message
    const displayMessage = event.display_message ||
        raw.display_message ||
        (eventType === 'door_open'
            ? `${doorLabel} opened`
            : eventType === 'door_close'
                ? `${doorLabel} closed`
                : eventResult === 'denied'
                    ? `Access denied for ${userName} at ${doorLabel} (${accessMethodLabel})`
                    : `${userName} opened ${doorLabel} via ${accessMethodLabel}`);
    return {
        id,
        org_id: orgId,
        timestamp: timestampIso,
        event_type: eventType,
        event_result: eventResult,
        door_id: doorId,
        door_label: doorLabel,
        user_id: userId,
        user_name: userName,
        user_type: userType,
        access_method: accessMethod,
        access_method_label: accessMethodLabel,
        display_message: displayMessage,
        raw_data: raw,
    };
}
exports.DAYS_OF_WEEK = [
    'monday',
    'tuesday',
    'wednesday',
    'thursday',
    'friday',
    'saturday',
    'sunday',
];
function normalizeUnifiSchedule(raw, orgId = '') {
    const id = String(raw.id || raw.unique_id || raw._id || '');
    const name = String(raw.name || raw.schedule_name || raw.alias || 'Schedule');
    const type = raw.type || (raw.is_unlock ? 'unlock' : 'access');
    const isDefault = Boolean(raw.is_default || raw.default);
    const holidayGroupId = raw.holiday_group_id || raw.holiday_id;
    const weeklySchedule = exports.DAYS_OF_WEEK.map((day) => ({
        day,
        active: false,
        slots: [],
    }));
    const rawWeekly = raw.weekly_schedule || raw.week_schedule || raw.schedule || raw.schedules;
    if (Array.isArray(rawWeekly)) {
        for (const item of rawWeekly) {
            let targetDay;
            if (typeof item.day === 'string') {
                const d = item.day.toLowerCase();
                if (exports.DAYS_OF_WEEK.includes(d))
                    targetDay = d;
            }
            else if (typeof item.day_of_week === 'number') {
                const idx = item.day_of_week === 0 ? 6 : item.day_of_week - 1;
                targetDay = exports.DAYS_OF_WEEK[idx] || exports.DAYS_OF_WEEK[item.day_of_week];
            }
            if (targetDay) {
                const dayEntry = weeklySchedule.find((w) => w.day === targetDay);
                if (dayEntry) {
                    if (Array.isArray(item.slots) && item.slots.length > 0) {
                        dayEntry.active = item.active !== false;
                        dayEntry.slots = item.slots.map((s) => ({
                            start_time: String(s.start_time || s.start || '08:00'),
                            end_time: String(s.end_time || s.end || '17:00'),
                        }));
                    }
                    else if (item.start_time || item.start) {
                        dayEntry.active = true;
                        dayEntry.slots.push({
                            start_time: String(item.start_time || item.start || '08:00'),
                            end_time: String(item.end_time || item.end || '17:00'),
                        });
                    }
                }
            }
        }
    }
    else if (rawWeekly && typeof rawWeekly === 'object') {
        for (const day of exports.DAYS_OF_WEEK) {
            const dayData = rawWeekly[day] || rawWeekly[day.slice(0, 3)];
            const dayEntry = weeklySchedule.find((w) => w.day === day);
            if (dayEntry && dayData) {
                if (Array.isArray(dayData) && dayData.length > 0) {
                    dayEntry.active = true;
                    dayEntry.slots = dayData.map((s) => ({
                        start_time: String(s.start_time || s.start || '08:00'),
                        end_time: String(s.end_time || s.end || '17:00'),
                    }));
                }
                else if (typeof dayData === 'object' && (dayData.start_time || dayData.start)) {
                    dayEntry.active = true;
                    dayEntry.slots = [{
                            start_time: String(dayData.start_time || dayData.start || '08:00'),
                            end_time: String(dayData.end_time || dayData.end || '17:00'),
                        }];
                }
            }
        }
    }
    const doorIds = [];
    const doorLabels = [];
    if (Array.isArray(raw.doors || raw.door_ids || raw.device_ids)) {
        for (const d of raw.doors || raw.door_ids || raw.device_ids) {
            if (typeof d === 'string') {
                doorIds.push(d);
            }
            else if (d && typeof d === 'object') {
                if (d.id || d.unique_id)
                    doorIds.push(String(d.id || d.unique_id));
                if (d.name || d.label)
                    doorLabels.push(String(d.name || d.label));
            }
        }
    }
    return {
        id,
        org_id: orgId,
        unifi_schedule_id: id,
        name,
        type,
        is_default: isDefault,
        weekly_schedule: weeklySchedule,
        door_ids: doorIds,
        door_labels: doorLabels,
        holiday_group_id: holidayGroupId,
        raw_data: raw,
        last_synced: new Date().toISOString(),
        sync_status: 'synced',
    };
}
function serializeUnifiSchedule(schedule) {
    const base = schedule.raw_data ? { ...schedule.raw_data } : {};
    if (schedule.name)
        base.name = schedule.name;
    if (schedule.type)
        base.type = schedule.type;
    if (schedule.holiday_group_id !== undefined)
        base.holiday_group_id = schedule.holiday_group_id;
    if (schedule.weekly_schedule) {
        base.weekly_schedule = schedule.weekly_schedule.map((dayObj, idx) => ({
            day: dayObj.day,
            day_of_week: idx + 1,
            active: dayObj.active,
            slots: dayObj.active ? dayObj.slots : [],
        }));
        const weekScheduleObj = {};
        for (const d of schedule.weekly_schedule) {
            weekScheduleObj[d.day] = d.active ? d.slots : [];
        }
        base.week_schedule = weekScheduleObj;
    }
    if (schedule.door_ids) {
        base.door_ids = schedule.door_ids;
    }
    return base;
}
// ---------------------------------------------------------------------------
// Device helpers
// ---------------------------------------------------------------------------
function isHubDevice(d) {
    if (Array.isArray(d?.capabilities)) {
        if (d.capabilities.includes('is_hub') || d.capabilities.includes('identity_is_hub'))
            return true;
        if (d.capabilities.includes('is_reader') || d.capabilities.includes('identity_is_reader'))
            return false;
    }
    const t = String(d?.device_type || d?.type || d?.model || d?.name || '').toLowerCase();
    if (t.includes('reader'))
        return false;
    return (t.includes('hub') ||
        t.includes('uah') ||
        t.includes('eah') ||
        t.includes('uret') ||
        t.includes('ultra') ||
        t.includes('gate') ||
        t.includes('lock'));
}
function isReaderDevice(d) {
    if (Array.isArray(d?.capabilities)) {
        if (d.capabilities.includes('is_reader') || d.capabilities.includes('identity_is_reader'))
            return true;
        if (d.capabilities.includes('is_hub') || d.capabilities.includes('identity_is_hub'))
            return false;
    }
    const t = String(d?.device_type || d?.type || d?.model || d?.name || '').toLowerCase();
    return (t.includes('reader') ||
        t.includes('pro') ||
        t.includes('g2') ||
        t.includes('lite') ||
        t.includes('intercom'));
}
function parseHubDoorStatus(hubDevice, port = 'd1') {
    if (!hubDevice) {
        return { relayStatus: 'lock', positionStatus: 'close', isHeld: false, holdEndTime: null };
    }
    const cfgs = hubDevice.configs || [];
    const map = new Map();
    for (const c of cfgs) {
        if (c.key && c.value !== undefined) {
            map.set(c.key, String(c.value));
        }
    }
    // 1. Direct relay outputs: 'on' = unlocked/energized, 'off' = locked
    let isUnlocked = false;
    if (port === 'd2') {
        isUnlocked = map.get('output_d2_lock_relay') === 'on';
    }
    else {
        isUnlocked = map.get('output_d1_lock_relay') === 'on' || map.get('input_state_rly-lock_dry') === 'on';
    }
    // 2. Temporary hold-open / unlock schedules
    const nowSec = Math.floor(Date.now() / 1000);
    const lockEndTime = parseInt(map.get('lock_end_time') || '0', 10);
    const tempUnlockEnd = parseInt(map.get('temporary_unlock_suspend_end_time') || '0', 10);
    const isHeld = lockEndTime > nowSec || tempUnlockEnd > nowSec;
    if (isHeld) {
        isUnlocked = true;
    }
    // 3. Door position sensor (DPS): 'off' = open circuit (door open), 'on' = closed
    const dps = port === 'd2'
        ? map.get('input_d2_dps')
        : (map.get('input_d1_dps') || map.get('input_state_dps'));
    let positionStatus = 'close';
    if (dps === 'off') {
        positionStatus = 'open';
    }
    else if (dps === 'on') {
        positionStatus = 'close';
    }
    return {
        relayStatus: isUnlocked ? 'unlock' : 'lock',
        positionStatus,
        isHeld,
        holdEndTime: isHeld ? Math.max(lockEndTime, tempUnlockEnd) : null,
    };
}
// ---------------------------------------------------------------------------
// Client
// ---------------------------------------------------------------------------
class UnifiAccessClient {
    /**
     * @param host           - Base URL of the UniFi console, e.g. https://192.168.1.1
     * @param token          - UniFi Access API token
     * @param skipTlsVerify  - When true, disables TLS certificate validation
     *                         (needed for self-signed certs on UniFi consoles)
     */
    constructor(host, token, skipTlsVerify = false) {
        this.doorToHubMap = new Map();
        this.doorToPortMap = new Map();
        this.host = host.replace(/\/$/, '');
        const httpsAgent = new https.Agent({
            rejectUnauthorized: !skipTlsVerify,
        });
        this.http = axios_1.default.create({
            baseURL: this.host,
            httpsAgent,
            headers: {
                Authorization: `Bearer ${token}`,
                'X-API-KEY': token,
                'Content-Type': 'application/json',
                Accept: 'application/json',
            },
            timeout: 15000,
        });
        // Log outgoing requests at debug level
        this.http.interceptors.request.use((config) => {
            logger_1.logger.debug(`UniFi → ${config.method?.toUpperCase()} ${config.url}`);
            return config;
        });
        // Log responses and surface API-level errors
        this.http.interceptors.response.use((response) => {
            logger_1.logger.debug(`UniFi ← ${response.status} ${response.config.url}`);
            // Surface UniFi API application-level error codes even if HTTP status is 200 OK
            if (response.data && typeof response.data === 'object') {
                const rawCode = response.data.code;
                if (rawCode !== undefined && rawCode !== null) {
                    const msg = response.data.msg ||
                        response.data.message;
                    const msgStr = typeof msg === 'string' ? msg.toLowerCase().trim() : '';
                    // UniFi APIs return code 0, 1, 200, 'SUCCESS', 'OK', or msg 'success'/'ok' for successful responses
                    const isSuccess = rawCode === 'SUCCESS' ||
                        rawCode === 'success' ||
                        rawCode === 0 ||
                        rawCode === '0' ||
                        rawCode === 1 ||
                        rawCode === '1' ||
                        rawCode === 200 ||
                        rawCode === '200' ||
                        rawCode === 'OK' ||
                        rawCode === 'ok' ||
                        msgStr === 'success' ||
                        msgStr === 'ok';
                    if (!isSuccess) {
                        const errorText = msg || `UniFi API error code: ${rawCode}`;
                        logger_1.logger.warn(`UniFi API error response [${rawCode}] ${response.config.url}: ${errorText}`);
                        const err = new Error(`UniFi API error [${rawCode}]: ${errorText}`);
                        err.response = response;
                        err.code = rawCode;
                        return Promise.reject(err);
                    }
                }
            }
            return response;
        }, (error) => {
            logger_1.logger.debug(`UniFi API error: ${error.config?.method?.toUpperCase()} ${error.config?.url} -> ${error.response?.status ?? error.message}`);
            return Promise.reject(error);
        });
    }
    /**
     * Populate internal mapping of door IDs to device/hub IDs from:
     * 1. v2 topology tree (/proxy/access/api/v2/devices/topology)
     * 2. v2 devices API (/proxy/access/api/v2/devices)
     * 3. v2 doors API (/proxy/access/api/v2/doors)
     */
    async populateDoorToHubMap() {
        // Strategy 1: UniFi Access topology API (explicit door -> hub relationship)
        try {
            const topoRes = await this.http.get('/proxy/access/api/v2/devices/topology');
            const topoData = topoRes.data?.data || [];
            const walkTopology = (item) => {
                if (!item)
                    return;
                if (Array.isArray(item)) {
                    for (const el of item)
                        walkTopology(el);
                    return;
                }
                if (Array.isArray(item.doors)) {
                    for (const door of item.doors) {
                        const doorId = door.id || door.unique_id;
                        if (doorId && Array.isArray(door.device_groups)) {
                            for (const group of door.device_groups) {
                                const devs = Array.isArray(group) ? group : (group.devices || [group]);
                                for (const dev of devs) {
                                    if (isHubDevice(dev) && dev.unique_id) {
                                        this.doorToHubMap.set(doorId, dev.unique_id);
                                        logger_1.logger.info(`[UniFi] Mapped Hub ${dev.unique_id} (${dev.device_type || 'hub'}) to door ${doorId} via topology`);
                                    }
                                }
                            }
                        }
                    }
                }
                if (Array.isArray(item.floors)) {
                    walkTopology(item.floors);
                }
            };
            walkTopology(topoData);
        }
        catch (err) {
            logger_1.logger.debug(`[UniFi] Topology fetch not available or failed: ${err.message}`);
        }
        // Strategy 2: v2 devices API
        try {
            const response = await this.http.get('/proxy/access/api/v2/devices');
            const devices = response.data?.data || [];
            // Pass 1: Multi-port hub extensions (e.g. UA Retrofit Hub 2)
            for (const d of devices) {
                if (d.extensions && Array.isArray(d.extensions)) {
                    for (const ext of d.extensions) {
                        if (ext.target_type === 'door' && ext.target_value) {
                            const port = ext.source_id === 'port2' ? 'd2' : 'd1';
                            this.doorToHubMap.set(ext.target_value, d.unique_id);
                            this.doorToPortMap.set(ext.target_value, port);
                        }
                    }
                }
            }
            // Pass 2: Hubs with d.doors or d.relays
            for (const d of devices) {
                if (isHubDevice(d)) {
                    if (Array.isArray(d.doors)) {
                        for (const dr of d.doors) {
                            const dId = typeof dr === 'string' ? dr : (dr?.unique_id || dr?.id);
                            if (dId && !this.doorToHubMap.has(dId)) {
                                this.doorToHubMap.set(dId, d.unique_id);
                                logger_1.logger.info(`[UniFi] Mapped Hub ${d.unique_id} to door ${dId} from hub.doors`);
                            }
                        }
                    }
                    if (Array.isArray(d.relays)) {
                        for (const r of d.relays) {
                            const dId = r.door_id || r.target_door_id || r.target_id;
                            if (dId && !this.doorToHubMap.has(dId)) {
                                this.doorToHubMap.set(dId, d.unique_id);
                                logger_1.logger.info(`[UniFi] Mapped Hub ${d.unique_id} to door ${dId} from hub.relays`);
                            }
                        }
                    }
                }
            }
            // Pass 3: Hubs with d.door or location_id
            for (const d of devices) {
                const doorId = d.door?.unique_id || d.location_id;
                if (doorId && isHubDevice(d) && !this.doorToHubMap.has(doorId)) {
                    this.doorToHubMap.set(doorId, d.unique_id);
                    this.doorToPortMap.set(doorId, 'd1');
                    logger_1.logger.info(`[UniFi] Mapped Hub ${d.unique_id} to door ${doorId} (${d.door?.name || d.name || 'Door'})`);
                }
            }
            // Pass 4: Readers with linked hub ID attributes
            for (const d of devices) {
                const doorId = d.door?.unique_id || d.location_id;
                const linkedHubId = d.connected_uah_id ||
                    d.hub_id ||
                    d.connected_hub_id ||
                    d.parent_device_id ||
                    d.door?.hub_id ||
                    d.door?.device_id ||
                    d.door?.uah_id;
                if (doorId && linkedHubId && !this.doorToHubMap.has(doorId)) {
                    this.doorToHubMap.set(doorId, linkedHubId);
                    logger_1.logger.info(`[UniFi] Mapped Hub ${linkedHubId} (from device ${d.unique_id}) to door ${doorId}`);
                }
            }
            // Pass 5: Single Hub fallback (e.g. site with one Retrofit Hub)
            const allHubs = devices.filter((d) => isHubDevice(d));
            if (allHubs.length === 1) {
                const singleHub = allHubs[0];
                for (const d of devices) {
                    const doorId = d.door?.unique_id;
                    if (doorId && !this.doorToHubMap.has(doorId)) {
                        this.doorToHubMap.set(doorId, singleHub.unique_id);
                        logger_1.logger.info(`[UniFi] Single hub ${singleHub.unique_id} mapped as default for door ${doorId}`);
                    }
                }
            }
        }
        catch (err) {
            logger_1.logger.debug(`[UniFi] Failed to populate door to hub map from devices: ${err.message}`);
        }
        // Strategy 3: v2 doors API
        try {
            const doorsRes = await this.http.get('/proxy/access/api/v2/doors');
            const doorsData = doorsRes.data?.data || [];
            for (const dr of doorsData) {
                const doorId = dr.id || dr.unique_id;
                const hubId = dr.hub_id || dr.connected_uah_id || dr.uah_id || dr.device_id;
                if (doorId && hubId && !this.doorToHubMap.has(doorId)) {
                    this.doorToHubMap.set(doorId, hubId);
                    logger_1.logger.info(`[UniFi] Mapped Hub ${hubId} to door ${doorId} via /doors`);
                }
            }
        }
        catch { }
    }
    /**
     * Dynamically update host and token (e.g. after cloud config pull or token rotation).
     */
    updateCredentials(host, token, skipTlsVerify) {
        this.host = host.replace(/\/$/, '');
        this.http.defaults.baseURL = this.host;
        this.http.defaults.headers.common['Authorization'] = `Bearer ${token}`;
        this.http.defaults.headers.common['X-API-KEY'] = token;
        if (skipTlsVerify !== undefined) {
            this.http.defaults.httpsAgent = new https.Agent({
                rejectUnauthorized: !skipTlsVerify,
            });
        }
    }
    // ---------------------------------------------------------------------------
    // Public methods
    // ---------------------------------------------------------------------------
    /**
     * Fetch all doors registered in UniFi Access.
     * Checks v1 Developer API first, falls back to UniFi OS Access v2 API.
     */
    async getDoors() {
        try {
            const response = await this.http.get('/api/v1/developer/doors');
            if (Array.isArray(response.data?.data)) {
                // Asynchronously populate door-to-hub mapping in background
                this.populateDoorToHubMap().catch(() => { });
                return response.data.data;
            }
        }
        catch {
            // Fall through
        }
        try {
            const response = await this.http.get('/proxy/access/integration/v1/developer/doors');
            if (Array.isArray(response.data?.data)) {
                this.populateDoorToHubMap().catch(() => { });
                return response.data.data;
            }
        }
        catch {
            // Fall through to v2 API
        }
        // UniFi Access v2 API
        const response = await this.http.get('/proxy/access/api/v2/devices');
        const devices = response.data?.data || [];
        const deviceById = new Map();
        for (const d of devices) {
            deviceById.set(d.unique_id, d);
        }
        // Ensure doorToHubMap and doorToPortMap are populated
        for (const d of devices) {
            if (d.extensions && Array.isArray(d.extensions)) {
                for (const ext of d.extensions) {
                    if (ext.target_type === 'door' && ext.target_value) {
                        const port = ext.source_id === 'port2' ? 'd2' : 'd1';
                        this.doorToHubMap.set(ext.target_value, d.unique_id);
                        this.doorToPortMap.set(ext.target_value, port);
                    }
                }
            }
        }
        for (const d of devices) {
            const doorId = d.door?.unique_id || d.location_id;
            if (doorId && isHubDevice(d) && !this.doorToHubMap.has(doorId)) {
                this.doorToHubMap.set(doorId, d.unique_id);
                this.doorToPortMap.set(doorId, 'd1');
            }
        }
        for (const d of devices) {
            const doorId = d.door?.unique_id || d.location_id;
            const linkedHubId = d.connected_uah_id || d.hub_id || d.connected_hub_id;
            if (doorId && linkedHubId) {
                this.doorToHubMap.set(doorId, linkedHubId);
            }
        }
        const doorMap = new Map();
        // Pass 1: Add doors from multi-port hub extensions (e.g. Front Door & Main Door on UA Retrofit Hub 2)
        for (const d of devices) {
            if (d.extensions && Array.isArray(d.extensions)) {
                for (const ext of d.extensions) {
                    if (ext.target_type === 'door' && ext.target_value) {
                        const doorId = ext.target_value;
                        const port = ext.source_id === 'port2' ? 'd2' : 'd1';
                        const status = parseHubDoorStatus(d, port);
                        doorMap.set(doorId, {
                            id: doorId,
                            name: ext.target_name || d.alias || d.name,
                            door_lock_relay_status: status.relayStatus,
                            door_position_status: status.positionStatus,
                            is_held_unlocked: status.isHeld,
                            hold_unlock_end_time: status.holdEndTime,
                            type: d.device_type,
                            location_id: d.location_id || '',
                            full_name: `${d.alias || d.name} - ${ext.target_name || 'Door'}`,
                            device_state: d.device_state || d.state || 'connected',
                        });
                    }
                }
            }
        }
        // Pass 2: Add or enhance doors from devices with d.door
        for (const d of devices) {
            if (d.door && d.door.unique_id) {
                const doorId = d.door.unique_id;
                const isHub = isHubDevice(d);
                const hubId = this.doorToHubMap.get(doorId);
                const hub = hubId ? deviceById.get(hubId) : (isHub ? d : null);
                const port = this.doorToPortMap.get(doorId) || 'd1';
                const status = parseHubDoorStatus(hub, port);
                const existing = doorMap.get(doorId);
                if (!existing) {
                    doorMap.set(doorId, {
                        id: doorId,
                        name: d.door.name || d.alias || d.name,
                        door_lock_relay_status: status.relayStatus,
                        door_position_status: status.positionStatus,
                        is_held_unlocked: status.isHeld,
                        hold_unlock_end_time: status.holdEndTime,
                        type: hub?.device_type || (isHub ? d.device_type : d.device_type),
                        location_id: d.door.up_id || '',
                        full_name: d.door.full_name || d.door.name,
                        device_state: hub?.device_state || d.device_state || d.state || 'connected',
                    });
                }
                else {
                    // If already in doorMap (from hub extensions), prefer official name from reader/door if cleaner
                    if (d.door.name) {
                        existing.name = d.door.name;
                    }
                    if (d.door.full_name) {
                        existing.full_name = d.door.full_name;
                    }
                    if (hub?.device_type) {
                        existing.type = hub.device_type;
                    }
                    existing.door_lock_relay_status = status.relayStatus;
                    existing.door_position_status = status.positionStatus;
                    existing.is_held_unlocked = status.isHeld;
                }
            }
        }
        // Pass 3: Enrich doors with schedules/rules from v2 doors API
        try {
            const doorsRes = await this.http.get('/proxy/access/api/v2/doors');
            const doorsData = doorsRes.data?.data || [];
            for (const dr of doorsData) {
                const doorId = String(dr.id || dr.unique_id || '');
                if (!doorId)
                    continue;
                const existing = doorMap.get(doorId);
                const schedId = dr.unlock_schedule_id || dr.schedule_id || dr.door_unlock_rule?.schedule_id;
                const schedName = dr.unlock_schedule?.name || dr.schedule?.name || dr.door_unlock_rule?.name;
                if (existing) {
                    if (schedId)
                        existing.schedule_id = String(schedId);
                    if (schedName)
                        existing.schedule_name = String(schedName);
                    if (dr.door_unlock_rule)
                        existing.door_unlock_rule = dr.door_unlock_rule;
                }
                else {
                    doorMap.set(doorId, {
                        id: doorId,
                        name: dr.name || dr.full_name || doorId,
                        door_lock_relay_status: (dr.door_lock_relay_status === 'unlock' ? 'unlock' : 'lock'),
                        door_position_status: dr.door_position_status ?? undefined,
                        type: dr.type || 'door',
                        full_name: dr.full_name || dr.name,
                        device_state: dr.device_state || 'connected',
                        schedule_id: schedId ? String(schedId) : undefined,
                        schedule_name: schedName ? String(schedName) : undefined,
                        door_unlock_rule: dr.door_unlock_rule,
                    });
                }
            }
        }
        catch { }
        return Array.from(doorMap.values());
    }
    /**
     * Get current status/details of a specific door.
     */
    async getDoorStatus(doorId) {
        const doors = await this.getDoors();
        const found = doors.find((d) => d.id === doorId);
        if (!found) {
            throw new Error(`Door ${doorId} not found in UniFi Access.`);
        }
        return found;
    }
    /**
     * Unlock a door.
     * Performs an immediate unlock (via UniFi OS v2 native dashboard location or hub relay)
     * and optionally applies a hold-open lock rule for the requested duration.
     *
     * @param doorId      - UniFi door ID
     * @param durationMin - How long to hold the door unlocked, in minutes (if supported)
     */
    async unlockDoor(doorId, durationMin = 0) {
        let unlocked = false;
        let lastError = null;
        let hubId = this.doorToHubMap.get(doorId);
        if (!hubId) {
            await this.populateDoorToHubMap().catch(() => { });
            hubId = this.doorToHubMap.get(doorId);
        }
        const attempts = [];
        const durationSeconds = durationMin > 0 ? durationMin * 60 : 5;
        // 1. UniFi OS Access v2 native dashboard locations unlock (door-level)
        attempts.push({
            name: `PUT /proxy/access/api/v2/dashboard/locations/${doorId}/unlock`,
            fn: () => this.http.put(`/proxy/access/api/v2/dashboard/locations/${encodeURIComponent(doorId)}/unlock`, { duration: durationSeconds }),
        });
        attempts.push({
            name: `PUT /proxy/access/api/v2/dashboard/locations/${doorId}/unlock (empty body)`,
            fn: () => this.http.put(`/proxy/access/api/v2/dashboard/locations/${encodeURIComponent(doorId)}/unlock`, {}),
        });
        attempts.push({
            name: `POST /proxy/access/api/v2/dashboard/locations/${doorId}/unlock`,
            fn: () => this.http.post(`/proxy/access/api/v2/dashboard/locations/${encodeURIComponent(doorId)}/unlock`, { duration: durationSeconds }),
        });
        // 2. Physical Hub relay_unlock (UniFi OS Access v2 hardware controller)
        if (hubId) {
            attempts.push({
                name: `PUT /proxy/access/api/v2/device/${hubId}/relay_unlock`,
                fn: () => this.http.put(`/proxy/access/api/v2/device/${encodeURIComponent(hubId)}/relay_unlock`, {}),
            });
            attempts.push({
                name: `PUT /proxy/access/api/v2/device/${hubId}/relay_unlock (door_id: ${doorId})`,
                fn: () => this.http.put(`/proxy/access/api/v2/device/${encodeURIComponent(hubId)}/relay_unlock`, { door_id: doorId }),
            });
            attempts.push({
                name: `POST /proxy/access/api/v2/device/${hubId}/relay_unlock`,
                fn: () => this.http.post(`/proxy/access/api/v2/device/${encodeURIComponent(hubId)}/relay_unlock`, { door_id: doorId }),
            });
        }
        // 3. Fallback: try doorId directly as device ID relay_unlock
        attempts.push({
            name: `PUT /proxy/access/api/v2/device/${doorId}/relay_unlock`,
            fn: () => this.http.put(`/proxy/access/api/v2/device/${encodeURIComponent(doorId)}/relay_unlock`, {}),
        });
        // 4. Developer API endpoints (if enabled on console)
        attempts.push({
            name: 'PUT /proxy/access/integration/v1/developer/doors/.../unlock',
            fn: () => this.http.put(`/proxy/access/integration/v1/developer/doors/${encodeURIComponent(doorId)}/unlock`, {}),
        }, {
            name: 'POST /proxy/access/integration/v1/developer/doors/.../unlock',
            fn: () => this.http.post(`/proxy/access/integration/v1/developer/doors/${encodeURIComponent(doorId)}/unlock`, {}),
        }, {
            name: 'PUT /api/v1/developer/doors/.../unlock',
            fn: () => this.http.put(`/api/v1/developer/doors/${encodeURIComponent(doorId)}/unlock`, {}),
        }, {
            name: 'POST /api/v1/developer/doors/.../unlock',
            fn: () => this.http.post(`/api/v1/developer/doors/${encodeURIComponent(doorId)}/unlock`, {}),
        });
        for (const att of attempts) {
            try {
                await att.fn();
                unlocked = true;
                logger_1.logger.info(`[UniFi] ✓ Door ${doorId} unlocked via ${att.name}`);
                break;
            }
            catch (err) {
                lastError = err;
                logger_1.logger.debug(`[UniFi] Unlock attempt ${att.name} failed: ${err.message}`);
            }
        }
        // 5. Apply temporary hold-open lock rule if duration was specified
        if (durationMin > 0) {
            const holdRulePayloads = [
                { type: 'custom', interval: durationMin },
                { type: 'keep_unlock' },
            ];
            let holdRuleApplied = false;
            const holdEndpoints = [
                `/proxy/access/api/v2/dashboard/locations/${encodeURIComponent(doorId)}/lock_rule`,
            ];
            if (hubId) {
                holdEndpoints.push(`/proxy/access/api/v2/device/${encodeURIComponent(hubId)}/lock_rule`);
            }
            holdEndpoints.push(`/proxy/access/api/v2/device/${encodeURIComponent(doorId)}/lock_rule`, `/proxy/access/integration/v1/developer/doors/${encodeURIComponent(doorId)}/lock_rule`, `/api/v1/developer/doors/${encodeURIComponent(doorId)}/lock_rule`);
            // Also try location unlock with full duration
            try {
                await this.http.put(`/proxy/access/api/v2/dashboard/locations/${encodeURIComponent(doorId)}/unlock`, { duration: durationMin * 60 });
                holdRuleApplied = true;
                unlocked = true;
                logger_1.logger.info(`[UniFi] Door ${doorId} hold rule applied via dashboard location unlock (${durationMin} min)`);
            }
            catch { }
            if (!holdRuleApplied) {
                for (const endpoint of holdEndpoints) {
                    for (const payload of holdRulePayloads) {
                        try {
                            await this.http.put(endpoint, payload);
                            holdRuleApplied = true;
                            logger_1.logger.info(`[UniFi] Door ${doorId} hold rule applied (${payload.type}) via ${endpoint}`);
                            break;
                        }
                        catch { }
                    }
                    if (holdRuleApplied)
                        break;
                }
            }
            if (holdRuleApplied) {
                unlocked = true;
            }
            else if (!unlocked) {
                throw new Error(`Failed to unlock door ${doorId}: ${lastError?.message || 'Unsupported door command'}`);
            }
            else {
                logger_1.logger.info(`[UniFi] Door ${doorId} unlocked via relay. Note: hold-open schedule rule is not supported by this hardware model.`);
            }
        }
        else if (!unlocked) {
            throw new Error(`Failed to unlock door ${doorId}: ${lastError?.message || 'Door unlock failed'}`);
        }
    }
    /**
     * Lock a door immediately, overriding/clearing any active hold rule.
     * @param doorId - UniFi door ID
     */
    async lockDoor(doorId) {
        let locked = false;
        let lastError = null;
        let hubId = this.doorToHubMap.get(doorId);
        if (!hubId) {
            await this.populateDoorToHubMap().catch(() => { });
            hubId = this.doorToHubMap.get(doorId);
        }
        // 1. Try native dashboard location lock first
        try {
            await this.http.put(`/proxy/access/api/v2/dashboard/locations/${encodeURIComponent(doorId)}/lock`, {});
            locked = true;
            logger_1.logger.info(`[UniFi] Door ${doorId} locked via dashboard locations lock`);
            return;
        }
        catch (err) {
            lastError = err;
            logger_1.logger.debug(`[UniFi] Dashboard location lock failed: ${err.message}`);
        }
        const resetPayloads = [
            { type: 'reset' },
            { type: 'lock_early' },
            { type: 'keep_lock' },
        ];
        const lockEndpoints = [];
        if (hubId) {
            lockEndpoints.push(`/proxy/access/api/v2/device/${encodeURIComponent(hubId)}/lock_rule`);
        }
        lockEndpoints.push(`/proxy/access/api/v2/dashboard/locations/${encodeURIComponent(doorId)}/lock_rule`, `/proxy/access/api/v2/device/${encodeURIComponent(doorId)}/lock_rule`, `/proxy/access/integration/v1/developer/doors/${encodeURIComponent(doorId)}/lock_rule`, `/api/v1/developer/doors/${encodeURIComponent(doorId)}/lock_rule`);
        for (const endpoint of lockEndpoints) {
            for (const payload of resetPayloads) {
                try {
                    await this.http.put(endpoint, payload);
                    locked = true;
                    logger_1.logger.info(`[UniFi] Door ${doorId} locked (${payload.type}) via ${endpoint}`);
                    return;
                }
                catch (err) {
                    lastError = err;
                }
            }
        }
        if (!locked) {
            throw new Error(`Failed to lock door ${doorId}: ${lastError?.message || 'Door lock failed'}`);
        }
    }
    /**
     * Verify connectivity by attempting to fetch the door list.
     * Returns true on success, false on any error.
     */
    async testConnection() {
        try {
            const doors = await this.getDoors();
            logger_1.logger.info(`UniFi connection OK — host: ${this.host} (${doors.length} doors found)`);
            return true;
        }
        catch (err) {
            logger_1.logger.error(`UniFi connection test failed for ${this.host}: ${String(err)}`);
            return false;
        }
    }
    /**
     * Fetch all schedules from UniFi Access.
     * Discovers global schedules, access policy door assignments, and
     * individual door-level unlock schedules.
     */
    async getSchedules() {
        const schedulesMap = new Map();
        // 1. Fetch from Developer API candidate endpoints (port 12445 & proxy endpoints)
        const scheduleEndpoints = this.getScheduleEndpoints();
        for (const endpoint of scheduleEndpoints) {
            try {
                const res = await this.http.get(endpoint);
                const rawList = Array.isArray(res.data?.data)
                    ? res.data.data
                    : Array.isArray(res.data?.data?.list)
                        ? res.data.data.list
                        : Array.isArray(res.data?.list)
                            ? res.data.list
                            : Array.isArray(res.data)
                                ? res.data
                                : null;
                if (rawList && rawList.length > 0) {
                    for (const item of rawList) {
                        const sched = normalizeUnifiSchedule(item);
                        if (sched.id)
                            schedulesMap.set(sched.id, sched);
                    }
                    logger_1.logger.info(`[UniFi] Fetched ${rawList.length} schedule(s) via ${endpoint}`);
                    break;
                }
            }
            catch { }
        }
        // 2. Also try v2 API schedules if Developer API yielded nothing or to merge
        try {
            const res = await this.http.get('/proxy/access/api/v2/schedules');
            const v2List = Array.isArray(res.data?.data) ? res.data.data : [];
            for (const item of v2List) {
                const sched = normalizeUnifiSchedule(item);
                if (sched.id && !schedulesMap.has(sched.id)) {
                    schedulesMap.set(sched.id, sched);
                }
            }
        }
        catch { }
        // 3. Fetch Access Policies to map schedules to door assignments
        const scheduleToDoors = new Map();
        const policyEndpoints = [...this.getAccessPolicyEndpoints(), '/proxy/access/api/v2/policies'];
        for (const endpoint of policyEndpoints) {
            try {
                const res = await this.http.get(endpoint);
                const rawPolicies = Array.isArray(res.data?.data)
                    ? res.data.data
                    : Array.isArray(res.data?.data?.list)
                        ? res.data.data.list
                        : Array.isArray(res.data)
                            ? res.data
                            : [];
                if (rawPolicies.length > 0) {
                    for (const pol of rawPolicies) {
                        const schedId = pol.schedule_id || pol.scheduleId;
                        if (!schedId)
                            continue;
                        const resources = pol.resources || pol.resource || pol.doors || [];
                        const entry = scheduleToDoors.get(schedId) || { doorIds: [], doorLabels: [] };
                        for (const r of resources) {
                            const dId = typeof r === 'string' ? r : (r.id || r.unique_id || r.door_id);
                            const dLabel = typeof r === 'object' ? (r.name || r.label) : undefined;
                            if (dId && !entry.doorIds.includes(String(dId))) {
                                entry.doorIds.push(String(dId));
                                if (dLabel)
                                    entry.doorLabels.push(String(dLabel));
                            }
                        }
                        scheduleToDoors.set(schedId, entry);
                    }
                    break;
                }
            }
            catch { }
        }
        // 4. Fetch door-specific unlock schedules for each individual door
        try {
            const allDoors = await this.getDoors();
            logger_1.logger.info(`[UniFi] Inspecting ${allDoors.length} door(s) for door-level unlock schedules…`);
            for (const dr of allDoors) {
                const doorId = String(dr.id || '');
                if (!doorId)
                    continue;
                const doorName = String(dr.name || dr.full_name || 'Door');
                let doorDetail = dr;
                try {
                    const detailRes = await this.getDoorDetails(doorId);
                    if (detailRes && typeof detailRes === 'object') {
                        doorDetail = { ...doorDetail, ...detailRes };
                    }
                }
                catch { }
                // 4a. Check for linked schedule ID on the door
                const linkedSchedId = String(doorDetail.unlock_schedule_id ||
                    doorDetail.schedule_id ||
                    doorDetail.keep_open_schedule_id ||
                    doorDetail.door_unlock_rule?.schedule_id ||
                    doorDetail.door_unlock_rule?.unlock_schedule_id ||
                    doorDetail.unlock_schedule?.id ||
                    doorDetail.schedule?.id ||
                    '');
                if (linkedSchedId) {
                    let sched = schedulesMap.get(linkedSchedId);
                    if (!sched) {
                        try {
                            sched = await this.getSchedule(linkedSchedId);
                            if (sched) {
                                schedulesMap.set(sched.id, sched);
                            }
                        }
                        catch (err) {
                            logger_1.logger.debug(`[UniFi] Could not fetch schedule ${linkedSchedId} for ${doorName}: ${err}`);
                        }
                    }
                    if (sched) {
                        const entry = scheduleToDoors.get(sched.id) || { doorIds: [], doorLabels: [] };
                        if (!entry.doorIds.includes(doorId)) {
                            entry.doorIds.push(doorId);
                            entry.doorLabels.push(doorName);
                        }
                        scheduleToDoors.set(sched.id, entry);
                    }
                }
                // 4b. Check for embedded unlock schedule object directly on the door
                const embedded = doorDetail.door_unlock_rule ||
                    doorDetail.unlock_schedule ||
                    doorDetail.schedule ||
                    doorDetail.keep_open_schedule ||
                    doorDetail.work_time_rule;
                if (embedded && typeof embedded === 'object') {
                    const schedId = String(embedded.id || embedded.unique_id || `door-sched-${doorId}`);
                    const schedName = String(embedded.name || `${doorName} Unlock Schedule`);
                    const normalized = normalizeUnifiSchedule({
                        ...embedded,
                        id: schedId,
                        name: schedName,
                        type: 'unlock',
                        doors: [{ id: doorId, name: doorName }],
                    });
                    // Check if this rule has active hours or days
                    const hasActiveSlots = normalized.weekly_schedule?.some((d) => d.active && d.slots.length > 0);
                    if (hasActiveSlots || !schedulesMap.has(schedId)) {
                        schedulesMap.set(schedId, normalized);
                        const entry = scheduleToDoors.get(schedId) || { doorIds: [], doorLabels: [] };
                        if (!entry.doorIds.includes(doorId)) {
                            entry.doorIds.push(doorId);
                            entry.doorLabels.push(doorName);
                        }
                        scheduleToDoors.set(schedId, entry);
                    }
                }
                // 4c. Check for pass_schedules or weekly_schedule directly on the door root
                const passList = doorDetail.pass_schedules || doorDetail.weekly_schedule || doorDetail.week_schedule;
                if (Array.isArray(passList) && passList.length > 0) {
                    const schedId = `door-sched-${doorId}`;
                    const schedName = `${doorName} Unlock Schedule`;
                    const normalized = normalizeUnifiSchedule({
                        id: schedId,
                        name: schedName,
                        type: 'unlock',
                        weekly_schedule: passList,
                        doors: [{ id: doorId, name: doorName }],
                    });
                    schedulesMap.set(schedId, normalized);
                    scheduleToDoors.set(schedId, { doorIds: [doorId], doorLabels: [doorName] });
                }
            }
        }
        catch (err) {
            logger_1.logger.warn(`[UniFi] Could not inspect doors for schedules: ${err}`);
        }
        // 5. Connect doors to schedules
        for (const [schedId, doors] of scheduleToDoors.entries()) {
            let sched = schedulesMap.get(schedId);
            if (sched) {
                if (!sched.door_ids)
                    sched.door_ids = [];
                if (!sched.door_labels)
                    sched.door_labels = [];
                for (const dId of doors.doorIds) {
                    if (!sched.door_ids.includes(dId))
                        sched.door_ids.push(dId);
                }
                for (const dLabel of doors.doorLabels) {
                    if (!sched.door_labels.includes(dLabel))
                        sched.door_labels.push(dLabel);
                }
            }
        }
        const allSchedules = Array.from(schedulesMap.values());
        logger_1.logger.info(`[UniFi] Resolved ${allSchedules.length} schedule(s) across doors`);
        return allSchedules;
    }
    /**
     * Fetch detailed door configuration from developer and proxy endpoints.
     */
    async getDoorDetails(doorId) {
        const endpoints = [
            ...this.getDeveloperEndpoints('doors', encodeURIComponent(doorId)),
            `/proxy/access/api/v2/door/${encodeURIComponent(doorId)}`,
            `/proxy/access/api/v2/doors/${encodeURIComponent(doorId)}`,
            `/proxy/access/api/v2/dashboard/locations/${encodeURIComponent(doorId)}`,
        ];
        for (const endpoint of endpoints) {
            try {
                const res = await this.http.get(endpoint);
                const data = res.data?.data || res.data;
                if (data && typeof data === 'object') {
                    return data;
                }
            }
            catch { }
        }
        return null;
    }
    /**
     * Get a single schedule by ID.
     */
    async getSchedule(scheduleId) {
        const endpoints = [
            ...this.getScheduleEndpoints(encodeURIComponent(scheduleId)),
            `/proxy/access/api/v2/schedule/${encodeURIComponent(scheduleId)}`,
        ];
        for (const endpoint of endpoints) {
            try {
                const res = await this.http.get(endpoint);
                const data = res.data?.data || res.data;
                if (data)
                    return normalizeUnifiSchedule(data);
            }
            catch { }
        }
        throw new Error(`Schedule ${scheduleId} not found in UniFi Access.`);
    }
    /**
     * Create a new schedule in UniFi Access.
     */
    async createSchedule(schedule) {
        const payload = serializeUnifiSchedule(schedule);
        try {
            const res = await this.http.post('/api/v1/developer/schedules', payload);
            if (res.data?.data) {
                logger_1.logger.info(`UniFi schedule created via Developer API: ${res.data.data.id || schedule.name}`);
                return normalizeUnifiSchedule(res.data.data);
            }
        }
        catch {
            // Fall through
        }
        try {
            const res = await this.http.post('/proxy/access/integration/v1/developer/schedules', payload);
            if (res.data?.data) {
                logger_1.logger.info(`UniFi schedule created via Integration API: ${res.data.data.id || schedule.name}`);
                return normalizeUnifiSchedule(res.data.data);
            }
        }
        catch {
            // Fall through
        }
        const res = await this.http.post('/proxy/access/api/v2/schedules', payload);
        logger_1.logger.info(`UniFi schedule created via v2 API: ${res.data?.data?.id || schedule.name}`);
        return normalizeUnifiSchedule(res.data?.data ?? payload);
    }
    /**
     * Update an existing schedule in UniFi Access.
     */
    async updateSchedule(scheduleId, updates) {
        const payload = serializeUnifiSchedule(updates);
        try {
            const res = await this.http.put(`/api/v1/developer/schedules/${encodeURIComponent(scheduleId)}`, payload);
            if (res.data?.data) {
                logger_1.logger.info(`UniFi schedule ${scheduleId} updated via Developer API.`);
                return normalizeUnifiSchedule(res.data.data);
            }
            return normalizeUnifiSchedule({ id: scheduleId, ...payload });
        }
        catch {
            // Fall through
        }
        try {
            const res = await this.http.put(`/proxy/access/integration/v1/developer/schedules/${encodeURIComponent(scheduleId)}`, payload);
            if (res.data?.data) {
                logger_1.logger.info(`UniFi schedule ${scheduleId} updated via Integration API.`);
                return normalizeUnifiSchedule(res.data.data);
            }
            return normalizeUnifiSchedule({ id: scheduleId, ...payload });
        }
        catch {
            // Fall through
        }
        const res = await this.http.put(`/proxy/access/api/v2/schedule/${encodeURIComponent(scheduleId)}`, payload);
        logger_1.logger.info(`UniFi schedule ${scheduleId} updated via v2 API.`);
        return normalizeUnifiSchedule(res.data?.data ?? { id: scheduleId, ...payload });
    }
    /**
     * Delete a schedule from UniFi Access.
     */
    async deleteSchedule(scheduleId) {
        try {
            await this.http.delete(`/api/v1/developer/schedules/${encodeURIComponent(scheduleId)}`);
            logger_1.logger.info(`UniFi schedule ${scheduleId} deleted via Developer API.`);
            return;
        }
        catch {
            // Fall through
        }
        try {
            await this.http.delete(`/proxy/access/integration/v1/developer/schedules/${encodeURIComponent(scheduleId)}`);
            logger_1.logger.info(`UniFi schedule ${scheduleId} deleted via Integration API.`);
            return;
        }
        catch {
            // Fall through
        }
        await this.http.delete(`/proxy/access/api/v2/schedule/${encodeURIComponent(scheduleId)}`);
        logger_1.logger.info(`UniFi schedule ${scheduleId} deleted via v2 API.`);
    }
    // ---------------------------------------------------------------------------
    // Visitor Management
    // ---------------------------------------------------------------------------
    /**
     * Generates prioritized candidate endpoints for the UniFi Access Developer API.
     * On local LAN setups, the Access Developer API runs on dedicated port 12445.
     * On port 443 console sessions, it is proxied under /proxy/access/integration/...
     * or /proxy/access/api/v1/developer/...
     */
    getDeveloperEndpoints(resource, subpath = '') {
        const endpoints = [];
        const cleanSub = subpath ? (subpath.startsWith('/') ? subpath : `/${subpath}`) : '';
        try {
            const u = new URL(this.host);
            // 1. Dedicated Developer API port (12445) on controller LAN
            endpoints.push(`${u.protocol}//${u.hostname}:12445/api/v1/developer/${resource}${cleanSub}`);
        }
        catch { }
        // 2. Port 443 proxy endpoints
        endpoints.push(`/proxy/access/integration/v1/developer/${resource}${cleanSub}`);
        endpoints.push(`/proxy/access/api/v1/developer/${resource}${cleanSub}`);
        endpoints.push(`/api/v1/developer/${resource}${cleanSub}`);
        return endpoints;
    }
    getVisitorEndpoints(subpath = '') {
        return this.getDeveloperEndpoints('visitors', subpath);
    }
    getScheduleEndpoints(subpath = '') {
        return this.getDeveloperEndpoints('schedules', subpath);
    }
    getAccessPolicyEndpoints(subpath = '') {
        return this.getDeveloperEndpoints('access_policies', subpath);
    }
    /**
     * Fetch all visitors from UniFi Access.
     */
    async getVisitors() {
        const endpoints = this.getVisitorEndpoints();
        let lastErr = null;
        for (const endpoint of endpoints) {
            try {
                const res = await this.http.get(endpoint);
                const rawList = Array.isArray(res.data?.data)
                    ? res.data.data
                    : Array.isArray(res.data?.data?.list)
                        ? res.data.data.list
                        : Array.isArray(res.data?.data?.visitors)
                            ? res.data.data.visitors
                            : Array.isArray(res.data?.list)
                                ? res.data.list
                                : Array.isArray(res.data)
                                    ? res.data
                                    : null;
                if (rawList !== null) {
                    logger_1.logger.info(`[UniFi] Fetched ${rawList.length} visitor(s) via ${endpoint}`);
                    return rawList.map((item) => normalizeUnifiVisitor(item));
                }
            }
            catch (err) {
                lastErr = err;
                logger_1.logger.debug(`[UniFi] getVisitors tried ${endpoint}: ${err.response?.status || err.message}`);
            }
        }
        // Fallback: v2 visitors endpoint
        try {
            const res = await this.http.get('/proxy/access/api/v2/visitors');
            const rawList = Array.isArray(res.data?.data) ? res.data.data : Array.isArray(res.data) ? res.data : null;
            if (rawList) {
                logger_1.logger.info(`[UniFi] Fetched ${rawList.length} visitor(s) via /proxy/access/api/v2/visitors`);
                return rawList.map((item) => normalizeUnifiVisitor(item));
            }
        }
        catch (err) {
            lastErr = err;
        }
        if (lastErr) {
            logger_1.logger.warn(`[UniFi] getVisitors failed across all endpoints: ${lastErr.message}`);
        }
        return [];
    }
    /**
     * Get a single visitor by ID.
     */
    async getVisitor(visitorId) {
        const endpoints = this.getVisitorEndpoints(`/${encodeURIComponent(visitorId)}`);
        let lastErr = null;
        for (const endpoint of endpoints) {
            try {
                const res = await this.http.get(endpoint);
                const rawData = res.data?.data || res.data;
                if (rawData && (rawData.id || rawData.unique_id || rawData.first_name || rawData.name)) {
                    return normalizeUnifiVisitor(rawData);
                }
            }
            catch (err) {
                lastErr = err;
                logger_1.logger.debug(`[UniFi] getVisitor tried ${endpoint}: ${err.response?.status || err.message}`);
            }
        }
        throw new Error(`Visitor ${visitorId} not found in UniFi Access. Last error: ${lastErr?.response?.data?.msg || lastErr?.response?.data?.message || lastErr?.message || lastErr}`);
    }
    /**
     * Create a new visitor in UniFi Access.
     */
    async createVisitor(visitor) {
        const payload = serializeUnifiVisitor(visitor);
        const endpoints = this.getVisitorEndpoints();
        let lastErr = null;
        for (const endpoint of endpoints) {
            try {
                const res = await this.http.post(endpoint, payload);
                const rawData = res.data?.data || res.data;
                if (rawData) {
                    logger_1.logger.info(`[UniFi] Visitor ${rawData.id || visitor.first_name} created successfully via ${endpoint}`);
                    return normalizeUnifiVisitor(rawData);
                }
            }
            catch (err) {
                lastErr = err;
                const status = err.response?.status;
                const msg = err.response?.data?.msg || err.response?.data?.message || err.message;
                logger_1.logger.warn(`[UniFi] createVisitor tried ${endpoint} -> status ${status || 'ERR'}: ${msg}`);
            }
        }
        throw new Error(`Failed to create visitor in UniFi Access across all endpoints. Last error: ${lastErr?.response?.data?.msg || lastErr?.response?.data?.message || lastErr?.message || lastErr}`);
    }
    /**
     * Update an existing visitor in UniFi Access.
     */
    async updateVisitor(visitorId, updates) {
        const payload = serializeUnifiVisitor(updates);
        const endpoints = this.getVisitorEndpoints(`/${encodeURIComponent(visitorId)}`);
        let lastErr = null;
        for (const endpoint of endpoints) {
            try {
                const res = await this.http.put(endpoint, payload);
                const rawData = res.data?.data || res.data;
                if (rawData) {
                    logger_1.logger.info(`[UniFi] Visitor ${visitorId} updated successfully via ${endpoint}`);
                    return normalizeUnifiVisitor(rawData);
                }
            }
            catch (err) {
                lastErr = err;
                logger_1.logger.debug(`[UniFi] updateVisitor tried ${endpoint} -> ${err.response?.status || err.message}`);
            }
        }
        throw new Error(`Failed to update visitor ${visitorId} in UniFi Access. Last error: ${lastErr?.response?.data?.msg || lastErr?.response?.data?.message || lastErr?.message || lastErr}`);
    }
    /**
     * Delete or revoke a visitor from UniFi Access.
     */
    async deleteVisitor(visitorId) {
        const endpoints = this.getVisitorEndpoints(`/${encodeURIComponent(visitorId)}`);
        let lastErr = null;
        for (const endpoint of endpoints) {
            try {
                await this.http.delete(endpoint);
                logger_1.logger.info(`[UniFi] Visitor ${visitorId} deleted successfully via ${endpoint}`);
                return;
            }
            catch (err) {
                lastErr = err;
                logger_1.logger.debug(`[UniFi] deleteVisitor tried ${endpoint} -> ${err.response?.status || err.message}`);
            }
        }
        throw new Error(`Failed to delete visitor ${visitorId} in UniFi Access. Last error: ${lastErr?.response?.data?.msg || lastErr?.response?.data?.message || lastErr?.message || lastErr}`);
    }
    /**
     * Fetch system access logs from UniFi Access.
     * Tracks who opened or closed doors, timestamps, and access methods
     * (NFC Card/Fob, Keypad PIN, Mobile Tap, Hand Wave, Remote, Face).
     */
    async getAccessLogs(options) {
        const endpoints = [
            ...this.getDeveloperEndpoints('system/logs'),
            '/proxy/access/api/v2/activities',
            '/proxy/access/api/v2/events',
        ];
        const body = {
            topic: options?.topic || 'door_openings',
            page_num: 1,
            page_size: options?.pageSize || 50,
        };
        if (options?.since)
            body.since = options.since;
        if (options?.until)
            body.until = options.until;
        for (const endpoint of endpoints) {
            try {
                let res;
                if (endpoint.includes('/v2/')) {
                    res = await this.http.get(endpoint, {
                        params: {
                            page: 1,
                            page_size: options?.pageSize || 50,
                            since: options?.since,
                        },
                    });
                }
                else {
                    res = await this.http.post(endpoint, body);
                }
                const rawList = Array.isArray(res.data?.data)
                    ? res.data.data
                    : Array.isArray(res.data?.data?.list)
                        ? res.data.data.list
                        : Array.isArray(res.data?.data?.activities)
                            ? res.data.data.activities
                            : Array.isArray(res.data?.list)
                                ? res.data.list
                                : Array.isArray(res.data)
                                    ? res.data
                                    : null;
                if (rawList !== null && rawList.length > 0) {
                    logger_1.logger.info(`[UniFi] Fetched ${rawList.length} access log(s) via ${endpoint}`);
                    return rawList.map((item) => normalizeAccessLogEntry(item));
                }
            }
            catch (err) {
                logger_1.logger.debug(`[UniFi] getAccessLogs tried ${endpoint} -> ${err.response?.status || err.message}`);
            }
        }
        return [];
    }
}
exports.UnifiAccessClient = UnifiAccessClient;
