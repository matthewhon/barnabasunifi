"use strict";
/**
 * firebase/userSync.ts
 * Syncs UniFi Access policies and local users into Firestore.
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.syncAccessPolicies = syncAccessPolicies;
exports.startPolicySyncInterval = startPolicySyncInterval;
exports.syncUsers = syncUsers;
const firebase_1 = require("../firebase");
const logger_1 = require("../logger");
const admin = __importStar(require("firebase-admin"));
function cleanFirestoreRecord(obj) {
    const clean = (val) => {
        if (val === undefined)
            return null;
        if (val === null || typeof val !== 'object')
            return val;
        if (val instanceof Date)
            return val.toISOString();
        if (Array.isArray(val)) {
            return val.filter((item) => item !== undefined).map(clean);
        }
        const res = {};
        for (const [k, v] of Object.entries(val)) {
            if (v !== undefined) {
                res[k] = clean(v);
            }
        }
        return res;
    };
    return clean(obj);
}
/**
 * Fetch all access policies from UniFi Access and upsert into Firestore.
 */
async function syncAccessPolicies(orgId, unifiClient) {
    const db = (0, firebase_1.getDb)();
    let policies = [];
    try {
        policies = await unifiClient.getAccessPolicies();
    }
    catch (err) {
        logger_1.logger.error(`[PolicySync] Failed to fetch access policies from UniFi: ${String(err)}`);
        return [];
    }
    if (policies.length === 0) {
        logger_1.logger.info('[PolicySync] No access policies returned from UniFi Access.');
        return [];
    }
    const batch = db.batch();
    const now = admin.firestore.Timestamp.now();
    for (const policy of policies) {
        if (!policy.id)
            continue;
        const policyRef = db.doc(`organizations/${orgId}/access_policies/${policy.id}`);
        const record = cleanFirestoreRecord({
            ...policy,
            org_id: orgId,
            last_synced: now,
            updated_at: now,
        });
        batch.set(policyRef, record, { merge: true });
    }
    try {
        await batch.commit();
        logger_1.logger.info(`[PolicySync] ✓ Upserted ${policies.length} access policy(ies) into Firestore.`);
    }
    catch (err) {
        logger_1.logger.error(`[PolicySync] Failed to commit access policies batch to Firestore: ${String(err)}`);
    }
    return policies;
}
/**
 * Start a recurring access policy sync on a fixed interval.
 * Returns a cleanup function that stops the interval.
 */
function startPolicySyncInterval(orgId, unifiClient, intervalMs) {
    logger_1.logger.info(`[PolicySync] Starting access policy sync interval — every ${intervalMs / 1000}s for org: ${orgId}`);
    const handle = setInterval(() => {
        syncAccessPolicies(orgId, unifiClient).catch((err) => {
            logger_1.logger.error(`[PolicySync] Unhandled error in policy sync interval: ${String(err)}`);
        });
    }, intervalMs);
    if (handle.unref)
        handle.unref();
    return () => {
        clearInterval(handle);
        logger_1.logger.info('[PolicySync] Access policy sync interval stopped.');
    };
}
/**
 * Fetch all users from UniFi Access and upsert into Firestore unifi_users.
 */
async function syncUsers(orgId, unifiClient) {
    const db = (0, firebase_1.getDb)();
    let users = [];
    try {
        users = await unifiClient.getUsers();
    }
    catch (err) {
        logger_1.logger.error(`[UserSync] Failed to fetch users from UniFi: ${String(err)}`);
        return [];
    }
    if (users.length === 0) {
        logger_1.logger.info('[UserSync] No users returned from UniFi Access.');
        return [];
    }
    const batch = db.batch();
    const now = admin.firestore.Timestamp.now();
    for (const user of users) {
        if (!user.id)
            continue;
        const userRef = db.doc(`organizations/${orgId}/unifi_users/${user.id}`);
        const record = cleanFirestoreRecord({
            ...user,
            org_id: orgId,
            last_synced: now,
            updated_at: now,
        });
        batch.set(userRef, record, { merge: true });
    }
    try {
        await batch.commit();
        logger_1.logger.info(`[UserSync] ✓ Upserted ${users.length} UniFi user(s) into Firestore.`);
    }
    catch (err) {
        logger_1.logger.error(`[UserSync] Failed to commit users batch to Firestore: ${String(err)}`);
    }
    return users;
}
