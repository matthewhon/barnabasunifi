"use strict";
/**
 * firebase/scheduleSync.ts
 * Syncs UniFi Access schedules into Firestore.
 *
 * Fetches all schedules from the local UniFi console and upserts them
 * into /organizations/{orgId}/unifi_schedules/{scheduleId}. Runs on startup
 * and on an interval to keep the cloud dashboard in sync with UniFi schedules.
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.syncSchedules = syncSchedules;
exports.startScheduleSyncInterval = startScheduleSyncInterval;
const firebase_1 = require("../firebase");
const logger_1 = require("../logger");
const admin = __importStar(require("firebase-admin"));
/**
 * Fetch all schedules from UniFi Access and upsert into Firestore.
 */
async function syncSchedules(orgId, unifiClient) {
    const db = (0, firebase_1.getDb)();
    let schedules = [];
    try {
        schedules = await unifiClient.getSchedules();
    }
    catch (err) {
        logger_1.logger.error(`[ScheduleSync] Failed to fetch schedules from UniFi: ${String(err)}`);
        return [];
    }
    if (schedules.length === 0) {
        logger_1.logger.info('[ScheduleSync] No schedules returned from UniFi Access.');
        return [];
    }
    const isUuid = (str) => /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(str.trim());
    const batch = db.batch();
    const now = admin.firestore.Timestamp.now();
    const validScheduleIds = new Set();
    for (const schedule of schedules) {
        if (!schedule.id)
            continue;
        validScheduleIds.add(schedule.id);
        const scheduleRef = db.doc(`organizations/${orgId}/unifi_schedules/${schedule.id}`);
        const record = {
            ...schedule,
            org_id: orgId,
            last_synced: now,
            sync_status: 'synced',
            sync_error: null,
            updated_at: now,
        };
        batch.set(scheduleRef, record, { merge: true });
        // Link assigned doors directly in Firestore doors collection
        if (schedule.door_ids && Array.isArray(schedule.door_ids)) {
            for (const dId of schedule.door_ids) {
                const doorRef = db.doc(`organizations/${orgId}/doors/${dId}`);
                batch.set(doorRef, {
                    schedule_id: schedule.id,
                    schedule_name: schedule.name,
                }, { merge: true });
            }
        }
    }
    // Prune phantom or orphaned schedule documents in Firestore
    try {
        const existingSchedsSnap = await db.collection(`organizations/${orgId}/unifi_schedules`).get();
        let prunedSchedCount = 0;
        for (const docSnap of existingSchedsSnap.docs) {
            const docId = docSnap.id;
            const data = docSnap.data();
            const schedName = String(data.name || '').trim();
            const hasDoors = Array.isArray(data.door_ids) && data.door_ids.length > 0;
            const hasActiveSlots = Array.isArray(data.weekly_schedule) && data.weekly_schedule.some((d) => d.active && d.slots?.length > 0);
            // If document is not in valid schedules and looks like a phantom UUID / empty schedule
            if (!validScheduleIds.has(docId)) {
                if (isUuid(docId) || isUuid(schedName) || !schedName || schedName === 'Schedule') {
                    if (!hasDoors && !hasActiveSlots) {
                        batch.delete(docSnap.ref);
                        prunedSchedCount++;
                        logger_1.logger.info(`[ScheduleSync] Pruning phantom schedule ${docId} (name: "${schedName}")`);
                    }
                }
            }
        }
        if (prunedSchedCount > 0) {
            logger_1.logger.info(`[ScheduleSync] Pruned ${prunedSchedCount} phantom schedule document(s) from Firestore.`);
        }
    }
    catch (pruneErr) {
        logger_1.logger.debug(`[ScheduleSync] Error during phantom schedule pruning: ${pruneErr}`);
    }
    try {
        await batch.commit();
        logger_1.logger.info(`[ScheduleSync] Synced ${schedules.length} schedule(s) for org: ${orgId}`);
    }
    catch (err) {
        logger_1.logger.error(`[ScheduleSync] Batch write failed: ${String(err)}`);
    }
    return schedules;
}
/**
 * Start a recurring schedule sync on a fixed interval.
 * Returns a cleanup function that stops the interval.
 */
function startScheduleSyncInterval(orgId, unifiClient, intervalMs) {
    logger_1.logger.info(`[ScheduleSync] Starting schedule sync interval — every ${intervalMs / 1000}s for org: ${orgId}`);
    const handle = setInterval(() => {
        syncSchedules(orgId, unifiClient).catch((err) => {
            logger_1.logger.error(`[ScheduleSync] Unhandled error in schedule sync interval: ${String(err)}`);
        });
    }, intervalMs);
    if (handle.unref)
        handle.unref();
    return () => {
        clearInterval(handle);
        logger_1.logger.info('[ScheduleSync] Schedule sync interval stopped.');
    };
}
