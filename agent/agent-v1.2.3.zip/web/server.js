"use strict";
/**
 * server.ts
 * Embedded Express Web Server for Agent Configuration & Management.
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.startWebServer = startWebServer;
const express_1 = __importDefault(require("express"));
const cors_1 = __importDefault(require("cors"));
const multer_1 = __importDefault(require("multer"));
const fs = __importStar(require("fs"));
const path = __importStar(require("path"));
const os = __importStar(require("os"));
const logger_1 = require("../logger");
const config_1 = require("../config");
const axios_1 = __importDefault(require("axios"));
const scanner_1 = require("./scanner");
const access_1 = require("../unifi/access");
const updateChecker_1 = require("../firebase/updateChecker");
function getLocalIp() {
    try {
        const interfaces = os.networkInterfaces();
        for (const name of Object.keys(interfaces)) {
            const iface = interfaces[name];
            if (!iface)
                continue;
            for (const alias of iface) {
                if (alias.family === 'IPv4' && !alias.internal) {
                    return alias.address;
                }
            }
        }
    }
    catch { }
    return null;
}
function startWebServer(port, state) {
    const app = (0, express_1.default)();
    app.use((0, cors_1.default)());
    app.use(express_1.default.json());
    const upload = (0, multer_1.default)({ storage: multer_1.default.memoryStorage(), limits: { fileSize: 5 * 1024 * 1024 } });
    // Resolve public directory for HTML assets
    const publicDirCandidates = [
        path.join(__dirname, 'public'),
        path.join(__dirname, '../../src/web/public'),
        path.join(process.cwd(), 'src/web/public'),
        path.join(process.cwd(), 'dist/web/public'),
    ];
    let publicDir = publicDirCandidates[0];
    for (const dir of publicDirCandidates) {
        if (fs.existsSync(dir)) {
            publicDir = dir;
            break;
        }
    }
    // Serve static UI
    app.use(express_1.default.static(publicDir));
    app.get('/', (_req, res) => {
        res.sendFile(path.join(publicDir, 'index.html'));
    });
    // GET /api/status
    app.get('/api/status', (_req, res) => {
        const configStatus = (0, config_1.getConfigurationStatus)();
        const serviceAccountPath = process.env.FIREBASE_SERVICE_ACCOUNT_PATH || './service-account.json';
        const saPresent = (0, config_1.isServiceAccountPresent)(serviceAccountPath);
        res.json({
            status: state.status,
            unifiConnected: state.unifiConnected,
            firebaseConnected: state.firebaseConnected,
            serviceAccountPresent: saPresent,
            doorCount: state.doorCount,
            lastSync: state.lastSync ? state.lastSync.toISOString() : null,
            error: state.errorMessage,
            localIp: getLocalIp(),
            hostname: os.hostname(),
            platform: `${os.type()} ${os.release()}`,
            ...(() => {
                const upd = (0, updateChecker_1.getUpdateState)();
                return {
                    version: upd.currentVersion,
                    latestVersion: upd.latestVersion,
                    updateAvailable: upd.updateAvailable,
                    updateChangelog: upd.changelog,
                };
            })(),
            config: configStatus.config
                ? {
                    unifiHost: configStatus.config.unifiHost,
                    unifiAccessToken: configStatus.config.unifiAccessToken || '',
                    orgId: configStatus.config.orgId,
                    agentId: configStatus.config.agentId,
                    agentLabel: configStatus.config.agentLabel,
                    firebaseProjectId: configStatus.config.firebaseProjectId,
                    skipTlsVerify: configStatus.config.skipTlsVerify,
                }
                : {
                    unifiHost: process.env.UNIFI_HOST || '',
                    unifiAccessToken: process.env.UNIFI_ACCESS_TOKEN || '',
                    orgId: process.env.ORG_ID || '',
                    agentId: process.env.AGENT_ID || 'agent-main-campus',
                    agentLabel: process.env.AGENT_LABEL || 'Main Campus Agent',
                    firebaseProjectId: process.env.FIREBASE_PROJECT_ID || 'barnabasunfi',
                    skipTlsVerify: process.env.SKIP_TLS_VERIFY !== 'false',
                },
            missing: configStatus.missing,
        });
    });
    // GET /api/logs
    app.get('/api/logs', (_req, res) => {
        res.json({ logs: (0, logger_1.getRecentLogs)() });
    });
    // POST /api/scan-unifi
    app.post('/api/scan-unifi', async (req, res) => {
        const subnet = req.body?.subnet || '192.168.1';
        logger_1.logger.info(`[WebUI] Scanning subnet ${subnet}.0/24 for UniFi consoles…`);
        try {
            const consoles = await (0, scanner_1.scanSubnet)(subnet);
            logger_1.logger.info(`[WebUI] Scan complete — found ${consoles.length} candidate(s).`);
            res.json({ consoles });
        }
        catch (err) {
            logger_1.logger.error(`[WebUI] Subnet scan failed: ${err.message}`);
            res.status(500).json({ error: err.message });
        }
    });
    // POST /api/test-unifi
    app.post('/api/test-unifi', async (req, res) => {
        const { host, token, skipTls } = req.body || {};
        if (!host) {
            res.status(400).json({ ok: false, error: 'Host is required' });
            return;
        }
        try {
            const client = new access_1.UnifiAccessClient(host, token || '', Boolean(skipTls));
            const connected = await client.testConnection();
            if (!connected) {
                res.json({ ok: false, error: 'Could not connect to host. Check IP or self-signed cert setting.' });
                return;
            }
            const doors = await client.getDoors();
            res.json({
                ok: true,
                doorCount: doors.length,
                doors: doors.map((d) => ({ id: d.id, name: d.name, status: d.door_lock_relay_status })),
            });
        }
        catch (err) {
            res.json({ ok: false, error: err.message });
        }
    });
    // POST /api/upload-service-account
    app.post('/api/upload-service-account', upload.single('serviceAccount'), (req, res) => {
        if (!req.file) {
            res.status(400).json({ ok: false, error: 'No file uploaded' });
            return;
        }
        try {
            const content = req.file.buffer.toString('utf-8');
            const parsed = JSON.parse(content);
            if (!parsed.project_id || !parsed.private_key) {
                res.status(400).json({ ok: false, error: 'Invalid service account JSON: missing project_id or private_key' });
                return;
            }
            const targetPath = path.resolve(process.env.FIREBASE_SERVICE_ACCOUNT_PATH || './service-account.json');
            fs.writeFileSync(targetPath, content, 'utf-8');
            logger_1.logger.info(`[WebUI] Service account key saved successfully to ${targetPath} (project: ${parsed.project_id})`);
            res.json({ ok: true, projectId: parsed.project_id });
        }
        catch (err) {
            res.status(400).json({ ok: false, error: `Invalid JSON file: ${err.message}` });
        }
    });
    // POST /api/register-token
    app.post('/api/register-token', async (req, res) => {
        const { token, agentId, label, unifiHost } = req.body || {};
        if (!token || typeof token !== 'string') {
            res.status(400).json({ ok: false, error: 'Connection token is required.' });
            return;
        }
        try {
            // Decode token to inspect payload
            const base64Str = token.replace(/^UPCO_/, '').trim();
            const raw = Buffer.from(base64Str, 'base64').toString('utf-8');
            const parsed = JSON.parse(raw);
            const endpoint = parsed.endpoint ||
                `https://us-central1-${parsed.projectId || 'barnabasunfi'}.cloudfunctions.net/registerAgentWithToken`;
            logger_1.logger.info(`[WebUI] Registering agent with cloud endpoint: ${endpoint} for org: ${parsed.orgId}…`);
            // Call cloud function
            const response = await axios_1.default.post(endpoint, {
                token,
                agentId: agentId || process.env.AGENT_ID || 'agent-main-campus',
                label: label || process.env.AGENT_LABEL || 'Main Campus Agent',
                unifiHost: unifiHost || process.env.UNIFI_HOST || '',
                version: process.env.npm_package_version || '1.0.0',
            }, { timeout: 15000 });
            if (response.data?.ok) {
                const { orgId, customToken, projectId, unifiHost: returnedHost, unifiAccessToken, skipTlsVerify } = response.data;
                // Save to config
                (0, config_1.saveConfig)({
                    ORG_ID: orgId,
                    FIREBASE_PROJECT_ID: projectId || 'barnabasunfi',
                    AGENT_ID: agentId || process.env.AGENT_ID || 'agent-main-campus',
                    AGENT_LABEL: label || process.env.AGENT_LABEL || 'Main Campus Agent',
                    AGENT_AUTH_TOKEN: customToken,
                    CONNECTION_TOKEN: token,
                    ...(returnedHost ? { UNIFI_HOST: returnedHost } : {}),
                    ...(unifiAccessToken ? { UNIFI_ACCESS_TOKEN: unifiAccessToken } : {}),
                    ...(skipTlsVerify !== undefined ? { SKIP_TLS_VERIFY: String(skipTlsVerify) } : {}),
                });
                logger_1.logger.info(`[WebUI] Successfully registered and associated with organization: ${orgId}!`);
                if (state.onRestartRequest) {
                    await state.onRestartRequest();
                }
                res.json({
                    ok: true,
                    orgId,
                    agentId: agentId || process.env.AGENT_ID || 'agent-main-campus',
                    agentLabel: label || process.env.AGENT_LABEL || 'Main Campus Agent',
                    unifiHost: returnedHost || unifiHost,
                    unifiAccessToken: unifiAccessToken || '',
                    skipTlsVerify: skipTlsVerify ?? true,
                    projectId: projectId || 'barnabasunfi',
                    message: 'Agent registered and linked successfully! Credentials pulled from cloud.',
                });
            }
            else {
                res.status(400).json({ ok: false, error: response.data?.error || 'Registration failed' });
            }
        }
        catch (err) {
            const msg = err.response?.data?.error || err.message;
            logger_1.logger.error(`[WebUI] Registration handshake error: ${msg}`);
            res.status(500).json({ ok: false, error: msg });
        }
    });
    // GET /api/version — returns version info and update status
    app.get('/api/version', (_req, res) => {
        const upd = (0, updateChecker_1.getUpdateState)();
        res.json({
            currentVersion: upd.currentVersion,
            latestVersion: upd.latestVersion,
            updateAvailable: upd.updateAvailable,
            changelog: upd.changelog,
            lastChecked: upd.lastChecked?.toISOString() ?? null,
            applying: upd.applying,
            error: upd.error,
        });
    });
    // POST /api/check-update — manually trigger an update check
    app.post('/api/check-update', async (_req, res) => {
        logger_1.logger.info('[WebUI] Manual update check triggered.');
        try {
            const result = await (0, updateChecker_1.checkForUpdate)();
            res.json({ ok: true, ...result });
        }
        catch (err) {
            res.status(500).json({ ok: false, error: err.message });
        }
    });
    // POST /api/apply-update — download and apply pending update, then restart
    app.post('/api/apply-update', async (_req, res) => {
        const upd = (0, updateChecker_1.getUpdateState)();
        if (!upd.updateAvailable) {
            res.status(400).json({ ok: false, error: 'No update available.' });
            return;
        }
        if (upd.applying) {
            res.status(409).json({ ok: false, error: 'Update is already in progress.' });
            return;
        }
        logger_1.logger.info('[WebUI] Apply update requested.');
        res.json({ ok: true, message: `Downloading and applying v${upd.latestVersion}… Agent will restart.` });
        // Apply asynchronously after responding
        setTimeout(() => {
            (0, updateChecker_1.applyPendingUpdate)(state.onRestartRequest).catch((err) => {
                logger_1.logger.error(`[WebUI] Apply update failed: ${err.message}`);
            });
        }, 100);
    });
    // POST /api/sync-doors — force door discovery sync
    app.post('/api/sync-doors', async (_req, res) => {
        logger_1.logger.info('[WebUI] Manual door sync requested.');
        if (!state.onSyncDoors) {
            res.status(503).json({ ok: false, error: 'Door sync handler not initialized or agent offline.' });
            return;
        }
        try {
            const count = await state.onSyncDoors();
            res.json({ ok: true, count, message: `Discovered and synced ${count} door(s).` });
        }
        catch (err) {
            res.status(500).json({ ok: false, error: err.message });
        }
    });
    // POST /api/save-config
    app.post('/api/save-config', async (req, res) => {
        const updates = req.body || {};
        // Don't wipe existing UNIFI_ACCESS_TOKEN if empty string was submitted
        if (updates.UNIFI_ACCESS_TOKEN === '' && (process.env.UNIFI_ACCESS_TOKEN || '').trim()) {
            delete updates.UNIFI_ACCESS_TOKEN;
        }
        try {
            (0, config_1.saveConfig)(updates);
            logger_1.logger.info('[WebUI] Configuration updated via Web UI.');
            if (state.onRestartRequest) {
                await state.onRestartRequest();
            }
            res.json({ ok: true });
        }
        catch (err) {
            logger_1.logger.error(`[WebUI] Failed to save configuration: ${err.message}`);
            res.status(500).json({ ok: false, error: err.message });
        }
    });
    // POST /api/restart — trigger a bridge restart
    app.post('/api/restart', async (_req, res) => {
        logger_1.logger.info('[WebUI] Restart requested via API.');
        res.json({ ok: true, message: 'Restarting agent…' });
        if (state.onRestartRequest) {
            setTimeout(() => state.onRestartRequest(), 500);
        }
    });
    // POST /api/update-agent — upload a zip of new dist JS files and restart
    // Accepts multipart form with field "update" containing a zip file
    const updateUpload = (0, multer_1.default)({ storage: multer_1.default.memoryStorage(), limits: { fileSize: 50 * 1024 * 1024 } });
    app.post('/api/update-agent', updateUpload.single('update'), async (req, res) => {
        if (!req.file) {
            res.status(400).json({ ok: false, error: 'No file uploaded. POST multipart with field "update" containing a zip.' });
            return;
        }
        try {
            const { execSync } = await Promise.resolve().then(() => __importStar(require('child_process')));
            const os = await Promise.resolve().then(() => __importStar(require('os')));
            const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'agent-update-'));
            const zipPath = path.join(tmpDir, 'update.zip');
            fs.writeFileSync(zipPath, req.file.buffer);
            // Determine dist directory (where the running code lives)
            const distDir = path.resolve(__dirname, '..');
            logger_1.logger.info(`[WebUI] Applying update to dist at ${distDir}…`);
            execSync(`unzip -o "${zipPath}" -d "${distDir}"`, { stdio: 'pipe' });
            fs.rmSync(tmpDir, { recursive: true, force: true });
            logger_1.logger.info('[WebUI] Agent update applied successfully. Restarting…');
            res.json({ ok: true, message: 'Update applied. Agent restarting…' });
            if (state.onRestartRequest) {
                setTimeout(() => state.onRestartRequest(), 500);
            }
        }
        catch (err) {
            logger_1.logger.error(`[WebUI] Update failed: ${err.message}`);
            res.status(500).json({ ok: false, error: err.message });
        }
    });
    app.listen(port, '0.0.0.0', () => {
        logger_1.logger.info(`🌐 Web Configuration Portal running at http://localhost:${port}`);
    });
    return app;
}
