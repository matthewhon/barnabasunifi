"use strict";
/**
 * index.ts
 * Main entry point for the UnFi-PCO Local Agent.
 *
 * Boots an always-on Web Configuration & Management Portal on port 8080.
 * If credentials and configuration are present, starts the background bridge worker.
 * If configuration is incomplete, stays alive in setup mode and allows configuration
 * via the web portal.
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
require("dotenv/config");
const config_1 = require("./config");
const logger_1 = require("./logger");
const firebase_1 = require("./firebase");
const access_1 = require("./unifi/access");
const heartbeat_1 = require("./firebase/heartbeat");
const doorSync_1 = require("./firebase/doorSync");
const scheduleSync_1 = require("./firebase/scheduleSync");
const visitorSync_1 = require("./firebase/visitorSync");
const accessLogSync_1 = require("./firebase/accessLogSync");
const commandListener_1 = require("./firebase/commandListener");
const updateChecker_1 = require("./firebase/updateChecker");
const server_1 = require("./web/server");
const scanner_1 = require("./web/scanner");
const axios_1 = __importDefault(require("axios"));
const admin = __importStar(require("firebase-admin"));
// ---------------------------------------------------------------------------
// Lifecycle State
// ---------------------------------------------------------------------------
let cleanupPreviousWorker = null;
const bridgeState = {
    status: 'unconfigured',
    unifiConnected: false,
    firebaseConnected: false,
    doorCount: 0,
    lastSync: null,
    onRestartRequest: async () => {
        logger_1.logger.info('[Bridge] Reload/restart requested — exiting process for supervisor/Docker reboot…');
        setTimeout(() => {
            process.exit(0);
        }, 500);
    },
};
/**
 * Automatically exchange CONNECTION_TOKEN with Cloud Functions to configure the agent.
 */
async function attemptAutoRegistration(connectionToken) {
    try {
        const base64Str = connectionToken.replace(/^UPCO_/, '').trim();
        const raw = Buffer.from(base64Str, 'base64').toString('utf-8');
        const parsed = JSON.parse(raw);
        const endpoint = parsed.endpoint ||
            `https://us-central1-${parsed.projectId || 'barnabasunfi'}.cloudfunctions.net/registerAgentWithToken`;
        logger_1.logger.info(`[AutoRegister] Discovered CONNECTION_TOKEN. Contacting pairing endpoint: ${endpoint}…`);
        const response = await axios_1.default.post(endpoint, {
            token: connectionToken,
            agentId: process.env.AGENT_ID || 'agent-main-campus',
            label: process.env.AGENT_LABEL || 'Main Campus Agent',
            unifiHost: process.env.UNIFI_HOST || '',
            version: process.env.npm_package_version || '1.0.0',
        }, { timeout: 15000 });
        if (response.data?.ok) {
            const { orgId, customToken, projectId, unifiHost, unifiAccessToken, skipTlsVerify } = response.data;
            logger_1.logger.info(`[AutoRegister] ✓ Paired successfully with Organization: ${orgId}`);
            (0, config_1.saveConfig)({
                ORG_ID: orgId,
                FIREBASE_PROJECT_ID: projectId || 'barnabasunfi',
                AGENT_AUTH_TOKEN: customToken,
                ...(unifiHost ? { UNIFI_HOST: unifiHost } : {}),
                ...(unifiAccessToken ? { UNIFI_ACCESS_TOKEN: unifiAccessToken } : {}),
                ...(skipTlsVerify !== undefined ? { SKIP_TLS_VERIFY: String(skipTlsVerify) } : {}),
            });
            return true;
        }
        else {
            logger_1.logger.warn(`[AutoRegister] Pairing failed: ${response.data?.error || 'Unknown error'}`);
        }
    }
    catch (err) {
        const msg = err.response?.data?.error || err.message;
        logger_1.logger.warn(`[AutoRegister] Pairing handshake error: ${msg}`);
    }
    return false;
}
// ---------------------------------------------------------------------------
// Worker Launcher
// ---------------------------------------------------------------------------
async function startBridgeWorker() {
    // Stop existing worker if one was running
    if (cleanupPreviousWorker) {
        try {
            cleanupPreviousWorker();
        }
        catch (err) {
            logger_1.logger.warn(`[Bridge] Error cleaning up previous worker: ${err}`);
        }
        cleanupPreviousWorker = null;
    }
    let configStatus = (0, config_1.getConfigurationStatus)();
    // 1. If not yet fully configured but Connection Token is present, attempt auto-pairing handshake
    if (!configStatus.isConfigured && configStatus.canAutoRegister) {
        const token = process.env.CONNECTION_TOKEN || configStatus.config?.connectionToken;
        if (token) {
            await attemptAutoRegistration(token);
            configStatus = (0, config_1.getConfigurationStatus)();
        }
    }
    // 2. If token is present but host is missing, auto-scan local subnets to discover console
    if (!configStatus.isConfigured &&
        process.env.UNIFI_ACCESS_TOKEN &&
        (!process.env.UNIFI_HOST || configStatus.missing.some((m) => m.startsWith('UNIFI_HOST')))) {
        logger_1.logger.info('[Bridge] UniFi Host URL not set. Scanning local network for UniFi Access console…');
        const discovered = await (0, scanner_1.autoDiscoverUnifiConsole)(process.env.UNIFI_ACCESS_TOKEN);
        if (discovered) {
            logger_1.logger.info(`[Bridge] Discovered UniFi Access console on LAN at: ${discovered}`);
            (0, config_1.saveConfig)({ UNIFI_HOST: discovered });
            configStatus = (0, config_1.getConfigurationStatus)();
        }
    }
    if (!configStatus.isConfigured || !configStatus.config) {
        bridgeState.status = 'unconfigured';
        bridgeState.unifiConnected = false;
        bridgeState.firebaseConnected = false;
        bridgeState.errorMessage = `Missing: ${configStatus.missing.join(', ')}`;
        logger_1.logger.warn(`⚠️ Agent is unconfigured (${bridgeState.errorMessage}). ` +
            `Open http://localhost:${process.env.PORT || 8080} to configure.`);
        return;
    }
    const config = configStatus.config;
    (0, logger_1.setLogLevel)(config.logLevel);
    logger_1.logger.info('═══════════════════════════════════════════════');
    logger_1.logger.info('  UnFi-PCO Local Agent');
    logger_1.logger.info(`  Version : ${config.version}`);
    logger_1.logger.info(`  Org     : ${config.orgId}`);
    logger_1.logger.info(`  Agent   : ${config.agentId} (${config.agentLabel})`);
    logger_1.logger.info(`  UniFi   : ${config.unifiHost || '(Scanning network...)'}`);
    logger_1.logger.info('═══════════════════════════════════════════════');
    bridgeState.status = 'starting';
    // 1. Initialize Firebase
    try {
        await (0, firebase_1.initializeFirebase)(config.firebaseServiceAccountPath, config.firebaseProjectId);
        bridgeState.firebaseConnected = true;
    }
    catch (err) {
        bridgeState.status = 'error';
        bridgeState.firebaseConnected = false;
        bridgeState.errorMessage = `Firebase initialization failed: ${err.message}`;
        logger_1.logger.error(`[Bridge] Firebase init error: ${err.message}`);
        return;
    }
    const db = (0, firebase_1.getDb)();
    // 2. Initialize UniFi Access client
    const unifiClient = new access_1.UnifiAccessClient(config.unifiHost, config.unifiAccessToken, config.skipTlsVerify);
    // 3. Test UniFi connectivity with auto-discovery fallback
    logger_1.logger.info('Testing UniFi Access connection…');
    try {
        let connected = await unifiClient.testConnection();
        if (!connected) {
            logger_1.logger.warn(`[Bridge] Could not connect to configured host (${config.unifiHost}). Scanning LAN for active console…`);
            const discovered = await (0, scanner_1.autoDiscoverUnifiConsole)(config.unifiAccessToken);
            if (discovered && discovered !== config.unifiHost) {
                logger_1.logger.info(`[Bridge] Discovered active console on LAN at: ${discovered}. Connecting…`);
                config.unifiHost = discovered;
                (0, config_1.saveConfig)({ UNIFI_HOST: discovered });
                unifiClient.updateCredentials(discovered, config.unifiAccessToken, config.skipTlsVerify);
                connected = await unifiClient.testConnection();
            }
        }
        if (!connected) {
            bridgeState.status = 'error';
            bridgeState.unifiConnected = false;
            bridgeState.errorMessage = 'Could not connect to UniFi Access API. Check host & token.';
            logger_1.logger.error('[Bridge] Could not connect to UniFi Access API. ' +
                'Check UNIFI_HOST, UNIFI_ACCESS_TOKEN, and network reachability.');
            return;
        }
        bridgeState.unifiConnected = true;
    }
    catch (err) {
        bridgeState.status = 'error';
        bridgeState.unifiConnected = false;
        bridgeState.errorMessage = `UniFi connection error: ${err.message}`;
        logger_1.logger.error(`[Bridge] UniFi connection error: ${err.message}`);
        return;
    }
    // 4. Register / update agent document in Firestore
    try {
        await db.doc(`agents/${config.agentId}`).set({
            org_id: config.orgId,
            label: config.agentLabel,
            version: config.version,
            status: 'online',
            registered_at: admin.firestore.Timestamp.now(),
            unifi_host: config.unifiHost,
            capabilities: ['unlock', 'lock', 'door_sync'],
        }, { merge: true });
        logger_1.logger.info(`Agent document registered: agents/${config.agentId}`);
    }
    catch (err) {
        logger_1.logger.error(`Failed to register agent document: ${String(err)}`);
    }
    // 5. Start heartbeat
    const stopHeartbeat = (0, heartbeat_1.startHeartbeat)(config.orgId, config.agentId, config.agentLabel, config.version, config.heartbeatIntervalMs);
    // 5b. Start OTA update checker (polls every 60s, listens real-time for approvals)
    const stopUpdateChecker = (0, updateChecker_1.startUpdateChecker)(config.agentId, config.orgId, 60 * 1000, bridgeState.onRestartRequest);
    // 6. Initial door sync
    logger_1.logger.info('Running initial door sync…');
    try {
        const doors = await unifiClient.getDoors();
        bridgeState.doorCount = doors.length;
        await (0, doorSync_1.syncDoors)(config.orgId, unifiClient);
        bridgeState.lastSync = new Date();
    }
    catch (err) {
        logger_1.logger.error(`[DoorSync] Initial sync error: ${err.message}`);
    }
    // 7. Recurring door sync
    const stopDoorSync = (0, doorSync_1.startDoorSyncInterval)(config.orgId, unifiClient, config.doorSyncIntervalMs);
    // 8. Initial schedule sync
    logger_1.logger.info('Running initial schedule sync…');
    try {
        const schedules = await (0, scheduleSync_1.syncSchedules)(config.orgId, unifiClient);
        logger_1.logger.info(`[ScheduleSync] Initial sync completed (${schedules.length} schedules found).`);
    }
    catch (err) {
        logger_1.logger.error(`[ScheduleSync] Initial sync error: ${err.message}`);
    }
    // 9. Recurring schedule sync (every 60 seconds)
    const stopScheduleSync = (0, scheduleSync_1.startScheduleSyncInterval)(config.orgId, unifiClient, 60 * 1000);
    // 10. Initial visitor sync
    logger_1.logger.info('Running initial visitor sync…');
    try {
        const visitors = await (0, visitorSync_1.syncVisitors)(config.orgId, unifiClient);
        logger_1.logger.info(`[VisitorSync] Initial sync completed (${visitors.length} visitors found).`);
    }
    catch (err) {
        logger_1.logger.error(`[VisitorSync] Initial sync error: ${err.message}`);
    }
    // 11. Recurring visitor sync (every 60 seconds)
    const stopVisitorSync = (0, visitorSync_1.startVisitorSyncInterval)(config.orgId, unifiClient, 60 * 1000);
    // 12. Initial access log sync
    logger_1.logger.info('Running initial access log sync…');
    try {
        const logs = await (0, accessLogSync_1.syncAccessLogs)(config.orgId, unifiClient);
        logger_1.logger.info(`[AccessLogSync] Initial sync completed (${logs.length} access logs found).`);
    }
    catch (err) {
        logger_1.logger.error(`[AccessLogSync] Initial sync error: ${err.message}`);
    }
    // 13. Recurring access log sync (every 25 seconds for near-instant access tracking)
    const stopAccessLogSync = (0, accessLogSync_1.startAccessLogSyncInterval)(config.orgId, unifiClient, 25 * 1000);
    // 14. Start Firestore command listener
    const stopCommandListener = (0, commandListener_1.startCommandListener)(config.orgId, config.agentId, unifiClient, (cmd) => {
        logger_1.logger.debug(`[Main] Command callback — id: ${cmd.id} action: ${cmd.action} door: ${cmd.door_id}`);
    }, bridgeState.onRestartRequest);
    // 15. Subscribe to real-time cloud settings updates (token rotation, host changes)
    const stopSettingsListener = db.doc(`organizations/${config.orgId}/settings/config`).onSnapshot(async (snap) => {
        if (!snap.exists)
            return;
        const data = snap.data();
        const unifiConfig = data?.unifi_agent || data?.unifi_remote;
        if (!unifiConfig)
            return;
        let changed = false;
        if (unifiConfig.access_token && unifiConfig.access_token !== config.unifiAccessToken) {
            logger_1.logger.info('[Bridge] Detected updated UniFi Access API token in cloud settings. Updating…');
            config.unifiAccessToken = unifiConfig.access_token;
            (0, config_1.saveConfig)({ UNIFI_ACCESS_TOKEN: unifiConfig.access_token });
            changed = true;
        }
        if (unifiConfig.host && unifiConfig.host !== config.unifiHost) {
            logger_1.logger.info(`[Bridge] Detected updated UniFi Host (${unifiConfig.host}) in cloud settings. Updating…`);
            config.unifiHost = unifiConfig.host;
            (0, config_1.saveConfig)({ UNIFI_HOST: unifiConfig.host });
            changed = true;
        }
        if (unifiConfig.skip_tls_verify !== undefined && Boolean(unifiConfig.skip_tls_verify) !== config.skipTlsVerify) {
            logger_1.logger.info(`[Bridge] Detected updated skip_tls_verify (${unifiConfig.skip_tls_verify}) in cloud settings. Updating…`);
            config.skipTlsVerify = Boolean(unifiConfig.skip_tls_verify);
            (0, config_1.saveConfig)({ SKIP_TLS_VERIFY: String(config.skipTlsVerify) });
            changed = true;
        }
        if (changed) {
            logger_1.logger.info('[Bridge] Re-applying cloud credentials to UniFi client…');
            unifiClient.updateCredentials(config.unifiHost, config.unifiAccessToken, config.skipTlsVerify);
            const testOk = await unifiClient.testConnection();
            bridgeState.unifiConnected = testOk;
            if (testOk) {
                logger_1.logger.info('[Bridge] ✓ Connection verified with new credentials! Running door sync…');
                await (0, doorSync_1.syncDoors)(config.orgId, unifiClient);
                bridgeState.lastSync = new Date();
            }
        }
    }, (err) => {
        logger_1.logger.warn(`[Bridge] Cloud settings listener notice: ${err.message}`);
    });
    bridgeState.onSyncDoors = async () => {
        logger_1.logger.info('[Bridge] Executing on-demand door discovery sync…');
        const doors = await (0, doorSync_1.syncDoors)(config.orgId, unifiClient);
        bridgeState.doorCount = doors.length;
        bridgeState.lastSync = new Date();
        return doors.length;
    };
    bridgeState.status = 'running';
    bridgeState.errorMessage = undefined;
    logger_1.logger.info('✓ Agent bridge running — listening for door commands.');
    cleanupPreviousWorker = () => {
        logger_1.logger.info('[Bridge] Stopping previous bridge worker…');
        bridgeState.onSyncDoors = undefined;
        stopSettingsListener();
        stopCommandListener();
        stopAccessLogSync();
        stopVisitorSync();
        stopScheduleSync();
        stopDoorSync();
        stopHeartbeat();
        stopUpdateChecker();
    };
}
// ---------------------------------------------------------------------------
// Main
// ---------------------------------------------------------------------------
async function main() {
    const port = parseInt(process.env.PORT || '8080', 10);
    // 1. Launch the web configuration portal immediately
    (0, server_1.startWebServer)(port, bridgeState);
    // 2. Start bridge worker (will run if configured, or stay in setup mode)
    await startBridgeWorker();
    // 3. Graceful shutdown
    const shutdown = (signal) => {
        logger_1.logger.info(`Received ${signal} — shutting down gracefully.`);
        if (cleanupPreviousWorker) {
            cleanupPreviousWorker();
        }
        process.exit(0);
    };
    process.once('SIGINT', () => shutdown('SIGINT'));
    process.once('SIGTERM', () => shutdown('SIGTERM'));
}
main().catch((err) => {
    logger_1.logger.error(`[FATAL] Startup failure: ${String(err)}`);
});
