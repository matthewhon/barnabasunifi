/**
 * firebase/commandListener.ts
 * Real-time Firestore listener for door commands.
 *
 * Listens for documents in organizations/{orgId}/door_commands with
 * status == 'queued' that are due for execution (execute_at <= now).
 * Uses Firestore transactions to claim commands atomically, preventing
 * double-execution in multi-agent deployments.
 */

import { getDb, firestoreTimestamp } from '../firebase';
import { UnifiAccessClient, UnifiVisitor } from '../unifi/access';
import { logger } from '../logger';

import { syncDoors } from './doorSync';
import { syncSchedules } from './scheduleSync';
import { syncVisitors } from './visitorSync';
import { syncAccessLogs } from './accessLogSync';
import { syncAccessPolicies, syncUsers } from './userSync';
import { checkForUpdate, applyPendingUpdate } from './updateChecker';
import { getCacheStore } from '../storage/cacheStore';

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export type CommandAction =
  | 'unlock'
  | 'lock'
  | 'sync_doors'
  | 'sync_schedules'
  | 'update_schedule'
  | 'create_schedule'
  | 'delete_schedule'
  | 'sync_visitors'
  | 'create_visitor'
  | 'update_visitor'
  | 'delete_visitor'
  | 'sync_users'
  | 'create_user'
  | 'update_user'
  | 'assign_policies'
  | 'sync_policies'
  | 'create_policy'
  | 'update_policy'
  | 'delete_policy'
  | 'sync_access_logs'
  | 'apply_update'
  | 'upgrade_agent'
  | 'restart_agent';

export type CommandStatus =
  | 'queued'
  | 'executing'
  | 'done'
  | 'failed'
  | 'skipped';

export interface DoorCommand {
  id: string;
  action: CommandAction;
  door_id?: string;
  door_label?: string;
  unifi_door_id?: string;
  schedule_id?: string;
  schedule_data?: Record<string, unknown>;
  visitor_id?: string;
  unifi_visitor_id?: string;
  firestore_visitor_id?: string;
  visitor_data?: Record<string, unknown>;
  user_id?: string;
  pco_person_id?: string;
  unifi_user_id?: string;
  user_data?: Record<string, unknown>;
  policy_id?: string;
  unifi_policy_id?: string;
  policy_data?: Record<string, unknown>;
  policy_ids?: string[];
  status: CommandStatus;
  execute_at: FirebaseFirestore.Timestamp | string | Date;
  duration_min?: number;
  schedule_window_id?: string;
  triggered_by?: 'scheduler' | 'manual';
  actor_uid?: string;
  created_by?: string;
  org_id: string;
}

export type CommandCallback = (command: DoorCommand) => void;

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

function nowTimestamp(): FirebaseFirestore.Timestamp {
  return firestoreTimestamp.now();
}

function parseExecuteAtMillis(executeAt: unknown): number {
  if (!executeAt) return 0;
  if (typeof (executeAt as any).toMillis === 'function') {
    return (executeAt as any).toMillis();
  }
  if (executeAt instanceof Date) {
    return isNaN(executeAt.getTime()) ? 0 : executeAt.getTime();
  }
  if (typeof executeAt === 'string' || typeof executeAt === 'number') {
    const ms = new Date(executeAt).getTime();
    return isNaN(ms) ? 0 : ms;
  }
  return 0;
}

async function writeAuditLog(
  db: FirebaseFirestore.Firestore,
  orgId: string,
  command: DoorCommand,
  status: CommandStatus,
  resultMessage: string,
  agentId: string
): Promise<void> {
  try {
    const isManual = command.triggered_by === 'manual' || !command.schedule_window_id;
    let action: string;
    if (command.action === 'unlock') {
      action = isManual ? 'manual_unlock' : 'unlock';
    } else if (command.action === 'lock') {
      action = isManual ? 'manual_lock' : 'lock';
    } else if (command.action === 'sync_doors') {
      action = 'doors_synced';
    } else if (command.action === 'sync_schedules') {
      action = 'schedule_synced';
    } else if (command.action === 'update_schedule') {
      action = 'schedule_updated';
    } else if (command.action === 'create_schedule') {
      action = 'schedule_created';
    } else if (command.action === 'delete_schedule') {
      action = 'schedule_deleted';
    } else if (command.action === 'sync_visitors') {
      action = 'visitor_synced';
    } else if (command.action === 'create_visitor') {
      action = 'visitor_created';
    } else if (command.action === 'update_visitor') {
      action = 'visitor_updated';
    } else if (command.action === 'delete_visitor') {
      action = 'visitor_deleted';
    } else if (command.action === 'sync_access_logs') {
      action = 'access_logs_synced';
    } else if (command.action === 'sync_users') {
      action = 'users_synced';
    } else if (command.action === 'create_user') {
      action = 'user_created';
    } else if (command.action === 'update_user') {
      action = 'user_updated';
    } else if (command.action === 'assign_policies') {
      action = 'policies_assigned';
    } else if (command.action === 'sync_policies') {
      action = 'policies_synced';
    } else if (command.action === 'create_policy') {
      action = 'policy_created';
    } else if (command.action === 'update_policy') {
      action = 'policy_updated';
    } else if (command.action === 'delete_policy') {
      action = 'policy_deleted';
    } else {
      action = command.action;
    }

    await db.collection(`organizations/${orgId}/audit_log`).add({
      command_id: command.id,
      action,
      door_id: command.door_id ?? null,
      door_label: command.door_label ?? null,
      unifi_door_id: command.unifi_door_id ?? null,
      schedule_id: command.schedule_id ?? null,
      user_id: command.user_id ?? command.pco_person_id ?? null,
      status,
      result: status === 'done' ? 'success' : 'error',
      result_message: resultMessage,
      message: resultMessage,
      triggered_by: isManual ? 'manual' : 'scheduler',
      actor_uid: command.actor_uid ?? null,
      agent_id: agentId,
      org_id: orgId,
      schedule_window_id: command.schedule_window_id ?? null,
      executed_at: nowTimestamp(),
      timestamp: nowTimestamp(),
    });
  } catch (err) {
    logger.error(`Failed to write audit log for command ${command.id}: ${String(err)}`);
  }
}

async function updateScheduleWindow(
  db: FirebaseFirestore.Firestore,
  orgId: string,
  windowId: string,
  action: CommandAction,
  status: CommandStatus
): Promise<void> {
  try {
    const windowRef = db.doc(`organizations/${orgId}/schedule_windows/${windowId}`);
    const windowStatus = action === 'unlock'
      ? (status === 'done' ? 'unlocked' : 'unlock_failed')
      : (status === 'done' ? 'locked' : 'lock_failed');

    await windowRef.update({
      status: windowStatus,
      last_command_status: status,
      last_updated: nowTimestamp(),
    });
  } catch (err) {
    logger.warn(
      `Could not update schedule_window ${windowId}: ${String(err)}`
    );
  }
}

// ---------------------------------------------------------------------------
// Main export
// ---------------------------------------------------------------------------

/**
 * Start listening for queued door commands and execute them against the
 * UniFi Access API. Returns an unsubscribe function.
 *
 * @param orgId       - Firestore organization document ID
 * @param agentId     - This agent's identifier (written into executed commands)
 * @param unifiClient - Initialized UniFi Access client
 * @param onCommand   - Optional callback invoked whenever a command is processed
 */
export function startCommandListener(
  orgId: string,
  agentId: string,
  unifiClient: UnifiAccessClient,
  onCommand?: CommandCallback,
  onRestart?: () => Promise<void>
): () => void {
  const db = getDb();
  const commandsRef = db.collection(`organizations/${orgId}/door_commands`);
  const activeTimers = new Map<string, NodeJS.Timeout>();
  const inFlightCommands = new Set<string>();

  logger.info(`[CommandListener] Watching commands for org: ${orgId}`);

  async function processCommand(doc: FirebaseFirestore.DocumentSnapshot) {
    const commandId = doc.id;
    if (inFlightCommands.has(commandId)) return;
    const rawData = doc.data();
    if (!rawData) return;

    inFlightCommands.add(commandId);
    try {
      await processCommandInner(doc, commandId, rawData);
    } finally {
      inFlightCommands.delete(commandId);
    }
  }

  async function processCommandInner(
    doc: FirebaseFirestore.DocumentSnapshot,
    commandId: string,
    rawData: FirebaseFirestore.DocumentData
  ) {
    // Step 1: Atomically claim the command with a Firestore transaction
    let command: DoorCommand;
    try {
      const claimed = await db.runTransaction(async (tx) => {
        const freshDoc = await tx.get(doc.ref);
        if (!freshDoc.exists) return false;

        const freshData = freshDoc.data()!;
        if (freshData.status !== 'queued') return false;

        tx.update(doc.ref, {
          status: 'executing',
          agent_id: agentId,
          claimed_at: nowTimestamp(),
        });
        return true;
      });

      if (!claimed) {
        logger.debug(
          `[CommandListener] Command ${commandId} already claimed or not queued — skipping.`
        );
        return;
      }

      const unifiDoorId = (rawData.unifi_door_id || rawData.door_id) as string | undefined;

      command = {
        id: commandId,
        action: rawData.action as CommandAction,
        door_id: rawData.door_id as string | undefined,
        door_label: rawData.door_label as string | undefined,
        unifi_door_id: unifiDoorId,
        schedule_id: rawData.schedule_id as string | undefined,
        schedule_data: rawData.schedule_data as Record<string, unknown> | undefined,
        visitor_id: rawData.visitor_id as string | undefined,
        unifi_visitor_id: rawData.unifi_visitor_id as string | undefined,
        firestore_visitor_id: rawData.firestore_visitor_id as string | undefined,
        visitor_data: rawData.visitor_data as Record<string, unknown> | undefined,
        status: 'executing',
        execute_at: rawData.execute_at,
        duration_min: rawData.duration_min as number | undefined,
        schedule_window_id: (rawData.schedule_window_id || rawData.window_id) as string | undefined,
        triggered_by: rawData.triggered_by as 'scheduler' | 'manual' | undefined,
        actor_uid: rawData.actor_uid as string | undefined,
        created_by: rawData.created_by as string | undefined,
        org_id: orgId,
      };

      logger.info(
        `[CommandListener] Claimed command ${commandId}: ${command.action}${
          command.unifi_door_id ? ` door ${command.unifi_door_id}` : ''
        }${command.schedule_id ? ` schedule ${command.schedule_id}` : ''}${
          command.visitor_id ? ` visitor ${command.visitor_id}` : ''
        }`
      );
    } catch (err) {
      logger.error(
        `[CommandListener] Transaction failed for command ${commandId}: ${String(err)}`
      );
      return;
    }

    // Step 2: Execute the command against the UniFi Access API
    let finalStatus: CommandStatus = 'done';
    let resultMessage = '';
    let skipPostExecutionSideEffects = false;

    try {
      const executeAtMs = parseExecuteAtMillis(command.execute_at);
      const isScheduledCmd = command.triggered_by === 'scheduler' || Boolean(command.schedule_window_id);

      if (command.action === 'unlock') {
        if (!command.unifi_door_id) throw new Error('Missing unifi_door_id for unlock action');
        let durationMin = command.duration_min ?? 60;

        if (isScheduledCmd && command.schedule_window_id) {
          const actionKey = `${command.schedule_window_id}:${command.unifi_door_id}:unlock`;
          if (getCacheStore().hasExecutedAction(actionKey)) {
            resultMessage = 'Unlock already executed locally via LocalScheduler.';
            skipPostExecutionSideEffects = true;
          } else if (executeAtMs > 0) {
            const unlockEndMs = executeAtMs + durationMin * 60 * 1000;
            const nowMs = Date.now();
            if (nowMs >= unlockEndMs) {
              finalStatus = 'skipped';
              resultMessage = 'Skipped expired scheduled unlock (event window already ended).';
              skipPostExecutionSideEffects = true;
            } else {
              durationMin = Math.max(1, Math.round((unlockEndMs - nowMs) / 60000));
            }
          }
        }

        if (!skipPostExecutionSideEffects) {
          command.duration_min = durationMin;
          await unifiClient.unlockDoor(command.unifi_door_id, durationMin);
          resultMessage = `Door unlocked for ${durationMin} minute(s).`;
          if (command.schedule_window_id) {
            getCacheStore().recordExecutedAction(`${command.schedule_window_id}:${command.unifi_door_id}:unlock`);
          }
          syncDoors(orgId, unifiClient).catch(() => {});
        }
      } else if (command.action === 'lock') {
        if (!command.unifi_door_id) throw new Error('Missing unifi_door_id for lock action');

        // Guard against premature or stale lock
        let skipLock = false;
        if (command.triggered_by !== 'manual') {
          const now = Date.now();
          if (command.schedule_window_id) {
            const actionKey = `${command.schedule_window_id}:${command.unifi_door_id}:lock`;
            if (getCacheStore().hasExecutedAction(actionKey)) {
              resultMessage = 'Lock already executed locally via LocalScheduler.';
              skipLock = true;
              skipPostExecutionSideEffects = true;
            }
          }
          if (!skipLock && executeAtMs > 0 && now - executeAtMs > 2 * 60 * 60 * 1000) {
            finalStatus = 'skipped';
            resultMessage = 'Skipped stale scheduled lock (>2h past scheduled time).';
            skipLock = true;
            skipPostExecutionSideEffects = true;
          }
          if (!skipLock) {
            try {
              let hasActiveOverlappingWindow = false;

              // 1. First check local memory cache
              const cachedWindows = getCacheStore().getScheduleWindows();
              hasActiveOverlappingWindow = cachedWindows.some((cw) => {
                if (cw.id === command.schedule_window_id) return false;
                if (!cw.door_ids.includes(command.unifi_door_id!)) return false;
                const uMs = new Date(cw.unlock_at).getTime();
                const lMs = new Date(cw.lock_at).getTime();
                return !isNaN(uMs) && !isNaN(lMs) && uMs <= now && lMs > now;
              });

              // 2. Also check Firestore if available
              if (!hasActiveOverlappingWindow) {
                const activeWindowsSnap = await db
                  .collection(`organizations/${orgId}/schedule_windows`)
                  .where('door_ids', 'array-contains', command.unifi_door_id)
                  .get();

                hasActiveOverlappingWindow = activeWindowsSnap.docs.some((wDoc) => {
                  if (wDoc.id === command.schedule_window_id) return false;
                  const d = wDoc.data();
                  const unlockAt = d.unlock_at?.toMillis ? d.unlock_at.toMillis() : new Date(d.unlock_at).getTime();
                  const lockAt = d.lock_at?.toMillis ? d.lock_at.toMillis() : new Date(d.lock_at).getTime();
                  return !isNaN(unlockAt) && !isNaN(lockAt) && unlockAt <= now && lockAt > now;
                });
              }

              if (hasActiveOverlappingWindow) {
                logger.info(
                  `[CommandListener] Suppressing lock command ${commandId} for door ${command.unifi_door_id}: another scheduled window is actively keeping this door unlocked.`
                );
                resultMessage = 'Lock deferred: another scheduled window is actively keeping this door unlocked.';
                skipLock = true;
                skipPostExecutionSideEffects = true;
              }
            } catch (guardErr) {
              logger.warn(`[CommandListener] Active window check notice: ${String(guardErr)}`);
            }
          }
        }

        if (!skipLock) {
          await unifiClient.lockDoor(command.unifi_door_id);
          resultMessage = 'Door locked successfully.';
          if (command.schedule_window_id) {
            getCacheStore().recordExecutedAction(`${command.schedule_window_id}:${command.unifi_door_id}:lock`);
          }
          syncDoors(orgId, unifiClient).catch(() => {});
        }
      } else if (command.action === 'sync_doors') {
        const synced = await syncDoors(orgId, unifiClient);
        resultMessage = `Discovered and synced ${synced.length} door(s) from UniFi Access.`;
      } else if (command.action === 'sync_schedules') {
        const synced = await syncSchedules(orgId, unifiClient);
        resultMessage = `Synced ${synced.length} schedule(s) from UniFi Access.`;
      } else if (command.action === 'update_schedule') {
        if (!command.schedule_id) throw new Error('Missing schedule_id for update_schedule');
        const updated = await unifiClient.updateSchedule(
          command.schedule_id,
          command.schedule_data || {}
        );
        await db.doc(`organizations/${orgId}/unifi_schedules/${command.schedule_id}`).set(
          {
            ...updated,
            org_id: orgId,
            last_synced: nowTimestamp(),
            sync_status: 'synced',
            sync_error: null,
            updated_at: nowTimestamp(),
          },
          { merge: true }
        );
        resultMessage = `Schedule ${command.schedule_id} updated successfully.`;
      } else if (command.action === 'create_schedule') {
        const created = await unifiClient.createSchedule(command.schedule_data || {});
        await db.doc(`organizations/${orgId}/unifi_schedules/${created.id}`).set(
          {
            ...created,
            org_id: orgId,
            last_synced: nowTimestamp(),
            sync_status: 'synced',
            sync_error: null,
            updated_at: nowTimestamp(),
          },
          { merge: true }
        );
        resultMessage = `Schedule ${created.id} created successfully.`;
      } else if (command.action === 'delete_schedule') {
        if (!command.schedule_id) throw new Error('Missing schedule_id for delete_schedule');
        const doorIds = (command as any).door_ids || [];
        await unifiClient.deleteSchedule(command.schedule_id, doorIds);
        await db.doc(`organizations/${orgId}/unifi_schedules/${command.schedule_id}`).delete();
        resultMessage = `Schedule ${command.schedule_id} deleted successfully.`;
      } else if (command.action === 'sync_visitors') {
        const synced = await syncVisitors(orgId, unifiClient);
        resultMessage = `Synced ${synced.length} visitor(s) from UniFi Access.`;
      } else if (command.action === 'create_visitor' || command.action === 'update_visitor') {
        const rawUnifiId = (command.visitor_data?.unifi_visitor_id as string) || (command.unifi_visitor_id as string);
        const unifiVisitorId = rawUnifiId || (command.visitor_id && command.visitor_id.length > 20 ? command.visitor_id : undefined);
        let resultVisitor: UnifiVisitor;

        if (command.action === 'update_visitor' || unifiVisitorId) {
          const targetId = unifiVisitorId || command.visitor_id;
          if (!targetId) throw new Error('Missing visitor ID for update_visitor');
          try {
            resultVisitor = await unifiClient.updateVisitor(targetId, command.visitor_data || {});
            resultMessage = `Visitor ${targetId} updated successfully in UniFi.`;
          } catch (updateErr: any) {
            const errStr = String(updateErr);
            if (errStr.includes('160001') || errStr.includes('not found') || updateErr?.response?.status === 404) {
              logger.warn(`[CommandListener] Visitor ${targetId} not found in UniFi. Creating new visitor…`);
              resultVisitor = await unifiClient.createVisitor(command.visitor_data || {});
              resultMessage = `Visitor created in UniFi (ID: ${resultVisitor.id}).`;
            } else {
              throw updateErr;
            }
          }
        } else {
          resultVisitor = await unifiClient.createVisitor(command.visitor_data || {});
          resultMessage = `Visitor ${resultVisitor.full_name || resultVisitor.first_name} created successfully in UniFi.`;
        }

        const targetVisitorId = command.visitor_id || resultVisitor.id;
        const finalUnifiId = resultVisitor.unifi_visitor_id || resultVisitor.id;
        await db.doc(`organizations/${orgId}/visitors/${targetVisitorId}`).set(
          {
            ...resultVisitor,
            id: targetVisitorId,
            org_id: orgId,
            unifi_visitor_id: finalUnifiId,
            last_synced: nowTimestamp(),
            sync_status: 'synced',
            sync_error: null,
            updated_at: nowTimestamp(),
          },
          { merge: true }
        );
      } else if (command.action === 'delete_visitor') {
        if (!command.visitor_id) throw new Error('Missing visitor_id for delete_visitor');
        const visitorDocSnap = await db.doc(`organizations/${orgId}/visitors/${command.visitor_id}`).get().catch(() => null);
        const visitorDocData = visitorDocSnap && visitorDocSnap.exists ? visitorDocSnap.data() : null;

        const targetUniFiId =
          (command.visitor_data?.unifi_visitor_id as string) ||
          (visitorDocData?.unifi_visitor_id as string) ||
          (command.unifi_visitor_id as string) ||
          command.visitor_id;

        const visitorMeta = {
          first_name: (command.visitor_data?.first_name as string) || visitorDocData?.first_name,
          last_name: (command.visitor_data?.last_name as string) || visitorDocData?.last_name,
          email: (command.visitor_data?.email as string) || visitorDocData?.email,
          mobile_phone: (command.visitor_data?.mobile_phone as string) || visitorDocData?.mobile_phone,
          pin_code: (command.visitor_data?.pin_code as string) || visitorDocData?.pin_code,
        };

        try {
          await unifiClient.deleteVisitor(targetUniFiId, visitorMeta);
          logger.info(`[CommandListener] Deleted visitor ${targetUniFiId} from UniFi Access.`);
        } catch (delErr: any) {
          logger.warn(`[CommandListener] UniFi deleteVisitor notice: ${delErr.message}`);
        }

        await db.doc(`organizations/${orgId}/visitors/${command.visitor_id}`).set(
          {
            status: 'revoked',
            sync_status: 'synced',
            updated_at: nowTimestamp(),
          },
          { merge: true }
        );

        // Immediate background sync to clean up orphaned/duplicate records
        syncVisitors(orgId, unifiClient).catch((err) => {
          logger.debug(`[CommandListener] Post-delete visitor sync notice: ${err}`);
        });

        resultMessage = `Visitor ${command.visitor_id} revoked successfully.`;
      } else if (command.action === 'sync_access_logs') {
        const backfill = Boolean((command as any).backfill);
        const days = typeof (command as any).days === 'number' ? (command as any).days : 90;
        const synced = await syncAccessLogs(orgId, unifiClient, {
          forceFull: backfill,
          lookbackDays: days,
          maxPages: backfill ? 50 : 15,
        });
        resultMessage = `Synced ${synced.length} access log(s) from UniFi Access.`;
      } else if (command.action === 'sync_policies') {
        const policies = await syncAccessPolicies(orgId, unifiClient);
        resultMessage = `Synced ${policies.length} access policy(ies) from UniFi Access.`;
      } else if (command.action === 'sync_users') {
        const users = await syncUsers(orgId, unifiClient);
        resultMessage = `Synced ${users.length} user(s) from UniFi Access.`;
      } else if (command.action === 'create_user') {
        const userData = (command.user_data as Record<string, any>) || {};
        const policyIds = (command.policy_ids as string[]) || (userData.policy_ids as string[]) || [];

        const created = await unifiClient.createUser({
          first_name: userData.first_name || 'User',
          last_name: userData.last_name || '',
          full_name: userData.full_name,
          email: userData.email,
          phone_number: userData.phone_number,
          avatar: userData.avatar,
          policy_ids: policyIds,
        });

        const pcoId = command.pco_person_id || command.user_id;
        if (pcoId && created.id) {
          await db.doc(`organizations/${orgId}/synced_users/${pcoId}`).set(
            {
              unifi_user_id: created.id,
              status: policyIds.length > 0 ? 'active' : 'no_policy',
              assigned_policy_ids: policyIds,
              last_synced_at: new Date().toISOString(),
              updated_at: nowTimestamp(),
            },
            { merge: true }
          );
        }

        resultMessage = `Created UniFi user '${userData.full_name || userData.first_name}' (ID: ${created.id}) with ${policyIds.length} policy(ies).`;
      } else if (command.action === 'assign_policies' || command.action === 'update_user') {
        const pcoId = command.pco_person_id || command.user_id;
        let unifiUserId = command.unifi_user_id;
        const policyIds = (command.policy_ids as string[]) || [];

        if (!unifiUserId && pcoId) {
          const userDoc = await db.doc(`organizations/${orgId}/synced_users/${pcoId}`).get();
          if (userDoc.exists) {
            unifiUserId = userDoc.data()?.unifi_user_id;
          }
        }

        // If still no unifiUserId, try finding by email or name in UniFi
        if (!unifiUserId) {
          const userData = (command.user_data as Record<string, any>) || {};
          const existingUniFiUsers = await unifiClient.getUsers();
          const match = existingUniFiUsers.find(
            (u) =>
              (userData.email && (u.user_email === userData.email || u.email === userData.email)) ||
              (userData.full_name && u.name?.toLowerCase() === userData.full_name.toLowerCase())
          );
          if (match) {
            unifiUserId = match.id;
          }
        }

        if (unifiUserId) {
          await unifiClient.assignUserAccessPolicies(unifiUserId, policyIds);

          if (pcoId) {
            await db.doc(`organizations/${orgId}/synced_users/${pcoId}`).set(
              {
                unifi_user_id: unifiUserId,
                status: policyIds.length > 0 ? 'active' : 'no_policy',
                assigned_policy_ids: policyIds,
                last_synced_at: new Date().toISOString(),
                updated_at: nowTimestamp(),
              },
              { merge: true }
            );
          }

          resultMessage = `Updated user ${unifiUserId}: assigned ${policyIds.length} access policy(ies).`;
        } else {
          // User not found in UniFi -> Create them instead
          const userData = (command.user_data as Record<string, any>) || {};
          const created = await unifiClient.createUser({
            first_name: userData.first_name || 'User',
            last_name: userData.last_name || '',
            full_name: userData.full_name,
            email: userData.email,
            phone_number: userData.phone_number,
            avatar: userData.avatar,
            policy_ids: policyIds,
          });

          if (pcoId && created.id) {
            await db.doc(`organizations/${orgId}/synced_users/${pcoId}`).set(
              {
                unifi_user_id: created.id,
                status: policyIds.length > 0 ? 'active' : 'no_policy',
                assigned_policy_ids: policyIds,
                last_synced_at: new Date().toISOString(),
                updated_at: nowTimestamp(),
              },
              { merge: true }
            );
          }

          resultMessage = `User was not in UniFi; created new UniFi user (ID: ${created.id}) with ${policyIds.length} policy(ies).`;
        }
      } else if (command.action === 'create_policy') {
        const policyData = (command.policy_data as Record<string, any>) || {};
        const created = await unifiClient.createAccessPolicy({
          name: policyData.name || 'New Policy',
          door_ids: policyData.door_ids || [],
          schedule_id: policyData.schedule_id,
          description: policyData.description,
          holiday_group_id: policyData.holiday_group_id,
        });

        const firestorePolicyId = command.policy_id || created.id;
        await db.doc(`organizations/${orgId}/access_policies/${firestorePolicyId}`).set(
          {
            ...created,
            id: firestorePolicyId,
            org_id: orgId,
            sync_status: 'synced',
            sync_error: null,
            last_synced: new Date().toISOString(),
            updated_at: nowTimestamp(),
          },
          { merge: true }
        );

        resultMessage = `Created UniFi access policy '${created.name}' (ID: ${created.id}).`;
      } else if (command.action === 'update_policy') {
        const policyId = command.policy_id || command.unifi_policy_id;
        if (!policyId) throw new Error('Policy ID is required for update_policy');

        const policyData = (command.policy_data as Record<string, any>) || {};
        const updated = await unifiClient.updateAccessPolicy(policyId, {
          name: policyData.name,
          door_ids: policyData.door_ids,
          schedule_id: policyData.schedule_id,
          description: policyData.description,
          holiday_group_id: policyData.holiday_group_id,
        });

        await db.doc(`organizations/${orgId}/access_policies/${policyId}`).set(
          {
            ...updated,
            id: policyId,
            org_id: orgId,
            sync_status: 'synced',
            sync_error: null,
            last_synced: new Date().toISOString(),
            updated_at: nowTimestamp(),
          },
          { merge: true }
        );

        resultMessage = `Updated UniFi access policy '${policyId}'.`;
      } else if (command.action === 'delete_policy') {
        const policyId = command.policy_id || command.unifi_policy_id;
        if (!policyId) throw new Error('Policy ID is required for delete_policy');

        await unifiClient.deleteAccessPolicy(policyId);
        await db.doc(`organizations/${orgId}/access_policies/${policyId}`).delete();

        resultMessage = `Deleted UniFi access policy '${policyId}'.`;
      } else if (command.action === 'apply_update' || command.action === 'upgrade_agent') {
        const updateState = await checkForUpdate();
        if (updateState.updateAvailable) {
          applyPendingUpdate().catch((err) => {
            logger.error(`[CommandListener] Apply update failed: ${String(err)}`);
          });
          resultMessage = `Agent update to v${updateState.latestVersion} initiated. Restarting...`;
        } else {
          resultMessage = `Agent is already up to date (v${updateState.currentVersion}).`;
        }
      } else if (command.action === 'restart_agent') {
        resultMessage = 'Agent restart requested remotely. Rebooting container…';
        if (onRestart) {
          setTimeout(() => {
            onRestart().catch((err) => {
              logger.error(`[CommandListener] Remote restart failed: ${String(err)}`);
            });
          }, 500);
        } else {
          setTimeout(() => process.exit(0), 500);
        }
      } else {
        throw new Error(`Unknown action: ${String((command as any).action)}`);
      }

      // Immediately update the door's state in Firestore so the dashboard reflects the change
      const targetDoorId = command.door_id || command.unifi_door_id;
      if (
        !skipPostExecutionSideEffects &&
        targetDoorId &&
        (command.action === 'unlock' || command.action === 'lock')
      ) {
        try {
          const newCurrentState = command.action === 'unlock' ? 'unlocked' : 'locked';
          const updateData: Record<string, any> = {
            current_state: newCurrentState,
            last_synced: nowTimestamp(),
          };
          if (command.action === 'unlock') {
            const durationMin = command.duration_min ?? 60;
            const expiresAtMs = Date.now() + durationMin * 60 * 1000;
            updateData.last_unlocked_at = nowTimestamp();
            updateData.unlock_duration_min = durationMin;
            updateData.hold_unlock_expires_at = firestoreTimestamp.fromMillis(expiresAtMs);
            updateData.is_held_unlocked = true;
            updateData.unlock_trigger = command.triggered_by || 'manual';
            updateData.unlocked_by_user_id = command.actor_uid || null;
          } else {
            updateData.last_locked_at = nowTimestamp();
            updateData.is_held_unlocked = false;
            updateData.hold_unlock_expires_at = null;
            updateData.unlock_duration_min = null;
          }
          await db.doc(`organizations/${orgId}/doors/${targetDoorId}`).set(updateData, { merge: true });
        } catch (doorUpdateErr) {
          logger.warn(`Could not update door document state: ${String(doorUpdateErr)}`);
        }

        // Trigger background sync to refresh full door info without blocking
        syncDoors(orgId, unifiClient).catch((err) => {
          logger.debug(`[CommandListener] Post-command door sync notice: ${String(err)}`);
        });
      }

      logger.info(
        `[CommandListener] Command ${commandId} executed (${finalStatus}): ${resultMessage}`
      );
    } catch (err) {
      finalStatus = 'failed';
      resultMessage = String(err);
      logger.error(
        `[CommandListener] Command ${commandId} failed: ${resultMessage}`
      );
    }

    // Step 3: Update the command document with the final status
    try {
      await doc.ref.update({
        status: finalStatus,
        executed_at: nowTimestamp(),
        result_message: resultMessage,
        agent_id: agentId,
      });
    } catch (err) {
      logger.error(
        `[CommandListener] Failed to update command ${commandId} status: ${String(err)}`
      );
    }

    if (!skipPostExecutionSideEffects) {
      // Step 4: Write audit log entry
      await writeAuditLog(db, orgId, command, finalStatus, resultMessage, agentId);

      // Step 4b: Write to Activity Stream (access_logs)
      if (command.action === 'unlock' || command.action === 'lock') {
        try {
          const isScheduled = command.triggered_by === 'scheduler' || Boolean(command.schedule_window_id);
          const logId = `cmd-${command.id}-${Date.now()}`;
          const targetDoorId = command.door_id || command.unifi_door_id || 'door';
          const targetDoorLabel = command.door_label || 'Door';
          const mappingName = (command as any).mapping_name || (command as any).source_label || (isScheduled ? 'Schedule' : 'Remote');
          const actionLabel = command.action === 'unlock' ? 'unlock' : 'lock';

          let displayMessage: string;
          if (isScheduled) {
            displayMessage = `Scheduled ${actionLabel} for "${targetDoorLabel}" via ${mappingName}`;
          } else {
            displayMessage = `Remote ${actionLabel} for "${targetDoorLabel}"`;
          }

          await db.collection(`organizations/${orgId}/access_logs`).doc(logId).set({
            id: logId,
            org_id: orgId,
            timestamp: nowTimestamp().toDate().toISOString(),
            event_type: command.action === 'unlock' ? 'door_unlock' : 'door_lock',
            event_result: finalStatus === 'done' ? 'success' : 'failed',
            door_id: targetDoorId,
            door_label: targetDoorLabel,
            user_id: isScheduled ? 'scheduler' : (command.actor_uid || 'remote_admin'),
            user_name: isScheduled ? 'Scheduled Automation' : 'Remote Admin',
            user_type: isScheduled ? 'scheduler' : 'admin',
            access_method: isScheduled ? 'schedule' : 'remote',
            access_method_label: isScheduled
              ? (command.action === 'unlock' ? 'Scheduled Unlock' : 'Scheduled Lock')
              : (command.action === 'unlock' ? 'Remote Unlock' : 'Remote Lock'),
            display_message: displayMessage,
            schedule_window_id: command.schedule_window_id || null,
            mapping_id: (command as any).mapping_id || null,
            mapping_name: (command as any).mapping_name || null,
            source_label: (command as any).source_label || null,
            source_type: (command as any).source_type || null,
            time_type: (command as any).time_type || null,
            synced_at: nowTimestamp(),
          }, { merge: true });
        } catch (logErr) {
          logger.debug(`[CommandListener] Access log notice: ${logErr}`);
        }
      }

      // Step 5: Update the associated schedule window if applicable
      if (command.schedule_window_id) {
        await updateScheduleWindow(
          db,
          orgId,
          command.schedule_window_id,
          command.action,
          finalStatus
        );
      }
    }

    // Invoke optional callback
    onCommand?.(command);
  }

  function evaluateQueuedDoc(doc: FirebaseFirestore.DocumentSnapshot, nowMs: number) {
    const commandId = doc.id;
    const rawData = doc.data();
    if (!rawData || rawData.status !== 'queued') {
      const timer = activeTimers.get(commandId);
      if (timer) {
        clearTimeout(timer);
        activeTimers.delete(commandId);
      }
      return;
    }

    const executeAtMs = parseExecuteAtMillis(rawData.execute_at);
    const delayMs = executeAtMs - nowMs;

    // If due now or past due (or within 5 seconds in future)
    if (delayMs <= 5000) {
      const timer = activeTimers.get(commandId);
      if (timer) {
        clearTimeout(timer);
        activeTimers.delete(commandId);
      }
      void processCommand(doc);
    } else if (delayMs < 24 * 60 * 60 * 1000) {
      // Schedule execution if not already scheduled
      if (!activeTimers.has(commandId)) {
        logger.info(
          `[CommandListener] Scheduling command ${commandId} in ${Math.round(delayMs / 1000)}s`
        );
        const timer = setTimeout(() => {
          activeTimers.delete(commandId);
          void processCommand(doc);
        }, delayMs);
        activeTimers.set(commandId, timer);
      }
    }
  }

  const query = commandsRef.where('status', '==', 'queued');
  let stopped = false;
  let unsubscribeSnapshot: (() => void) | null = null;
  let reconnectTimer: NodeJS.Timeout | null = null;

  function attachSnapshotListener() {
    if (stopped) return;
    if (unsubscribeSnapshot) {
      try {
        unsubscribeSnapshot();
      } catch {}
      unsubscribeSnapshot = null;
    }

    unsubscribeSnapshot = query.onSnapshot(
      (snapshot) => {
        const nowMs = Date.now();
        for (const docChange of snapshot.docChanges()) {
          const doc = docChange.doc;
          const commandId = doc.id;

          if (docChange.type === 'removed') {
            const timer = activeTimers.get(commandId);
            if (timer) {
              clearTimeout(timer);
              activeTimers.delete(commandId);
            }
            continue;
          }

          evaluateQueuedDoc(doc, nowMs);
        }
      },
      (err) => {
        logger.warn(`[CommandListener] Snapshot listener error (will re-attach in 5s): ${String(err)}`);
        if (unsubscribeSnapshot) {
          try {
            unsubscribeSnapshot();
          } catch {}
          unsubscribeSnapshot = null;
        }
        if (!stopped && !reconnectTimer) {
          reconnectTimer = setTimeout(() => {
            reconnectTimer = null;
            attachSnapshotListener();
          }, 5000);
          if (reconnectTimer.unref) reconnectTimer.unref();
        }
      }
    );
  }

  async function pollQueuedCommands() {
    if (stopped) return;
    try {
      const snap = await query.get();
      if (snap.empty) return;
      const nowMs = Date.now();
      for (const doc of snap.docs) {
        evaluateQueuedDoc(doc, nowMs);
      }
    } catch (err) {
      logger.debug(`[CommandListener] Periodic poll notice: ${String(err)}`);
    }
  }

  // Attach real-time listener and run periodic 15-second fallback poll
  attachSnapshotListener();
  void pollQueuedCommands();
  const pollInterval = setInterval(() => {
    void pollQueuedCommands();
  }, 15000);
  if (pollInterval.unref) pollInterval.unref();

  return () => {
    stopped = true;
    clearInterval(pollInterval);
    if (reconnectTimer) {
      clearTimeout(reconnectTimer);
      reconnectTimer = null;
    }
    for (const timer of activeTimers.values()) {
      clearTimeout(timer);
    }
    activeTimers.clear();
    if (unsubscribeSnapshot) {
      try {
        unsubscribeSnapshot();
      } catch {}
      unsubscribeSnapshot = null;
    }
  };
}
